# GroApp Design System Reborn - design.md

> Version: 1.0  
> Purpose: AI-readable design contract for GroApp Design System Reborn  
> Source: GroApp DS Reborn Variable Token  
> Scope: Product UI, prototype generation, component creation, layout documentation, and AI-assisted design implementation.

---

## 1. Role of This File

This file is the bridge between GroApp Design System Reborn in Figma and AI-assisted design/build tools.

AI must use this file as the primary design contract before generating:
- UI screens
- Components
- Layout documentation
- Prototype HTML
- Figma component structure
- Design system implementation prompts

AI must not treat this file as inspiration only. This is a constraint layer.

---

## 2. Design System Priority Order

When creating or modifying UI, use this priority order:

1. Existing component or variant
2. Component-specific semantic token
3. Global semantic token
4. Foundation token
5. New token or custom value only after explicit user confirmation

Rule:
Do not jump directly to raw hex, raw pixel values, or new visual styles when an existing token is available.

---

## 3. Token Hierarchy

GroApp DS Reborn uses 4 token levels.

### 3.1 Primitive Tokens

Primitive tokens are raw base values.  
They define the palette and base measurements.

Examples:
- `pr-brand-p3-500`
- `pr-grey-900`
- `pr-info-critical-600`
- `pr-neutral-white`
- `hifi-gap-sm`
- `hifi-md`

Primitive tokens are not the first choice for product UI.

Use primitive tokens only when:
- Creating semantic tokens
- Documenting base palette
- No semantic token exists
- User explicitly asks for foundation/token-level work

---

### 3.2 Semantic Tokens

Semantic tokens describe UI purpose.

Examples:
- `sm-atribut-text-heading`
- `sm-atribut-text-body-light`
- `sm-atribut-bg-page-grey`
- `sm-atribut-border-default`
- `sm-atribut-icon-action-default`

Semantic tokens are the default choice for product UI.

Use semantic tokens when:
- Building product screens
- Styling text, icon, border, background, and state
- Creating reusable components
- Generating prototype pages

---

### 3.3 Component Tokens

Component tokens define visual decisions for specific components and states.

Examples:
- `sm-specific-button-primary-default`
- `sm-specific-button-secondary-hover`
- `sm-specific-input-focused-normal`
- `sm-specific-toast-banner-success`
- `sm-specific-chips-active-default`

Component tokens must be used when the UI element already exists in the design system.

Use component tokens when:
- Creating buttons
- Creating inputs
- Creating chips
- Creating tabs
- Creating toast/banner
- Creating tooltip
- Creating toggle

---

### 3.4 Layout Tokens

Layout tokens define spacing, padding, gap, and radius.

Examples:
- `hifi-gap-2xs`
- `hifi-gap-sm`
- `hifi-gap-md`
- `hifi-padding-md`
- `hifi-xs`
- `hifi-md`
- `sizes-border-radius-pill`

Layout tokens must be used instead of arbitrary pixel values.

---

## 4. Core Color Mapping

### 4.1 Brand / Action Color

GroApp primary action color is mapped to the P3 brand palette.

| Purpose | Token | Reference |
|---|---|---|
| Light action background | `growapp-action-50` | `pr-brand-p3-50` |
| Subtle action background | `growapp-action-100` | `pr-brand-p3-100` |
| Hover border / soft highlight | `growapp-action-300` | `pr-brand-p3-300` |
| Hover action | `growapp-action-400` | `pr-brand-p3-400` |
| Default action | `growapp-action-500` | `pr-brand-p3-500` |
| Focus action | `growapp-action-600` | `pr-brand-p3-600` |
| Pressed action | `growapp-action-700` | `pr-brand-p3-700` |
| Dark emphasis action | `growapp-action-800` | `pr-brand-p3-800` |
| Highest contrast action | `growapp-action-900` | `pr-brand-p3-900` |

Rules:
- Use `500` for default primary action.
- Use `400` for hover.
- Use `600` for focus.
- Use `700` for pressed.
- Use `50` for soft action background.
- Do not use multiple primary action areas in the same decision context.

---

### 4.2 Text Color

| Purpose | Preferred Token | Reference |
|---|---|---|
| Page title | `sm-atribut-text-heading` | `pr-grey-900` |
| Section title | `sm-atribut-text-title` | `pr-grey-900` |
| Label | `sm-atribut-text-label` | `pr-grey-900` |
| Main body | `sm-atribut-text-body-dark` | `pr-grey-900` |
| Secondary body | `sm-atribut-text-body-light` | `pr-grey-600` |
| Caption | `sm-atribut-text-caption` | `pr-grey-600` |
| Caption dark | `sm-atribut-text-caption-dark` | `pr-grey-800` |
| Placeholder | `sm-atribut-text-placeholder` | `pr-grey-400` |
| Disabled text | `sm-atribut-text-disabled` | `pr-grey-700` |
| Read-only text | `sm-atribut-text-read-only` | `pr-grey-900` |
| Link | `sm-atribut-text-hyperlink` | `pr-brand-p3-500` |
| White text | `sm-atribut-text-white` | `pr-neutral-white` |

Rules:
- Do not use `pr-grey-*` directly for product text if a semantic text token exists.
- Use `heading/title/label/body/caption` based on information hierarchy.
- Placeholder must not use body text color.
- Disabled and read-only must be visually different.

---

### 4.3 Background Color

| Purpose | Preferred Token | Reference |
|---|---|---|
| Default page background | `sm-atribut-bg-page-grey` | `pr-grey-50` |
| White page/surface | `sm-atribut-bg-page-white` | `pr-neutral-white` |
| Brand page/accent area | `sm-atribut-bg-page-brand` | `pr-brand-p3-500` |
| Overlay | `sm-atribut-bg-page-overlay` | `pr-neutral-overlay` |
| Card/surface white | `sm-atribut-bg-surface-white` | `pr-neutral-white` |
| Surface grey | `sm-atribut-bg-surface-grey` | `pr-grey-100` |
| Surface light grey | `sm-atribut-bg-surface-lightgrey` | `pr-grey-50` |
| Disabled fill | `sm-atribut-bg-fill-global-disabled` | `pr-grey-100` |
| Read-only fill | `sm-atribut-bg-fill-global-readonly` | `pr-grey-100` |

Rules:
- Product pages should default to `sm-atribut-bg-page-grey`.
- Cards and panels should default to `sm-atribut-bg-surface-white`.
- Avoid placing white cards on white page without border/divider.
- Use overlay token for modal/backdrop states.

---

### 4.4 Border Color

| Purpose | Preferred Token | Reference |
|---|---|---|
| Default border | `sm-atribut-border-default` | `pr-grey-200` |
| Disabled border | `sm-atribut-border-disabled` | `pr-grey-200` |
| Hover grey border | `sm-atribut-border-grey-hover` | `pr-grey-400` |
| Focus grey border | `sm-atribut-border-grey-focused` | `pr-grey-500` |
| Action border | `sm-atribut-border-action-default` | `pr-brand-p3-500` |
| Action focus border | `sm-atribut-border-action-focused` | `pr-brand-p3-300` |
| Error border | `sm-atribut-border-error-default` | `pr-info-critical-600` |
| Null border | `sm-atribut-border-null` | `pr-neutral-null` |

Rules:
- Default containers use `sm-atribut-border-default`.
- Inputs on focus use component input state tokens first.
- Error border must use error-specific tokens, not action tokens.

---

### 4.5 Icon Color

| Purpose | Preferred Token | Reference |
|---|---|---|
| Default dark icon | `sm-atribut-icon-dark-default` | `pr-grey-900` |
| Default grey icon | `sm-atribut-icon-grey-default` | `pr-grey-600` |
| Action icon | `sm-atribut-icon-action-default` | `pr-brand-p3-500` |
| Disabled icon | `sm-atribut-icon-dark-disabled` | `pr-grey-700` |
| Error icon | `sm-atribut-icon-error-default` | `pr-info-critical-600` |
| Success icon | `sm-atribut-icon-global-success` | `pr-info-success-700` |
| White icon | `sm-atribut-icon-global-white` | `pr-neutral-white` |

Rules:
- Use icon color according to role, not icon shape.
- Decorative icons should use lower emphasis grey.
- Action icons should only be used when clickable or strongly associated with action.

---

## 5. Feedback / Status Color Mapping

| Status | Text/Icon Token | Fill Token | Border Token |
|---|---|---|---|
| Success | `sm-atribut-text-inform-limegreen` / `sm-atribut-icon-inform-limegreen` | `sm-atribut-bg-fill-inform-limegreen` | `sm-atribut-border-inform-limegreen` |
| Warning | `sm-atribut-text-inform-yellow` / `sm-atribut-icon-inform-yellow` | `sm-atribut-bg-fill-inform-yellow` | `sm-atribut-border-inform-yellow` |
| Error / Critical | `sm-atribut-text-inform-red` / `sm-atribut-icon-inform-red` | `sm-atribut-bg-fill-inform-red` | `sm-atribut-border-inform-red` |
| Informative | `sm-atribut-text-inform-blue` / `sm-atribut-icon-inform-blue` | `sm-atribut-bg-fill-inform-blue` | `sm-atribut-border-inform-blue` |
| Brand 1 | `sm-atribut-text-inform-brand-1` / `sm-atribut-icon-inform-brand-1` | `sm-atribut-bg-fill-inform-brand-1` | `sm-atribut-border-inform-brand-1` |
| Brand 2 | `sm-atribut-text-inform-brand-2` / `sm-atribut-icon-inform-brand-2` | `sm-atribut-bg-fill-inform-brand-2` | `sm-atribut-border-inform-brand-2` |
| Brand 3 | `sm-atribut-text-inform-brand-3` / `sm-atribut-icon-inform-brand-3` | `sm-atribut-bg-fill-inform-brand-3` | `sm-atribut-border-inform-brand-3` |

Rules:
- Use feedback tokens for system condition, not decoration.
- Do not use red/orange/green just for visual variety.
- Error means user or system needs attention.
- Warning means risk or pending condition.
- Informative means neutral explanation.
- Success means completed or valid state.

---

## 6. Typography Mapping

Font family:
- `Plus Jakarta Sans`

| UI Role | Token | Size | Line Height | Default Weight |
|---|---|---:|---:|---|
| Page H1 | `typescale-h1-2986rem` | 48px | 72px | Semibold/Bold |
| Page H2 | `typescale-h2-2488rem` | 40px | 60px | Semibold/Bold |
| Page H3 | `typescale-h3-2074rem` | 32px | 48px | Semibold/Bold |
| Section title large | `typescale-h4-1728rem` | 28px | 42px | Semibold |
| Section title medium | `typescale-h5-144rem` | 24px | 36px | Semibold |
| Section title small | `typescale-h6-12rem` | 20px | 30px | Semibold |
| Body | `typescale-base-1rem` | 16px | 24px | Regular/Medium |
| Small body | `typescale-smallbase-0833rem` | 14px | 21px | Regular/Medium |
| Button | `typescale-button-0833rem` | 14px | 14px | Medium/Semibold |
| Caption | `typescale-caption-0833rem` | 12px | 18px | Regular/Medium |
| Label | `typescale-label-0694rem` | 12px | 12px | Medium/Semibold |
| Placeholder | `typescale-placeholder-0833rem` | 14px | 21px | Regular |
| Support text | `typescale-support` | 8px | 12px | Regular |

Rules:
- Use H1/H2 sparingly. Most product pages should start from H4, H5, or H6 depending on layout density.
- Use `typescale-base-1rem` for readable content.
- Use `typescale-smallbase-0833rem` for compact tables, metadata, and secondary descriptions.
- Use `caption` for helper text, timestamp, minor context, and notes.
- Do not fake hierarchy using only color. Use typography role + spacing + layout.

---

## 7. Spacing Mapping

### 7.1 Gap Tokens

| Token | Value | Recommended Use |
|---|---:|---|
| `hifi-gap-3xs` | 4px | Icon-text micro gap, tight inline elements |
| `hifi-gap-2xs` | 8px | Form helper gap, badge content gap, compact group |
| `hifi-gap-xsm` | 12px | Field label to input, compact vertical rhythm |
| `hifi-gap-sm` | 16px | Default component internal gap |
| `hifi-gap-md` | 24px | Section inner grouping, card content spacing |
| `hifi-gap-lg` | 32px | Section-to-section spacing |
| `hifi-gap-xl` | 48px | Major content separation |
| `hifi-gap-xxl` | 64px | Large layout separation, landing-style spacing |

### 7.2 Padding Tokens

| Token | Value | Recommended Use |
|---|---:|---|
| `hifi-padding-3xs` | 4px | Micro component padding |
| `hifi-padding-2xs` | 8px | Small badge/chip/control padding |
| `hifi-padding-xs` | 12px | Compact component padding |
| `hifi-padding-sm` | 16px | Default card/control padding |
| `hifi-padding-md` | 24px | Standard card/section padding |
| `hifi-padding-lg` | 32px | Large section padding |
| `hifi-padding-xl` | 40px | Page-level hero/content padding |
| `hifi-padding-2xl` | 48px | Large page block padding |
| `hifi-padding-3xl` | 64px | Maximum section padding |

Rules:
- Use 8px-based rhythm.
- Default card padding should be `hifi-padding-md`.
- Dense table/list area may use `hifi-padding-sm`.
- Do not use arbitrary spacing like 10px, 18px, 22px, 30px unless user confirms new design need.

---

## 8. Radius Mapping

| Token | Value | Recommended Use |
|---|---:|---|
| `hifi-xs` | 8px | Input, badge, small control |
| `hifi-sm` | 12px | Button, chip, compact card |
| `hifi-md` | 16px | Standard card, modal inner surface |
| `hifi-lg` | 20px | Large card, elevated panel |
| `hifi-xl` | 24px | Modal/container |
| `hifi-2xl` | 32px | Large hero or special surface |
| `sizes-border-radius-pill` | 100px | Pill badge, rounded chip, toggle |

Rules:
- Use `hifi-sm` for most buttons and chips.
- Use `hifi-md` for standard cards.
- Use pill radius only for pill-shaped elements, not normal cards.
- Do not create one-off radius values.

---

## 9. Component Mapping

## 9.1 Button

Available button families:
- Primary
- Secondary
- Tertiary
- Neutral
- Error Primary
- Error Secondary
- Error Tertiary

### Primary Button

Use for the main action in a context.

| State | Token |
|---|---|
| Default | `sm-specific-button-primary-default` |
| Hover | `sm-specific-button-primary-hover` |
| Focused | `sm-specific-button-primary-focused` |
| Pressed | `sm-specific-button-primary-pressed` |
| Disabled | `sm-specific-button-primary-disabled` |

Rules:
- Only one primary button per decision area.
- Use for save, submit, continue, create, confirm.
- Do not use primary for cancel, secondary navigation, or destructive action.

### Secondary Button

Use for supporting actions that are still important.

| State | Token |
|---|---|
| Default | `sm-specific-button-secondary-default` |
| Hover | `sm-specific-button-secondary-hover` |
| Focused | `sm-specific-button-secondary-focused` |
| Pressed | `sm-specific-button-secondary-pressed` |
| Disabled | `sm-specific-button-secondary-disabled` |

Use for:
- Back
- Export
- Filter
- Edit when not the primary path
- Alternative action

### Tertiary Button

Use for low-emphasis actions.

| State | Token |
|---|---|
| Default | `sm-specific-button-tertiary-default` |
| Hover | `sm-specific-button-tertiary-hover` |
| Focused | `sm-specific-button-tertiary-focused` |
| Pressed | `sm-specific-button-tertiary-pressed` |
| Disabled | `sm-specific-button-tertiary-disabled` |

Use for:
- Inline action
- View details
- Optional helper action
- Secondary link-like command

### Neutral Button

Use for neutral command that should not look brand-promotional.

| State | Token |
|---|---|
| Default | `sm-specific-button-neutral-default` |
| Hover | `sm-specific-button-neutral-hover` |
| Focused | `sm-specific-button-neutral-focused` |
| Pressed | `sm-specific-button-neutral-pressed` |
| Disabled | `sm-specific-button-neutral-disabled` |

Use for:
- Close
- Cancel
- Dismiss
- More options

### Error Button

Use only for destructive or irreversible actions.

| Variant | State Token Pattern |
|---|---|
| Error Primary | `sm-specific-error-button-primary-{state}` |
| Error Secondary | `sm-specific-error-button-secondary-{state}` |
| Error Tertiary | `sm-specific-error-button-tertiary-{state}` |

Use for:
- Delete
- Remove
- Deactivate when destructive or risky
- Confirm dangerous action

Rules:
- Destructive action should not use normal primary button.
- If a modal contains destructive action, use error button for destructive confirmation and neutral/secondary for cancel.

---

## 9.2 Input

Preferred component token pattern:
- `sm-specific-input-{state}-{status}`
- `sm-form-input-{state}-{status}`

Common states:
- default
- hover
- focused
- typing
- filled
- disabled
- read-only

Common statuses:
- normal
- success
- error

Rules:
- Use `default-normal` before user interaction.
- Use `hover-normal` on hover.
- Use `focused-normal` when field is active but empty.
- Use `typing-normal` when user is typing.
- Use `filled-normal` when field has valid content.
- Use `default-error`, `typing-error`, or `filled-error` when validation fails.
- Use `disabled` when user cannot interact.
- Use `read-only` when value is visible but intentionally locked.

Do not use disabled style for read-only content.

---

## 9.3 Toast / Banner

| Intent | Token |
|---|---|
| Success | `sm-specific-toast-banner-success` |
| Warning | `sm-specific-toast-banner-warning` |
| Error | `sm-specific-toast-banner-error` |
| Informative | `sm-specific-toast-banner-informative` |
| Default | `sm-specific-toast-banner-default` |

Rules:
- Success: action completed.
- Warning: user can proceed but should be careful.
- Error: action failed or needs correction.
- Informative: neutral guidance.
- Default: low-priority message.
- Toast/banner should not replace form-level validation.

---

## 9.4 Chips

Active chip:
- `sm-specific-chips-active-default`
- `sm-specific-chips-active-hover`
- `sm-specific-chips-active-focused`
- `sm-specific-chips-active-pressed`

Inactive chip:
- `sm-specific-chips-inactive-default`
- `sm-specific-chips-inactive-hover`
- `sm-specific-chips-inactive-focused`
- `sm-specific-chips-inactive-pressed`

Disabled chip:
- `sm-specific-chips-disabled`

Rules:
- Use chips for filter selections, category indicators, and compact status selectors.
- Active chip means selected/applied.
- Inactive chip means available but not selected.
- Disabled chip means unavailable.

---

## 9.5 Tabs

| State | Token |
|---|---|
| Active | `sm-specific-tabs-active` |
| Default | `sm-specific-tabs-default` |
| Hover | `sm-specific-tabs-hover` |
| Disabled | `sm-specific-tabs-disabled` |

Rules:
- Active tab must clearly indicate current content.
- Tabs are for switching content within the same context.
- Do not use tabs for primary navigation across unrelated modules.

---

## 9.6 Toggle

| State | Token |
|---|---|
| Active | `sm-specific-toogle-active-*` |
| Active pressed | `sm-specific-toogle-active-action-pressed` |
| Inactive | `sm-specific-toogle-inactive-*` |
| Disabled | `sm-specific-toogle-disabled-*` |

Rules:
- Toggle is for immediate binary state.
- Do not use toggle for actions that require confirmation unless product explicitly requires it.
- For destructive state changes, use confirmation modal if risk is high.

---

## 9.7 Tooltip

| Purpose | Token |
|---|---|
| Tooltip fill | `sm-specific-tooltips-fill` |
| Tooltip text | `sm-specific-tooltips-text` |
| Default icon | `sm-specific-tooltips-icon-default` |
| Success icon | `sm-specific-tooltips-icon-success` |
| Error icon | `sm-specific-tooltips-icon-error` |

Rules:
- Tooltip explains, not replaces visible label.
- Tooltip should be short.
- Do not hide critical information only inside tooltip.

---

## 10. Product Layout Rules

### 10.1 Page

Default page:
- Background: `sm-atribut-bg-page-grey`
- Main content surface: `sm-atribut-bg-surface-white`
- Border: `sm-atribut-border-default`
- Radius: `hifi-md`
- Padding: `hifi-padding-md`
- Section gap: `hifi-gap-lg`

### 10.2 Card

Default card:
- Fill: `sm-atribut-bg-surface-white`
- Border: `sm-atribut-border-default`
- Radius: `hifi-md`
- Padding: `hifi-padding-md`
- Internal gap: `hifi-gap-sm` or `hifi-gap-md`

### 10.3 Detail Information Layout

Use stacked layout when:
- Information must be scanned vertically
- Content labels are long
- Mobile scalability is important
- Detail values vary in length
- Readability is more important than density

Use grid layout when:
- Information is short and comparable
- Desktop density is needed
- Labels and values are predictable
- The section has 4 or more compact metadata items

Rules:
- Do not mix grid and stacked randomly in the same detail section.
- Use one dominant layout pattern per detail page.
- Summary/high-priority information should appear above lower-priority metadata.
- Use whitespace intentionally, not as leftover canvas space.

---

## 11. AI Behavior Rules

When AI generates or modifies UI, AI must:

1. Identify component level first:
   - Foundation
   - Primitive
   - Component
   - Pattern
   - Template

2. Check whether existing token/component covers the request.

3. Use semantic/component tokens before primitive values.

4. Preserve existing visual direction unless user asks for redesign.

5. Make only requested changes.

6. Ask confirmation before:
   - Creating new component
   - Creating new token
   - Changing visual direction
   - Changing hierarchy beyond request
   - Changing layout pattern
   - Introducing non-GroApp colors, typography, radius, or spacing

7. Document token usage in layout/spec output.

8. Avoid hardcoded values when token exists.

9. Do not invent component variants without explaining the gap.

10. If requirements conflict with the design system, report the conflict before generating.

---

## 12. Required AI Output Format for Component Creation

For every generated component, AI must include:

```md
## Component Name

### Component Level
Primitive / Component / Pattern / Template

### Purpose
Describe what the component solves.

### Anatomy
- Container
- Header
- Body
- Footer
- Icon
- CTA
- Supporting text

### Variants
| Variant | Usage |
|---|---|

### States
| State | Token |
|---|---|

### Token Usage
| Property | Token |
|---|---|

### Layout Rules
Explain spacing, padding, alignment, radius, and responsiveness.

### Do
- Reuse existing tokens.
- Keep interaction states consistent.

### Don't
- Do not hardcode visual values.
- Do not add unrequested layout changes.

### Confirmation Needed
List any design decisions that require user confirmation.
```

---

## 13. Required AI Output Format for Screen / Template Creation

For every generated screen, AI must include:

```md
## Screen Name

### Screen Type
List / Detail / Form / Modal / Empty State / Error State / Confirmation / Template

### Purpose
What user goal this screen supports.

### Layout Structure
1. Header
2. Main Content
3. Supporting Section
4. Footer / CTA Area

### Component Inventory
| Area | Component | Existing DS Reference |
|---|---|---|

### Token Usage
| UI Part | Token |
|---|---|

### Interaction States
| Interaction | Expected State |
|---|---|

### Responsive Rule
Desktop and mobile behavior.

### Scope Control
What AI is allowed and not allowed to change.

### Confirmation Needed
Any change outside user request.
```

---

## 14. Anti-Randomness Rules

AI must not:
- Hardcode hex colors.
- Use arbitrary spacing values.
- Invent new shadows, radii, or typography.
- Use multiple primary CTAs in one decision context.
- Mix action color and error color incorrectly.
- Use disabled style for read-only.
- Use primitive color directly when semantic token exists.
- Create one-off variants without confirmation.
- Change layout direction outside request.
- Add decorative colors without product purpose.

---

## 15. Preferred Prompt Prefix for AI Design Work

Use this prompt before asking AI to create GroApp DS UI:

```txt
You are working with GroApp Design System Reborn. Before generating UI, read and obey design.md as the source of truth.

Rules:
- Use existing components, variants, and tokens first.
- Use semantic/component tokens before primitive tokens.
- Do not hardcode colors, spacing, radius, or typography.
- Do not change visual direction outside the user request.
- If a required style/component/token does not exist, explain the gap and ask confirmation before creating a new one.
- Document token usage for every generated component or screen.
- Keep layout consistent, scalable, and readable across desktop and mobile.
```

---

## 16. Final Validation Checklist

Before finalizing any design output, AI must check:

- [ ] Component level is classified.
- [ ] Existing component/variant checked.
- [ ] Semantic/component token used.
- [ ] No raw hex unless documenting primitive token.
- [ ] No arbitrary spacing.
- [ ] Typography follows mapped roles.
- [ ] Radius follows mapped usage.
- [ ] Button hierarchy is clear.
- [ ] Error/destructive actions use error tokens.
- [ ] Disabled and read-only are not confused.
- [ ] Layout change is within user request.
- [ ] Any new token/component has confirmation note.
- [ ] Token usage is documented.

---

## 17. One-Line Principle

GroApp DS Reborn is not a style suggestion.  
It is a reusable decision system for making UI predictable for humans and readable for AI.
