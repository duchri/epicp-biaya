# GroApp Biaya Prototype

Pembaruan ini mencakup:
- Step 2 Impor Biaya tetap aktif ketika data belum valid.
- Tombol `Perbaiki Data Impor` membuka modal Panduan Perbaikan Data Impor.
- Catatan validasi dapat diunduh sebagai CSV.
- File Excel yang sudah diperbaiki dapat diunggah ulang langsung dari modal.
- Setelah pengecekan ulang berhasil, `Perlu Diperbaiki` menjadi 0 dan tombol `Impor Sekarang` aktif.

Buka `index.html` untuk menjalankan prototype.
