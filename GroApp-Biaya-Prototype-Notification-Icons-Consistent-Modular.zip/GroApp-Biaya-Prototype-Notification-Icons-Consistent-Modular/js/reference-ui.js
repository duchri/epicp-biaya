
/*
 * Reference UI behavior layer.
 * Keeps datasets and transaction flow in app.js intact.
 */

let prototypeRole = 'owner';
let uiPeriodMode = 'period';
let uiPeriodPhase = 'start';
let uiPeriodDraftStart = '2026-07-01';
let uiPeriodDraftEnd = '2026-07-31';
let uiPeriodMonthAnchor = new Date(2026, 6, 1);
let uiDueShortcut = 'all';
let uiDueStart = '';
let uiDueEnd = '';

const referenceOriginalShowPage = window.showPage;

function refDate(iso){
  if(!iso) return null;
  const [year,month,day] = String(iso).slice(0,10).split('-').map(Number);
  return new Date(year,month-1,day);
}
function refIso(date){
  const pad=value=>String(value).padStart(2,'0');
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
}
function refSlash(iso){
  const date=refDate(iso);
  if(!date) return '-';
  return new Intl.DateTimeFormat('id-ID',{day:'2-digit',month:'2-digit',year:'numeric'}).format(date);
}
function refMonthTitle(date){
  return new Intl.DateTimeFormat('id-ID',{month:'long',year:'numeric'}).format(date);
}
function addRefDays(date,days){
  const copy=new Date(date);
  copy.setDate(copy.getDate()+days);
  return copy;
}
function addRefMonths(date,months){
  const copy=new Date(date);
  copy.setMonth(copy.getMonth()+months);
  return copy;
}
function refStartOfYear(date){return new Date(date.getFullYear(),0,1)}
function refDefaultPeriod(){return {start:'2026-07-01',end:'2026-07-31'}}

window.syncDateRangeLabel=function syncDateRangeLabel(){
  const start=document.getElementById('periodStart')?.value;
  const end=document.getElementById('periodEnd')?.value;
  const label=document.getElementById('dateRangeLabel');
  if(label&&start&&end) label.textContent=`${refSlash(start)} - ${refSlash(end)}`;
};

function dueLabel(){
  const labels={all:'Semua','14':'14 Hari Lagi','7':'7 Hari Lagi','3':'3 Hari Lagi',tomorrow:'Besok',today:'Hari Ini',overdue:'Terlambat',custom:`${refSlash(uiDueStart)} - ${refSlash(uiDueEnd)}`};
  return labels[quickDue]||'Semua';
}

window.syncQuickFilterUI=function syncQuickFilterUI(){
  const source=document.getElementById('sourceFilter');
  const payment=document.getElementById('quickPaymentStatus');
  const due=document.getElementById('quickDueStatus');
  const dueText=document.getElementById('quickDueLabel');
  if(source) source.value=filters.source||'all';
  if(payment) payment.value=filters.pay?.length===1?filters.pay[0]:'all';
  if(due&&[...due.options].some(option=>option.value===quickDue)) due.value=quickDue;
  if(dueText) dueText.textContent=dueLabel();
  syncDateRangeLabel();
  populateFilterOptions();
};

window.setQuickPaymentStatus=function setQuickPaymentStatus(value){
  filters.pay=value==='all'?[]:[value];
  populateFilterOptions();
  renderList();
  syncSidebarToggleIcon();
};

window.setSourceFilter=function setSourceFilter(value){
  filters.source=value;
  renderList();
};

window.resetQuickFilters=function resetQuickFilters(){
  const defaults=refDefaultPeriod();
  filters={source:'all',pay:[],contact:[],item:[],expense:[],due:'all',account:[]};
  quickDue='all';
  uiDueShortcut='all';
  uiDueStart='';
  uiDueEnd='';
  activeTab='Terbit';
  document.getElementById('periodStart').value=defaults.start;
  document.getElementById('periodEnd').value=defaults.end;
  document.getElementById('rangeDraftStart').value=defaults.start;
  document.getElementById('rangeDraftEnd').value=defaults.end;
  selected.clear();
  syncQuickFilterUI();
  renderList();
};

window.quickDueMatches=function quickDueMatches(expense){
  if(quickDue==='all') return true;
  if(!expense.due||expense.payStatus==='Lunas'||expense.status!=='Terbit') return false;
  if(quickDue==='custom') return expense.due>=uiDueStart&&expense.due<=uiDueEnd;
  const diff=Math.ceil((refDate(expense.due)-refDate(refIso(today)))/86400000);
  if(quickDue==='overdue') return diff<0;
  if(quickDue==='today') return diff===0;
  if(quickDue==='tomorrow') return diff===1;
  return diff===Number(quickDue);
};

window.actionMenu=function actionMenu(expense){
  if(expense.status==='Draft'){
    return `<button onclick="openDetail(${expense.id})">Detail</button><button onclick="openForm(${expense.id})">Edit Draft</button><button onclick="askDelete(${expense.id})">Hapus Draft</button><button onclick="openPrint(${expense.id})">Cetak</button>`;
  }
  if(expense.status==='Terbit'){
    const paymentAction=expense.payStatus!=='Lunas'?`<button onclick="openPayment(${expense.id})">Catat Pembayaran</button>`:`<button onclick="openRepeatForm(${expense.id})">Catat Lagi</button>`;
    const voidAction=prototypeRole==='finance'?'':`<button onclick="askVoid(${expense.id})">Void</button>`;
    return `<button onclick="openDetail(${expense.id})">Detail</button>${paymentAction}<button onclick="openPrint(${expense.id})">Cetak</button>${voidAction}`;
  }
  return `<button onclick="openDetail(${expense.id})">Detail</button><button onclick="openRepeatForm(${expense.id})">Catat Lagi</button><button onclick="openPrint(${expense.id})">Cetak</button>`;
};

window.renderList=function renderList(){
  const base=filteredBase();
  const query=(document.getElementById('searchInput')?.value||'').trim().toLowerCase();
  const context=query?base.filter(expense=>`${expense.code} ${expense.sourceData||'Perusahaan'} ${expense.title} ${expense.contact} ${expense.items.map(item=>item.item).join(' ')}`.toLowerCase().includes(query)):base;
  renderTabs(context);
  const data=context.filter(expense=>expense.status===activeTab).sort((a,b)=>b.date.localeCompare(a.date));
  const issued=context.filter(expense=>expense.status==='Terbit');
  const total=issued.reduce((sum,expense)=>sum+(totalOf(expense)-pphOf(expense)),0);
  const gross=issued.reduce((sum,expense)=>sum+expense.items.reduce((itemSum,item)=>itemSum+Number(item.amount||0),0),0);
  const ppn=issued.reduce((sum,expense)=>sum+ppnOf(expense),0);
  const pph=issued.reduce((sum,expense)=>sum+pphOf(expense),0);
  const paid=issued.reduce((sum,expense)=>sum+Math.min(Number(expense.paid||0),totalOf(expense)-pphOf(expense)),0);
  const remaining=issued.reduce((sum,expense)=>sum+remainingOf(expense),0);
  const overdue=issued.filter(expense=>expense.due&&new Date(expense.due+'T23:59:59')<today&&expense.payStatus!=='Lunas');

  document.getElementById('sumTotal').textContent=rupiah(total);
  document.getElementById('sumTotalSub').textContent=`Pokok ${rupiah(gross)} • PPN ${rupiah(ppn)} • PPh ${rupiah(pph)}`;
  document.getElementById('paidRatio').textContent=`${total?Math.round(paid/total*100):0}%`;
  document.getElementById('debtRatio').textContent=`${total?Math.round(remaining/total*100):0}%`;
  document.getElementById('paidRatioNominal').textContent=rupiah(paid);
  document.getElementById('debtRatioNominal').textContent=rupiah(remaining);
  document.getElementById('sumOverdue').textContent=rupiah(overdue.reduce((sum,expense)=>sum+remainingOf(expense),0));
  document.getElementById('sumOverdueCount').textContent=`${overdue.length} transaksi`;

  const rowTarget=document.getElementById('rows');
  rowTarget.innerHTML=data.length?data.map(expense=>`<tr><td><input type="checkbox" ${selected.has(expense.id)?'checked':''} onchange="toggleSelect(${expense.id},this.checked)"></td><td>${dateTimeStack(expense.date)}</td><td><span class="code-link">${expense.code}</span></td><td>${expense.sourceData||'Perusahaan'}</td><td><span class="vendor-link">${expense.contact||'-'}</span></td><td class="due-cell ${dueToneClass(expense)}" title="${expenseEscape(dueToneLabel(expense))}">${expense.due?fmtDate(expense.due):'-'}</td><td class="total-strong">${rupiah(totalOf(expense)-pphOf(expense))}</td><td>${rupiah(remainingOf(expense))}</td><td><span class="badge ${expense.payStatus==='Lunas'?'lunas':expense.payStatus==='Dibayar Sebagian'?'partial':'unpaid'}">${expense.payStatus}</span></td><td class="actions"><button class="kebab row-kebab" aria-expanded="false" onclick="toggleMenu(event,${expense.id})" aria-label="Buka aksi"><i class="ti ti-dots" aria-hidden="true"></i></button><div class="menu" id="menu${expense.id}">${actionMenu(expense)}</div></td></tr>`).join(''):`<tr><td colspan="10"><div class="empty">Tidak ada data sesuai pencarian atau filter.</div></td></tr>`;

  const bulk=document.getElementById('bulkBar');
  bulk.classList.toggle('show',selected.size>0);
  document.getElementById('bulkText').textContent=`${selected.size} transaksi dipilih`;
  const selectAllNode=document.getElementById('selectAll');
  selectAllNode.checked=data.length>0&&data.every(expense=>selected.has(expense.id));

  const defaults=refDefaultPeriod();
  const customPeriod=document.getElementById('periodStart').value!==defaults.start||document.getElementById('periodEnd').value!==defaults.end;
  const activeCount=[filters.contact.length>0,filters.item.length>0,filters.expense.length>0,filters.account.length>0].filter(Boolean).length;
  const filterButton=document.getElementById('filterBtn');
  filterButton.innerHTML=activeCount?`<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter (${activeCount})`:'<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter';
  filterButton.className='btn '+(activeCount?'btn-soft':'btn-secondary');
  const resetButton=document.getElementById('resetFilterButton');
  if(resetButton) resetButton.disabled=activeCount===0&&activeTab==='Terbit'&&!query;
  const dueText=document.getElementById('quickDueLabel');
  if(dueText) dueText.textContent=dueLabel();
};

window.openPeriodPicker=function openPeriodPicker(mode){
  uiPeriodMode=mode==='due'?'due':'period';
  uiPeriodPhase='start';
  document.getElementById('periodShortcutList').hidden=uiPeriodMode==='due';
  document.getElementById('dueShortcutList').hidden=uiPeriodMode!=='due';
  document.getElementById('periodStartLabel').innerHTML=`${uiPeriodMode==='due'?'Jatuh Tempo Awal':'Periode Awal'} <span class="required-mark">*</span>`;
  document.getElementById('periodEndLabel').innerHTML=`${uiPeriodMode==='due'?'Jatuh Tempo Akhir':'Periode Akhir'} <span class="required-mark">*</span>`;
  if(uiPeriodMode==='period'){
    uiPeriodDraftStart=document.getElementById('periodStart').value;
    uiPeriodDraftEnd=document.getElementById('periodEnd').value;
  }else{
    uiDueShortcut=quickDue;
    if(quickDue==='custom'&&uiDueStart&&uiDueEnd){
      uiPeriodDraftStart=uiDueStart;
      uiPeriodDraftEnd=uiDueEnd;
    }else{
      const base=refDate(refIso(today));
      uiPeriodDraftStart=refIso(base);
      uiPeriodDraftEnd=refIso(base);
      setDueShortcutDraft(quickDue,false);
    }
  }
  uiPeriodMonthAnchor=new Date(refDate(uiPeriodDraftStart).getFullYear(),refDate(uiPeriodDraftStart).getMonth(),1);
  document.getElementById('periodPickerError').textContent='';
  renderPeriodPicker();
  openModal('periodModal');
};

function setDueShortcutDraft(key,rerender=true){
  const base=refDate(refIso(today));
  uiDueShortcut=key;
  if(key==='all'){
    uiPeriodDraftStart=refIso(base);
    uiPeriodDraftEnd=refIso(base);
  }else if(key==='overdue'){
    uiPeriodDraftStart=`${base.getFullYear()}-01-01`;
    uiPeriodDraftEnd=refIso(addRefDays(base,-1));
  }else if(key==='today'){
    uiPeriodDraftStart=uiPeriodDraftEnd=refIso(base);
  }else if(key==='tomorrow'){
    uiPeriodDraftStart=uiPeriodDraftEnd=refIso(addRefDays(base,1));
  }else if(['3','7','14'].includes(key)){
    uiPeriodDraftStart=uiPeriodDraftEnd=refIso(addRefDays(base,Number(key)));
  }
  if(rerender) renderPeriodPicker();
}

window.setPeriodShortcut=function setPeriodShortcut(key){
  const base=refDate(refIso(today));
  if(uiPeriodMode==='due'){
    if(key==='custom') uiDueShortcut='custom';
    else setDueShortcutDraft(key,false);
  }else{
    if(key==='today') uiPeriodDraftStart=uiPeriodDraftEnd=refIso(base);
    if(key==='week'){uiPeriodDraftStart=refIso(addRefDays(base,-6));uiPeriodDraftEnd=refIso(base)}
    if(key==='month'){uiPeriodDraftStart=refIso(addRefMonths(base,-1));uiPeriodDraftEnd=refIso(base)}
    if(key==='quarter'){uiPeriodDraftStart=refIso(addRefMonths(base,-3));uiPeriodDraftEnd=refIso(base)}
    if(key==='year'){uiPeriodDraftStart=refIso(refStartOfYear(base));uiPeriodDraftEnd=refIso(base)}
    if(key==='custom') uiPeriodPhase='start';
  }
  uiPeriodMonthAnchor=new Date(refDate(uiPeriodDraftStart).getFullYear(),refDate(uiPeriodDraftStart).getMonth(),1);
  renderPeriodPicker();
};

window.setPeriodSelectionPhase=function setPeriodSelectionPhase(phase){
  uiPeriodPhase=phase==='end'?'end':'start';
  renderPeriodPicker();
};

window.selectPeriodDate=function selectPeriodDate(iso){
  if(uiPeriodMode==='due') uiDueShortcut='custom';
  if(uiPeriodPhase==='start'){
    uiPeriodDraftStart=iso;
    if(!uiPeriodDraftEnd||iso>uiPeriodDraftEnd) uiPeriodDraftEnd=iso;
    uiPeriodPhase='end';
  }else{
    uiPeriodDraftEnd=iso;
    if(uiPeriodDraftEnd<uiPeriodDraftStart){
      const oldStart=uiPeriodDraftStart;
      uiPeriodDraftStart=uiPeriodDraftEnd;
      uiPeriodDraftEnd=oldStart;
    }
  }
  renderPeriodPicker();
};

window.navigatePeriodMonths=function navigatePeriodMonths(delta){
  uiPeriodMonthAnchor=new Date(uiPeriodMonthAnchor.getFullYear(),uiPeriodMonthAnchor.getMonth()+delta,1);
  renderPeriodPicker();
};

function renderCalendar(targetId,titleId,monthDate){
  document.getElementById(titleId).textContent=refMonthTitle(monthDate);
  const weekdays=['Sen','Sel','Rab','Kam','Jum','Sab','Min'];
  const first=new Date(monthDate.getFullYear(),monthDate.getMonth(),1);
  const mondayIndex=(first.getDay()+6)%7;
  const gridStart=addRefDays(first,-mondayIndex);
  let html=weekdays.map(day=>`<span class="calendar-weekday">${day}</span>`).join('');
  const todayIso=refIso(refDate(refIso(today)));
  for(let index=0;index<42;index+=1){
    const date=addRefDays(gridStart,index);
    const iso=refIso(date);
    const classes=['calendar-day'];
    if(date.getMonth()!==monthDate.getMonth()) classes.push('other-month');
    if(iso>uiPeriodDraftStart&&iso<uiPeriodDraftEnd) classes.push('in-range');
    if(iso===uiPeriodDraftStart) classes.push('range-start');
    if(iso===uiPeriodDraftEnd) classes.push('range-end');
    if(iso===todayIso) classes.push('today');
    html+=`<button type="button" class="${classes.join(' ')}" onclick="selectPeriodDate('${iso}')" aria-label="${refSlash(iso)}">${date.getDate()}</button>`;
  }
  document.getElementById(targetId).innerHTML=html;
}

function renderPeriodPicker(){
  document.getElementById('periodDraftStart').textContent=refSlash(uiPeriodDraftStart);
  document.getElementById('periodDraftEnd').textContent=refSlash(uiPeriodDraftEnd);
  document.getElementById('periodStartField').classList.toggle('active',uiPeriodPhase==='start');
  document.getElementById('periodEndField').classList.toggle('active',uiPeriodPhase==='end');
  const secondMonth=new Date(uiPeriodMonthAnchor.getFullYear(),uiPeriodMonthAnchor.getMonth()+1,1);
  renderCalendar('calendarStart','calendarStartTitle',uiPeriodMonthAnchor);
  renderCalendar('calendarEnd','calendarEndTitle',secondMonth);
  document.querySelectorAll('[data-period-shortcut],[data-due-shortcut]').forEach(button=>button.classList.remove('active'));
  if(uiPeriodMode==='due') document.querySelector(`[data-due-shortcut="${uiDueShortcut}"]`)?.classList.add('active');
}

window.applyPeriodDraft=function applyPeriodDraft(){
  const error=document.getElementById('periodPickerError');
  if(!uiPeriodDraftStart||!uiPeriodDraftEnd){error.textContent='Tanggal awal dan akhir wajib dipilih.';return}
  if(uiPeriodDraftStart>uiPeriodDraftEnd){error.textContent='Tanggal awal tidak boleh melewati tanggal akhir.';return}
  if(uiPeriodMode==='period'){
    document.getElementById('periodStart').value=uiPeriodDraftStart;
    document.getElementById('periodEnd').value=uiPeriodDraftEnd;
    document.getElementById('rangeDraftStart').value=uiPeriodDraftStart;
    document.getElementById('rangeDraftEnd').value=uiPeriodDraftEnd;
  }else{
    quickDue=uiDueShortcut==='custom'?'custom':uiDueShortcut;
    if(quickDue==='custom'){
      uiDueStart=uiPeriodDraftStart;
      uiDueEnd=uiPeriodDraftEnd;
    }
  }
  syncQuickFilterUI();
  closeModal('periodModal');
  renderList();
};

window.resetPeriodDraft=function resetPeriodDraft(){
  if(uiPeriodMode==='period'){
    const defaults=refDefaultPeriod();
    uiPeriodDraftStart=defaults.start;
    uiPeriodDraftEnd=defaults.end;
  }else{
    uiDueShortcut='all';
    setDueShortcutDraft('all',false);
  }
  uiPeriodPhase='start';
  uiPeriodMonthAnchor=new Date(refDate(uiPeriodDraftStart).getFullYear(),refDate(uiPeriodDraftStart).getMonth(),1);
  renderPeriodPicker();
};

window.toggleDateRange=function toggleDateRange(){openPeriodPicker('period')};
window.closeDateRange=function closeDateRange(){closeModal('periodModal')};
window.setRangeDraft=function setRangeDraft(){};
window.applyDateRange=function applyDateRange(){applyPeriodDraft()};

window.syncSidebarToggleIcon=function syncSidebarToggleIcon(){
  const app=document.getElementById('appShell');
  const toggle=document.getElementById('sidebarToggle');
  if(!toggle||!app) return;
  const collapsed=app.classList.contains('sidebar-collapsed');
  toggle.innerHTML=`<i class="ti ti-layout-sidebar-left-${collapsed?'expand':'collapse'}" aria-hidden="true"></i>`;
  const label=collapsed?'Perluas sidebar':'Ciutkan sidebar';
  toggle.setAttribute('aria-label',label);
  toggle.setAttribute('title',label);
};
window.toggleSidebar=function toggleSidebar(){
  const app=document.getElementById('appShell');
  const sidebar=document.getElementById('sidebar');
  if(window.innerWidth<=1000) sidebar.classList.toggle('show');
  else app.classList.toggle('sidebar-collapsed');
  syncSidebarToggleIcon();
};

window.setPrototypeRole=function setPrototypeRole(role){
  prototypeRole=role||'owner';
  renderList();
  const roleLabel={owner:'Pemilik Usaha',admin:'Administrator',finance:'Admin Keuangan'}[prototypeRole];
  showToast(`Role prototype diubah menjadi ${roleLabel}.`);
};

window.runPrototypeFlow=function runPrototypeFlow(flow){
  if(flow==='create') openForm();
  else if(flow==='master') openMasterItemPage();
  else if(flow==='import') openImportPage();
  else showPage('list');
};

window.showPage=function showPage(name){
  referenceOriginalShowPage(name);
  const flow=document.getElementById('prototypeFlow');
  const mapped={list:'list',form:'create',master:'master',import:'import'}[name];
  if(flow&&mapped) flow.value=mapped;
  if(window.innerWidth<=1000) document.getElementById('sidebar')?.classList.remove('show');
};


/* The legacy outside-click handler in app.js reads this global. Point it to the new modal. */
window.dateRangePopover=document.getElementById('periodModal');

function initializeReferenceUi(){
  document.getElementById('prototypeRole').value=prototypeRole;
  syncQuickFilterUI();
  renderList();
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initializeReferenceUi,{once:true});
else initializeReferenceUi();

/* ========================================================================== */
/* Biaya parity pass: exact component behavior from purchase/sales reference. */
/* ========================================================================== */

let modalSourceDraft=[];
let expenseMoreOpen=false;

function normalizeSourceSelection(value){
  if(Array.isArray(value)) return value.filter(Boolean);
  if(!value||value==='all') return [];
  return [value];
}
function sourceSelectionLabel(values,allLabel='Semua'){
  const selected=normalizeSourceSelection(values);
  if(!selected.length) return allLabel;
  if(selected.length===1) return selected[0];
  return `${selected.length} sumber data`;
}
function expenseEscape(value){
  return String(value??'').replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
}
function expenseIcon(name){
  const names={back:'arrow-left',print:'printer',pdf:'file-type-pdf',more:'dots',payment:'credit-card-pay',journal:'book-2',mail:'mail',ban:'circle-x',edit:'pencil',trash:'trash',close:'x',view:'eye',repeat:'copy',download:'download',calendar:'calendar-event'};
  return `<i class="ti ti-${names[name]||name} ui-icon" aria-hidden="true"></i>`;
}

window.toggleQuickSourceMenu=function toggleQuickSourceMenu(event){
  event?.stopPropagation();
  const menu=document.getElementById('quickSourcesMenu');
  const trigger=document.getElementById('quickSourcesTrigger');
  if(!menu||!trigger) return;
  const open=!menu.classList.contains('show');
  document.querySelectorAll('.source-multi-menu.show').forEach(node=>node.classList.remove('show'));
  menu.classList.toggle('show',open);
  trigger.setAttribute('aria-expanded',String(open));
  if(open){renderQuickSourceOptions();document.getElementById('quickSourceSearch')?.focus();}
};
window.renderQuickSourceOptions=function renderQuickSourceOptions(){
  const root=document.getElementById('quickFilterSources');
  if(!root) return;
  const query=(document.getElementById('quickSourceSearch')?.value||'').trim().toLowerCase();
  const selected=normalizeSourceSelection(filters.source);
  root.innerHTML=sourceOptions.filter(source=>source.toLowerCase().includes(query)).map(source=>`<label class="check-option"><input type="checkbox" value="${expenseEscape(source)}" ${selected.includes(source)?'checked':''} onchange="toggleQuickSource('${expenseEscape(source)}',this.checked)"><span>${expenseEscape(source)}</span></label>`).join('')||'<div class="multi-empty">Sumber data tidak ditemukan.</div>';
};
window.toggleQuickSource=function toggleQuickSource(source,checked){
  const selected=new Set(normalizeSourceSelection(filters.source));
  checked?selected.add(source):selected.delete(source);
  filters.source=[...selected];
  syncQuickFilterUI();
  renderList();
};
window.toggleModalSourceMenu=function toggleModalSourceMenu(event){
  event?.stopPropagation();
  const menu=document.getElementById('fSourceMenu');
  const trigger=document.getElementById('fSourceTrigger');
  if(!menu||!trigger) return;
  const open=!menu.classList.contains('show');
  document.querySelectorAll('.source-multi-menu.show').forEach(node=>node.classList.remove('show'));
  menu.classList.toggle('show',open);
  trigger.setAttribute('aria-expanded',String(open));
  if(open){renderModalSourceOptions();document.getElementById('fSourceSearch')?.focus();}
};
window.renderModalSourceOptions=function renderModalSourceOptions(){
  const root=document.getElementById('fSourceOptions');
  if(!root) return;
  const query=(document.getElementById('fSourceSearch')?.value||'').trim().toLowerCase();
  root.innerHTML=sourceOptions.filter(source=>source.toLowerCase().includes(query)).map(source=>`<label class="check-option"><input type="checkbox" value="${expenseEscape(source)}" ${modalSourceDraft.includes(source)?'checked':''} onchange="toggleModalSource('${expenseEscape(source)}',this.checked)"><span>${expenseEscape(source)}</span></label>`).join('')||'<div class="multi-empty">Sumber data tidak ditemukan.</div>';
};
window.toggleModalSource=function toggleModalSource(source,checked){
  const selected=new Set(modalSourceDraft);
  checked?selected.add(source):selected.delete(source);
  modalSourceDraft=[...selected];
  const label=document.getElementById('fSourceLabel');
  if(label) label.textContent=sourceSelectionLabel(modalSourceDraft,'Semua Sumber Data');
};

function expenseDueLabel(){
  return uiDueStart&&uiDueEnd?`${refSlash(uiDueStart)} - ${refSlash(uiDueEnd)}`:'Semua';
}
window.syncQuickFilterUI=function syncQuickFilterUI(){
  filters.source=normalizeSourceSelection(filters.source);
  const payment=document.getElementById('quickPaymentStatus');
  if(payment) payment.value=filters.pay?.length===1?filters.pay[0]:'all';
  const quickSourceLabel=document.getElementById('quickSourcesLabel');
  if(quickSourceLabel) quickSourceLabel.textContent=sourceSelectionLabel(filters.source,'Semua');
  const dueText=document.getElementById('quickDueLabel');
  if(dueText) dueText.textContent=expenseDueLabel();
  const dueStartNode=document.getElementById('dueStart');
  const dueEndNode=document.getElementById('dueEnd');
  if(dueStartNode) dueStartNode.value=uiDueStart||'';
  if(dueEndNode) dueEndNode.value=uiDueEnd||'';
  const modalPeriod=document.getElementById('fPeriodLabel');
  if(modalPeriod) modalPeriod.textContent=`${refSlash(document.getElementById('periodStart')?.value)} - ${refSlash(document.getElementById('periodEnd')?.value)}`;
  const modalDue=document.getElementById('fDueLabel');
  if(modalDue) modalDue.textContent=expenseDueLabel();
  syncDateRangeLabel();
  renderQuickSourceOptions();
  populateFilterOptions();
};
window.setSourceFilter=function setSourceFilter(value){
  filters.source=value==='all'?[]:[value];
  syncQuickFilterUI();
  renderList();
};
window.quickDueMatches=function quickDueMatches(expense){
  if(!uiDueStart||!uiDueEnd) return true;
  if(!expense.due) return false;
  return expense.due>=uiDueStart&&expense.due<=uiDueEnd;
};
window.filteredBase=function filteredBase(){
  const start=document.getElementById('periodStart').value;
  const end=document.getElementById('periodEnd').value;
  const sources=normalizeSourceSelection(filters.source);
  return expenses.filter(expense=>{
    const transactionDate=expense.date.slice(0,10);
    const source=expense.sourceData||'Perusahaan';
    return transactionDate>=start&&transactionDate<=end&&
      quickDueMatches(expense)&&
      (!sources.length||sources.includes(source))&&
      matchesMulti(filters.pay,expense.payStatus)&&
      matchesMulti(filters.contact,expense.contact)&&
      (!filters.item.length||expense.items.some(item=>filters.item.includes(item.item)))&&
      (!filters.expense.length||expense.items.some(item=>filters.expense.includes(item.coa)))&&
      (!filters.account.length||expense.payments.some(payment=>filters.account.includes(payment.account)));
  });
};
window.syncFilterModal=function syncFilterModal(){
  modalSourceDraft=normalizeSourceSelection(filters.source);
  const sourceLabel=document.getElementById('fSourceLabel');
  if(sourceLabel) sourceLabel.textContent=sourceSelectionLabel(modalSourceDraft,'Semua Sumber Data');
  const periodLabel=document.getElementById('fPeriodLabel');
  if(periodLabel) periodLabel.textContent=`${refSlash(document.getElementById('periodStart').value)} - ${refSlash(document.getElementById('periodEnd').value)}`;
  const dueLabelNode=document.getElementById('fDueLabel');
  if(dueLabelNode) dueLabelNode.textContent=expenseDueLabel();
  renderModalSourceOptions();
  populateFilterOptions();
};
window.applyFilter=function applyFilter(){
  filters={
    ...filters,
    source:normalizeSourceSelection(filters.source),
    pay:Array.isArray(filters.pay)?[...filters.pay]:[],
    contact:checkedValues('fVendorOptions'),
    item:checkedValues('fItemOptions'),
    expense:checkedValues('fExpenseOptions'),
    due:'all',
    account:checkedValues('fAccountOptions')
  };
  syncQuickFilterUI();
  closeModal('filterModal');
  renderList();
};
window.resetFilter=function resetFilter(){
  filters={
    ...filters,
    source:normalizeSourceSelection(filters.source),
    pay:Array.isArray(filters.pay)?[...filters.pay]:[],
    contact:[],
    item:[],
    expense:[],
    due:'all',
    account:[]
  };
  selected.clear();
  syncQuickFilterUI();
  syncFilterModal();
  renderList();
};
window.resetQuickFilters=function resetQuickFilters(){
  resetFilter();
  activeTab='Terbit';
  const query=document.getElementById('searchInput');
  if(query) query.value='';
  closeModal('filterModal');
  renderList();
};

window.openPeriodPicker=function openPeriodPicker(mode){
  uiPeriodMode=mode==='due'?'due':'period';
  uiPeriodPhase='start';
  document.getElementById('periodShortcutList').hidden=false;
  document.getElementById('dueShortcutList').hidden=true;
  document.getElementById('periodStartLabel').innerHTML=`${uiPeriodMode==='due'?'Jatuh Tempo Awal':'Periode Awal'} <span class="required-mark">*</span>`;
  document.getElementById('periodEndLabel').innerHTML=`${uiPeriodMode==='due'?'Jatuh Tempo Akhir':'Periode Akhir'} <span class="required-mark">*</span>`;
  if(uiPeriodMode==='period'){
    uiPeriodDraftStart=document.getElementById('periodStart').value;
    uiPeriodDraftEnd=document.getElementById('periodEnd').value;
  }else{
    const base=refDate(refIso(today));
    uiPeriodDraftStart=uiDueStart||refIso(base);
    uiPeriodDraftEnd=uiDueEnd||refIso(base);
  }
  uiPeriodMonthAnchor=new Date(refDate(uiPeriodDraftStart).getFullYear(),refDate(uiPeriodDraftStart).getMonth(),1);
  document.getElementById('periodPickerError').textContent='';
  renderPeriodPicker();
  openModal('periodModal');
};
window.setPeriodShortcut=function setPeriodShortcut(key){
  const base=refDate(refIso(today));
  if(key==='today') uiPeriodDraftStart=uiPeriodDraftEnd=refIso(base);
  if(key==='week'){uiPeriodDraftStart=refIso(addRefDays(base,-6));uiPeriodDraftEnd=refIso(base);}
  if(key==='month'){uiPeriodDraftStart=refIso(addRefMonths(base,-1));uiPeriodDraftEnd=refIso(base);}
  if(key==='quarter'){uiPeriodDraftStart=refIso(addRefMonths(base,-3));uiPeriodDraftEnd=refIso(base);}
  if(key==='year'){uiPeriodDraftStart=refIso(refStartOfYear(base));uiPeriodDraftEnd=refIso(base);}
  if(key==='custom') uiPeriodPhase='start';
  uiPeriodMonthAnchor=new Date(refDate(uiPeriodDraftStart).getFullYear(),refDate(uiPeriodDraftStart).getMonth(),1);
  renderPeriodPicker();
  document.querySelector(`[data-period-shortcut="${key}"]`)?.classList.add('active');
};
window.applyPeriodDraft=function applyPeriodDraft(){
  const error=document.getElementById('periodPickerError');
  if(!uiPeriodDraftStart||!uiPeriodDraftEnd){error.textContent='Tanggal awal dan akhir wajib dipilih.';return;}
  if(uiPeriodDraftStart>uiPeriodDraftEnd){error.textContent='Tanggal awal tidak boleh melewati tanggal akhir.';return;}
  if(uiPeriodMode==='period'){
    document.getElementById('periodStart').value=uiPeriodDraftStart;
    document.getElementById('periodEnd').value=uiPeriodDraftEnd;
    document.getElementById('rangeDraftStart').value=uiPeriodDraftStart;
    document.getElementById('rangeDraftEnd').value=uiPeriodDraftEnd;
  }else{
    uiDueStart=uiPeriodDraftStart;
    uiDueEnd=uiPeriodDraftEnd;
    quickDue='custom';
  }
  syncQuickFilterUI();
  syncFilterModal();
  closeModal('periodModal');
  renderList();
};
window.resetPeriodDraft=function resetPeriodDraft(){
  if(uiPeriodMode==='due'){
    uiDueStart='';
    uiDueEnd='';
    quickDue='all';
    syncQuickFilterUI();
    syncFilterModal();
    closeModal('periodModal');
    renderList();
    return;
  }
  const defaults=refDefaultPeriod();
  uiPeriodDraftStart=defaults.start;
  uiPeriodDraftEnd=defaults.end;
  uiPeriodPhase='start';
  uiPeriodMonthAnchor=new Date(refDate(uiPeriodDraftStart).getFullYear(),refDate(uiPeriodDraftStart).getMonth(),1);
  renderPeriodPicker();
};

window.renderList=function renderList(){
  filters.source=normalizeSourceSelection(filters.source);
  const base=filteredBase();
  const query=(document.getElementById('searchInput')?.value||'').trim().toLowerCase();
  const context=query?base.filter(expense=>`${expense.code} ${expense.sourceData||'Perusahaan'} ${expense.title} ${expense.contact} ${expense.items.map(item=>item.item).join(' ')}`.toLowerCase().includes(query)):base;
  renderTabs(context);
  const data=context.filter(expense=>expense.status===activeTab).sort((a,b)=>b.date.localeCompare(a.date));
  const issued=context.filter(expense=>expense.status==='Terbit');
  const total=issued.reduce((sum,expense)=>sum+(totalOf(expense)-pphOf(expense)),0);
  const gross=issued.reduce((sum,expense)=>sum+expense.items.reduce((itemSum,item)=>itemSum+Number(item.amount||0),0),0);
  const ppn=issued.reduce((sum,expense)=>sum+ppnOf(expense),0);
  const pph=issued.reduce((sum,expense)=>sum+pphOf(expense),0);
  const paid=issued.reduce((sum,expense)=>sum+Math.min(Number(expense.paid||0),totalOf(expense)-pphOf(expense)),0);
  const remaining=issued.reduce((sum,expense)=>sum+remainingOf(expense),0);
  const overdue=issued.filter(expense=>expense.due&&new Date(expense.due+'T23:59:59')<today&&expense.payStatus!=='Lunas');

  document.getElementById('sumTotal').textContent=rupiah(total);
  document.getElementById('sumTotalSub').textContent=`Pokok ${rupiah(gross)} • PPN ${rupiah(ppn)} • PPh ${rupiah(pph)}`;
  document.getElementById('paidRatio').textContent=`${total?Math.round(paid/total*100):0}%`;
  document.getElementById('debtRatio').textContent=`${total?Math.round(remaining/total*100):0}%`;
  document.getElementById('paidRatioNominal').textContent=rupiah(paid);
  document.getElementById('debtRatioNominal').textContent=rupiah(remaining);
  document.getElementById('sumOverdue').textContent=rupiah(overdue.reduce((sum,expense)=>sum+remainingOf(expense),0));
  document.getElementById('sumOverdueCount').textContent=`${overdue.length} transaksi`;

  const rowTarget=document.getElementById('rows');
  rowTarget.innerHTML=data.length?data.map(expense=>`<tr><td><input type="checkbox" ${selected.has(expense.id)?'checked':''} onchange="toggleSelect(${expense.id},this.checked)"></td><td>${dateTimeStack(expense.date)}</td><td><button class="table-link" type="button" onclick="openDetail(${expense.id})">${expenseEscape(expense.code)}</button></td><td>${expenseEscape(expense.sourceData||'Perusahaan')}</td><td><span class="vendor-link">${expenseEscape(expense.contact||'-')}</span></td><td class="due-cell ${dueToneClass(expense)}" title="${expenseEscape(dueToneLabel(expense))}">${expense.due?fmtDate(expense.due):'-'}</td><td class="total-strong">${rupiah(totalOf(expense)-pphOf(expense))}</td><td>${rupiah(remainingOf(expense))}</td><td><span class="badge ${expense.payStatus==='Lunas'?'lunas':expense.payStatus==='Dibayar Sebagian'?'partial':'unpaid'}">${expenseEscape(expense.payStatus)}</span></td><td class="actions"><button class="kebab row-kebab" aria-expanded="false" onclick="toggleMenu(event,${expense.id})" aria-label="Buka aksi"><i class="ti ti-dots" aria-hidden="true"></i></button><div class="menu" id="menu${expense.id}">${actionMenu(expense)}</div></td></tr>`).join(''):`<tr><td colspan="10"><div class="empty">Tidak ada data sesuai pencarian atau filter.</div></td></tr>`;

  const bulk=document.getElementById('bulkBar');
  bulk.classList.toggle('show',selected.size>0);
  document.getElementById('bulkText').textContent=`${selected.size} transaksi dipilih`;
  const selectAllNode=document.getElementById('selectAll');
  selectAllNode.checked=data.length>0&&data.every(expense=>selected.has(expense.id));

  const defaults=refDefaultPeriod();
  const customPeriod=document.getElementById('periodStart').value!==defaults.start||document.getElementById('periodEnd').value!==defaults.end;
  const activeCount=[filters.contact.length>0,filters.item.length>0,filters.expense.length>0,filters.account.length>0].filter(Boolean).length;
  const filterButton=document.getElementById('filterBtn');
  filterButton.innerHTML=activeCount?`<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter (${activeCount})`:'<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter';
  filterButton.className='btn '+(activeCount?'btn-soft':'btn-secondary');
  const resetButton=document.getElementById('resetFilterButton');
  if(resetButton) resetButton.disabled=activeCount===0&&activeTab==='Terbit'&&!query;
  syncQuickFilterUI();
};


function expenseStatusBadge(value){
  const className=value==='Terbit'?'terbit':value==='Lunas'?'lunas':value==='Dibayar Sebagian'?'partial':value==='Belum Dibayar'?'unpaid':String(value).toLowerCase();
  return `<span class="badge ${className}">${expenseEscape(value)}</span>`;
}
function expenseInfo(label,value){
  return `<div class="pd-info"><div class="pd-info-label">${expenseEscape(label)}</div><div class="pd-info-value">${expenseEscape(value||'—')}</div></div>`;
}
function expenseVendorSnapshot(expense){
  const vendor=getVendorDetail(expense.contact)||{};
  return {name:expense.contact||'—',phone:vendor.phone||'—',email:vendor.email||'—',address:vendor.address||'—',bank:vendor.bank||'—',account:vendor.account||'—',holder:vendor.holder||'—'};
}
function expensePaymentReference(expense,payment,index){
  const date=String(payment.date||expense.date||'').replace(/\D/g,'').slice(0,8)||'20260701';
  return `PB-${date}-${String(index+1).padStart(3,'0')}`;
}
function expensePaymentMethod(payment){
  const account=String(payment.account||'');
  return /kas|cash|tunai/i.test(account)?'Tunai':'Transfer';
}
function expenseItemRows(expense){
  return expense.items.map(item=>{
    const taxType=taxTypeOf(item);
    const taxAmount=taxType==='ppn11'?ppnItemOf(item):taxType==='pph10'?pphItemOf(item):0;
    const taxLabel=taxType==='ppn11'?`PPN 11% · ${rupiah(taxAmount)}`:taxType==='pph10'?`PPh 10% · ${rupiah(taxAmount)}`:'Rp 0';
    const itemTotal=Number(item.amount||0)+(taxType==='ppn11'?taxAmount:0)-(taxType==='pph10'?taxAmount:0);
    return `<tr><td><strong>${expenseEscape(item.item)}</strong></td><td>1</td><td>—</td><td class="amount">${rupiah(item.amount)}</td><td class="amount">Rp 0</td><td class="amount">${expenseEscape(taxLabel)}</td><td>${expenseEscape(item.desc||'—')}</td><td class="amount strong-amount">${rupiah(itemTotal)}</td></tr>`;
  }).join('');
}
function expensePaymentHistory(expense){
  if(!expense.payments?.length) return `<div class="pd-empty"><div class="pd-empty-icon">${expenseIcon('payment')}</div><strong>Belum ada pembayaran</strong><span>Pembayaran akan muncul setelah dicatat.</span></div>`;
  return `<div class="pd-table-wrap"><table class="pd-table payment-history-table"><thead><tr><th>Referensi</th><th>Tanggal</th><th>Nominal</th><th>Metode Pembayaran</th></tr></thead><tbody>${expense.payments.map((payment,index)=>`<tr><td><button type="button" class="payment-ref" onclick="showToast('Detail pembayaran ${expensePaymentReference(expense,payment,index)} dibuka (simulasi).')">${expensePaymentReference(expense,payment,index)}</button></td><td>${fmtDate(payment.date)}</td><td class="amount">${rupiah(payment.amount)}</td><td><span class="payment-method">${expensePaymentMethod(payment)}</span></td></tr>`).join('')}</tbody></table></div>`;
}
function expenseAttachments(expense){
  const transactionFiles=expense.attachments?.length?expense.attachments.map(file=>`<div class="pd-file"><div class="pd-file-copy"><strong>${expenseEscape(file)}</strong><span>Lampiran transaksi</span></div><button type="button" class="pd-icon-button" onclick="showToast('Preview ${expenseEscape(file)} dibuka (simulasi).')">${expenseIcon('view')}Lihat</button></div>`).join(''):'<div class="pd-empty compact"><strong>Belum ada lampiran transaksi</strong></div>';
  const paymentFiles=expense.payments?.filter(payment=>payment.evidence).length?expense.payments.filter(payment=>payment.evidence).map(payment=>`<div class="pd-file"><div class="pd-file-copy"><strong>${expenseEscape(payment.evidence)}</strong><span>${fmtDate(payment.date)} · ${rupiah(payment.amount)}</span></div><button type="button" class="pd-icon-button" onclick="showToast('Preview ${expenseEscape(payment.evidence)} dibuka (simulasi).')">${expenseIcon('view')}Lihat</button></div>`).join(''):'<div class="pd-empty compact"><strong>Belum ada bukti pembayaran</strong></div>';
  return `<section class="pd-section"><div class="pd-section-head"><div><h2 class="pd-section-title">Lampiran &amp; Bukti Pembayaran</h2><div class="pd-section-sub">File pendukung yang tersimpan pada transaksi.</div></div></div><div class="pd-attachment-grid"><div><h3 class="pd-subgroup-title">Lampiran Transaksi</h3>${transactionFiles}</div><div><h3 class="pd-subgroup-title">Bukti Pembayaran</h3>${paymentFiles}</div></div></section>`;
}
function expenseMoreMenu(expense){
  const items=[`<button type="button" onclick="openPrint(${expense.id})">${expenseIcon('print')}<span>Cetak Nota</span></button>`];
  if(expense.status==='Terbit'&&prototypeRole!=='finance') items.push(`<button class="danger" type="button" onclick="askVoid(${expense.id})">${expenseIcon('ban')}<span>Void</span></button>`);
  return `<div class="pd-more-wrap"><button class="pd-more-btn" type="button" onclick="toggleExpenseMoreMenu(event)" aria-haspopup="menu" aria-expanded="false" aria-label="Buka aksi tambahan">${expenseIcon('more')}</button><div class="pd-more-menu" id="expenseMoreMenu" role="menu">${items.join('')}</div></div>`;
}
function expenseDetailActions(expense){
  if(expense.status==='Draft'){
    return `<button class="btn btn-secondary" type="button" onclick="openForm(${expense.id})">${expenseIcon('edit')}Edit Draft</button><button class="btn btn-danger" type="button" onclick="askDelete(${expense.id})">${expenseIcon('trash')}Hapus Draft</button>${expenseMoreMenu(expense)}`;
  }
  const journalAction=`<button class="btn btn-secondary" type="button" onclick="openJournalFromExpense()">${expenseIcon('journal')}Lihat Jurnal</button>`;
  if(expense.status==='Terbit'&&(expense.payStatus==='Belum Dibayar'||expense.payStatus==='Dibayar Sebagian')){
    return `<button class="btn btn-primary" type="button" onclick="openPayment(${expense.id})">${expenseIcon('payment')}Catat Pembayaran</button>${journalAction}${expenseMoreMenu(expense)}`;
  }
  if(expense.status==='Terbit'&&expense.payStatus==='Lunas'){
    return `<button class="btn btn-primary" type="button" onclick="openRepeatForm(${expense.id})">${expenseIcon('repeat')}Catat Lagi</button>${journalAction}${expenseMoreMenu(expense)}`;
  }
  return `${journalAction}${expenseMoreMenu(expense)}`;
}
function renderExpenseDetail(expense){
  if(!expense) return '<div class="pd-empty"><strong>Transaksi tidak ditemukan.</strong></div>';
  const vendor=expenseVendorSnapshot(expense);
  const total=totalOf(expense)-pphOf(expense);
  const paid=Number(expense.paid||0);
  const remaining=remainingOf(expense);
  const lastPayment=expense.payments?.length?expense.payments[expense.payments.length-1]:null;
  const paymentSectionAction=expense.status==='Terbit'?(expense.payStatus==='Lunas'?`<button class="btn btn-secondary" type="button" onclick="openRepeatForm(${expense.id})">${expenseIcon('repeat')}Catat Lagi</button>`:`<button class="btn btn-primary" type="button" onclick="openPayment(${expense.id})">${expenseIcon('payment')}Catat Pembayaran</button>`):'';
  const paymentInfo=expense.status==='Draft'?'':`<section class="pd-section"><div class="pd-section-head"><div><h2 class="pd-section-title">Informasi Pembayaran</h2><div class="pd-section-sub">Kondisi tagihan dan pembayaran terakhir.</div></div>${paymentSectionAction}</div><div class="pd-info-grid">${expenseInfo('Status Pembayaran',expense.payStatus)}${expenseInfo('Total Tagihan',rupiah(total))}${expenseInfo('Total Pembayaran',rupiah(paid))}${expenseInfo('Sisa Tagihan',rupiah(remaining))}${expenseInfo('Tanggal Jatuh Tempo',expense.due?fmtDate(expense.due):'—')}${expenseInfo('Metode Pembayaran Terakhir',lastPayment?expensePaymentMethod(lastPayment):'—')}${expenseInfo('Kas / Rekening Sumber',lastPayment?.account||'—')}${expenseInfo('Rekening Vendor',vendor.account)}</div></section>`;
  const paymentHistory=expense.status==='Draft'?'':`<section class="pd-section"><div class="pd-section-head"><div><h2 class="pd-section-title">Riwayat Pembayaran</h2><div class="pd-section-sub">Pembayaran yang sudah tercatat tidak dapat dihapus dari halaman detail.</div></div></div>${expensePaymentHistory(expense)}</section>`;
  const voidInfo=expense.status==='Void'?`<section class="pd-section"><div class="pd-section-head"><div><h2 class="pd-section-title">Informasi Void</h2><div class="pd-section-sub">Transaksi tetap tersedia sebagai histori.</div></div></div><div class="pd-info-grid">${expenseInfo('Alasan Void',expense.voidReason||'—')}${expenseInfo('Status Dokumen','Void')}</div></section>`:'';
  return `<div class="pd-shell">
    <section class="card pd-hero"><div class="pd-hero-top"><div class="pd-title-wrap"><button class="pd-back" type="button" onclick="showPage('list')" aria-label="Kembali ke Daftar Biaya">${expenseIcon('back')}</button><div><h1 class="pd-heading">Detail Biaya</h1><div class="pd-code">${expenseEscape(expense.code)}</div><div class="pd-badges"><div class="pd-badge-group"><span class="pd-badge-label">Status Dokumen</span>${expenseStatusBadge(expense.status)}</div><div class="pd-badge-group"><span class="pd-badge-label">Status Pembayaran</span>${expenseStatusBadge(expense.payStatus)}</div></div></div></div><div class="pd-actions">${expenseDetailActions(expense)}</div></div></section>
    <section class="card pd-group"><div class="pd-group-content">
      <section class="pd-section"><div class="pd-section-head"><div><h2 class="pd-section-title">Informasi Nota</h2><div class="pd-section-sub">Informasi transaksi bersifat read-only.</div></div></div><div class="pd-info-grid">${expenseInfo('Sumber Data',expense.sourceData||'Perusahaan')}${expenseInfo('ID Transaksi Biaya',expense.code)}${expenseInfo('Keterangan',expense.title)}${expenseInfo('Tanggal Transaksi',fmtDate(expense.date))}${expenseInfo('Pembuat Transaksi',expense.createdBy)}</div></section>
      <section class="pd-section"><div class="pd-section-head"><div><h2 class="pd-section-title">Informasi Vendor</h2><div class="pd-section-sub">Data yang digunakan saat transaksi dibuat.</div></div></div><div class="pd-info-grid">${expenseInfo('Nama',vendor.name)}${expenseInfo('No. HP/WA Utama',vendor.phone)}${expenseInfo('Email',vendor.email)}${expenseInfo('Alamat',vendor.address)}${expenseInfo('Nama Bank',vendor.bank)}${expenseInfo('Nomor Rekening',vendor.account)}${expenseInfo('Nama Pemilik Rekening',vendor.holder)}</div></section>
      <section class="pd-section"><div class="pd-section-head"><div><h2 class="pd-section-title">Produk</h2><div class="pd-section-sub">Rincian item hanya dapat dilihat.</div></div></div><div class="pd-table-wrap"><table class="pd-table"><thead><tr><th>Produk</th><th>Jumlah</th><th>Satuan</th><th>Harga Beli</th><th>Diskon</th><th>Pajak</th><th>Catatan</th><th>Total Item</th></tr></thead><tbody>${expenseItemRows(expense)}</tbody></table></div></section>
      ${paymentInfo}${paymentHistory}${voidInfo}${expenseAttachments(expense)}
    </div></section>
  </div>`;
}
window.openDetail=function openDetail(id){
  currentDetailId=id;
  const expense=expenses.find(item=>item.id===id);
  document.getElementById('detailPage').innerHTML=renderExpenseDetail(expense);
  showPage('detail');
  closeExpenseMoreMenu();
};
window.toggleExpenseMoreMenu=function toggleExpenseMoreMenu(event){
  event?.stopPropagation();
  const menu=document.getElementById('expenseMoreMenu');
  const button=event?.currentTarget;
  if(!menu) return;
  expenseMoreOpen=!menu.classList.contains('show');
  menu.classList.toggle('show',expenseMoreOpen);
  button?.setAttribute('aria-expanded',String(expenseMoreOpen));
};
window.closeExpenseMoreMenu=function closeExpenseMoreMenu(){
  expenseMoreOpen=false;
  document.getElementById('expenseMoreMenu')?.classList.remove('show');
  document.querySelector('.pd-more-btn')?.setAttribute('aria-expanded','false');
};
window.openJournalFromExpense=function openJournalFromExpense(){
  const expense=expenses.find(item=>item.id===currentDetailId);
  if(!expense||expense.status==='Draft'){showToast('Jurnal belum tersedia untuk Draft.','error');return;}
  const groups=journalGroups(expense);
  document.getElementById('journalModalSubtitle').textContent=`${expense.code} · ${expense.sourceData||'Perusahaan'}`;
  document.getElementById('journalModalBody').innerHTML=groups.map(group=>`<section class="journal-modal-group"><div class="journal-modal-head"><div><strong>${expenseEscape(group.type)}</strong><span>${expenseEscape(group.id)} · ${expenseEscape(group.date)}</span></div></div><div class="pd-table-wrap"><table class="pd-table journal-table"><thead><tr><th>Akun</th><th>Debit</th><th>Kredit</th></tr></thead><tbody>${group.lines.map(line=>`<tr><td>${expenseEscape(line.account)}</td><td class="amount">${line.debit?rupiah(line.debit):'—'}</td><td class="amount">${line.credit?rupiah(line.credit):'—'}</td></tr>`).join('')}</tbody></table></div></section>`).join('')||'<div class="pd-empty"><strong>Jurnal tidak tersedia.</strong></div>';
  closeExpenseMoreMenu();
  openModal('journalModal');
};

document.addEventListener('click',event=>{
  if(!event.target.closest('.source-multi-select')){
    document.querySelectorAll('.source-multi-menu.show').forEach(menu=>menu.classList.remove('show'));
    document.querySelectorAll('.source-multi-select .select-trigger').forEach(trigger=>trigger.setAttribute('aria-expanded','false'));
  }
  if(!event.target.closest('.pd-more-wrap')) closeExpenseMoreMenu();
});

function initializeExpenseParity(){
  filters.source=normalizeSourceSelection(filters.source);
  uiDueStart=document.getElementById('dueStart')?.value||'';
  uiDueEnd=document.getElementById('dueEnd')?.value||'';
  syncQuickFilterUI();
  renderList();
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initializeExpenseParity,{once:true});
else initializeExpenseParity();

