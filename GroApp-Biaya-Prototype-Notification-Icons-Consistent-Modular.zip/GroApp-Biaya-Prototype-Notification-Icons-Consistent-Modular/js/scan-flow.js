(function(){
  const previousOpenPayment = window.openPayment;
  const previousCloseModal = window.closeModal;
  window.expenseScanState = {open:false,mode:'invoice',view:'permission',permission:'prompt',fileName:'',sourceType:'camera',file:null};

  function scanModeLabel(){return expenseScanState.mode==='invoice'?'nota':'bukti pembayaran'}
  function scanModeTitle(){return expenseScanState.mode==='invoice'?'NOTA VENDOR':'BUKTI TRANSFER'}
  function safeFileName(file,fallback){return String(file?.name||fallback||'dokumen').replace(/[<>]/g,'')}
  function scanFileMeta(name,file){return {status:'done',progress:100,size:Number(file?.size||0),type:file?.type||''}}
  function currentTimestampValue(){return typeof localDateTimeValue==='function'?localDateTimeValue():new Date().toISOString().slice(0,16)}

  window.openExpenseScan=function(mode){
    expenseScanState={open:true,mode:mode||'invoice',view:expenseScanState.permission==='granted'?'camera':expenseScanState.permission==='denied'?'denied':'permission',permission:expenseScanState.permission,fileName:'',sourceType:'camera',file:null};
    document.getElementById('expenseScanBackdrop')?.classList.add('show');
    document.body.classList.add('expense-scan-lock');
    renderExpenseScan();
  };
  window.closeExpenseScan=function(){
    document.getElementById('expenseScanBackdrop')?.classList.remove('show');
    document.body.classList.remove('expense-scan-lock');
    expenseScanState.open=false;
  };
  window.renderExpenseScan=function(){
    const shell=document.getElementById('expenseScanShell');
    if(!shell)return;
    if(expenseScanState.view==='permission'){
      shell.innerHTML=`<div class="expense-scan-camera"></div><div class="expense-scan-state"><div class="expense-scan-state-icon"><i class="ti ti-camera"></i></div><h2>Izinkan GroApp mengakses Kamera?</h2><p>Kamera digunakan untuk mengambil foto ${scanModeLabel()}. Anda tetap dapat menggunakan Galeri atau PDF.</p><div class="modal-actions"><button class="btn btn-secondary" type="button" onclick="denyExpenseCamera()">Jangan Izinkan</button><button class="btn btn-primary" type="button" onclick="allowExpenseCamera()">Izinkan</button></div></div>`;return;
    }
    if(expenseScanState.view==='denied'){
      shell.innerHTML=`<div class="expense-scan-camera"></div><div class="expense-scan-state"><div class="expense-scan-state-icon"><i class="ti ti-camera-off"></i></div><h2>Akses kamera belum tersedia</h2><p>Aktifkan melalui pengaturan perangkat, atau lanjutkan menggunakan Galeri/PDF agar proses tidak terhenti.</p><div class="modal-actions"><button class="btn btn-secondary" type="button" onclick="simulateExpenseCameraSettings()">Aktifkan di Pengaturan</button><button class="btn btn-secondary" type="button" onclick="pickExpenseScanGallery()"><i class="ti ti-photo"></i>Galeri</button><button class="btn btn-secondary" type="button" onclick="pickExpenseScanPdf()"><i class="ti ti-file-type-pdf"></i>Upload PDF</button><button class="btn btn-secondary" type="button" onclick="closeExpenseScan()">Batal</button></div></div>`;return;
    }
    if(expenseScanState.view==='camera'){
      shell.innerHTML=`<div class="expense-scan-camera"></div><div class="expense-scan-top"><button class="expense-scan-round" type="button" onclick="closeExpenseScan()" aria-label="Tutup"><i class="ti ti-x"></i></button><button class="expense-scan-round" type="button" onclick="showToast('Flash diubah (simulasi).','info')" aria-label="Flash"><i class="ti ti-bolt"></i></button></div><div class="expense-scan-frame"><div class="expense-fake-receipt"><strong>${scanModeTitle()}</strong>${Array.from({length:13},(_,i)=>`<div class="expense-receipt-line ${i%3===0?'short':i%4===0?'medium':''}"></div>`).join('')}</div></div><div class="expense-scan-hint">Posisikan ${scanModeLabel()} dalam bingkai</div><div class="expense-scan-controls"><button class="expense-scan-control" type="button" onclick="pickExpenseScanGallery()"><span><i class="ti ti-photo"></i></span>Galeri</button><button class="expense-scan-shutter" type="button" onclick="captureExpenseScanPhoto()" aria-label="Ambil foto"></button><button class="expense-scan-control" type="button" onclick="pickExpenseScanPdf()"><span>PDF</span>Upload PDF</button></div>`;return;
    }
    if(expenseScanState.view==='preview'){
      shell.innerHTML=`<div class="expense-scan-preview"><div class="expense-scan-file-pill">${expenseEscape(expenseScanState.fileName||scanModeLabel())}</div><div class="expense-fake-receipt"><strong>${scanModeTitle()}</strong>${Array.from({length:14},(_,i)=>`<div class="expense-receipt-line ${i%3===0?'short':''}"></div>`).join('')}</div><div class="expense-scan-preview-actions"><button class="btn btn-secondary" type="button" onclick="retakeExpenseScanPhoto()">Ambil Ulang</button><button class="btn btn-primary" type="button" onclick="processExpenseScan()">Gunakan Dokumen</button></div></div>`;return;
    }
    if(expenseScanState.view==='processing'){
      shell.innerHTML=`<div class="expense-scan-camera"></div><div class="expense-scan-state"><div class="expense-scan-spinner"></div><h2>Membaca ${scanModeLabel()}…</h2><p>Sistem sedang mengekstrak informasi. Hasil tetap dapat diperiksa dan disesuaikan sebelum transaksi diterbitkan.</p></div>`;return;
    }
    if(expenseScanState.view==='error'){
      shell.innerHTML=`<div class="expense-scan-camera"></div><div class="expense-scan-state"><div class="expense-scan-state-icon"><i class="ti ti-alert-triangle"></i></div><h2>Gagal membaca dokumen</h2><p>Coba ambil ulang foto atau upload file lain. Data yang sudah ada pada form tidak berubah.</p><div class="modal-actions"><button class="btn btn-secondary" type="button" onclick="closeExpenseScan()">Batal</button><button class="btn btn-primary" type="button" onclick="retryExpenseScan()">Coba Lagi</button><button class="btn btn-secondary" type="button" onclick="manualAfterExpenseScan()">Input Manual</button></div></div>`;
    }
  };
  window.allowExpenseCamera=function(){expenseScanState.permission='granted';expenseScanState.view='camera';renderExpenseScan()};
  window.denyExpenseCamera=function(){expenseScanState.permission='denied';expenseScanState.view='denied';renderExpenseScan()};
  window.simulateExpenseCameraSettings=function(){expenseScanState.permission='granted';expenseScanState.view='camera';showToast('Akses kamera diaktifkan (simulasi).','info');renderExpenseScan()};
  window.captureExpenseScanPhoto=function(){
    const name=`${expenseScanState.mode==='invoice'?'Foto-nota':'Bukti-pembayaran'}-${Date.now()}.jpg`;
    try{expenseScanState.file=new File([new Blob(['prototype-image'],{type:'image/jpeg'})],name,{type:'image/jpeg'});}catch(error){expenseScanState.file={name,type:'image/jpeg',size:1024};}
    expenseScanState.fileName=name;expenseScanState.sourceType='camera';expenseScanState.view='preview';renderExpenseScan();
  };
  window.retakeExpenseScanPhoto=function(){expenseScanState.view='camera';renderExpenseScan()};
  window.pickExpenseScanGallery=function(){expenseScanState.sourceType='gallery';document.getElementById('expenseScanGalleryInput')?.click()};
  window.pickExpenseScanPdf=function(){expenseScanState.sourceType='pdf';document.getElementById('expenseScanPdfInput')?.click()};
  window.handleExpenseScanFile=function(files,type){
    const file=files?.[0];if(!file)return;
    const isPdf=file.type==='application/pdf'||/\.pdf$/i.test(file.name||'');
    const isImage=String(file.type||'').startsWith('image/')||/\.(png|jpe?g|webp)$/i.test(file.name||'');
    if(type==='pdf'&&!isPdf){showToast('File harus berformat PDF.','error');return}
    if(type==='gallery'&&!isImage){showToast('Galeri hanya menerima JPG, PNG, atau WebP.','error');return}
    if(file.size>10*1024*1024){showToast('Ukuran dokumen maksimal 10 MB.','error');return}
    expenseScanState.file=file;expenseScanState.fileName=safeFileName(file);expenseScanState.sourceType=type;expenseScanState.view='preview';renderExpenseScan();
  };
  window.processExpenseScan=function(){
    expenseScanState.view='processing';renderExpenseScan();
    setTimeout(()=>{if(String(expenseScanState.fileName||'').toLowerCase().includes('gagal')){expenseScanState.view='error';renderExpenseScan();return}applyExpenseScanResult()},1100);
  };
  function addScanToTransactionAttachments(file,name){
    if(!formState)return;
    formState.attachments=formState.attachments||[];
    if(formState.attachments.includes(name))return;
    if(formState.attachments.length>=5){showToast('Lampiran sudah mencapai batas maksimal 5 file.','error');return}
    formState.attachments.push(name);expenseUploadState[name]=scanFileMeta(name,file);
  }
  function setSinglePaymentEvidence(file,name){
    if(!formState)return;
    formState.evidenceFiles=[name];paymentEvidenceState={};paymentEvidenceErrors=[];paymentEvidenceState[name]=scanFileMeta(name,file);
  }
  window.applyExpenseScanResult=function(){
    const file=expenseScanState.file;const name=safeFileName(file,expenseScanState.fileName||`${scanModeLabel()}-${Date.now()}`);
    if(expenseScanState.mode==='invoice'){
      const vendor=expenseAvailableVendorRecords()[0];
      const available=availableMasterItems(formState.sourceData||'Perusahaan').filter(item=>item.active);
      formState.date=currentTimestampValue();
      if(vendor){formState.contact=vendor.name;formState.vendorQuery='';syncExpenseVendorSelection()}
      formState.title=`Biaya hasil scan ${name.replace(/\.[^.]+$/,'')}`;
      if(!formState.items.length&&available.length){
        const first=available[0];formState.items.push({id:Date.now(),item:first.name,desc:first.desc||'Hasil pemindaian nota',amount:185000,tax:first.ppn?'ppn11':first.pph?'pph10':'none',coa:first.coa||''});
        if(available[1]){const second=available[1];formState.items.push({id:Date.now()+1,item:second.name,desc:second.desc||'Hasil pemindaian nota',amount:315000,tax:second.ppn?'ppn11':second.pph?'pph10':'none',coa:second.coa||''});}
      }
      addScanToTransactionAttachments(file,name);
      formState.scanReceiptState='done';formState.scanReceiptName=name;
      closeExpenseScan();renderForm();showToast('Scan Nota selesai. Informasi transaksi dan item terisi, lalu dokumen otomatis masuk ke Lampiran Step 2.','info');
    }else if(expenseScanState.mode==='payment-modal'){
      const expense=expenses.find(item=>item.id===currentPaymentId);const remaining=expense?remainingOf(expense):0;
      document.getElementById('payDateDay').value=expenseDatePart(currentTimestampValue());
      document.getElementById('payDateTime').value=expenseTimePart(currentTimestampValue());
      const select=document.getElementById('payAccount');if(select&&select.options.length)select.selectedIndex=0;
      const amount=document.getElementById('payAmount');if(amount){amount.dataset.max=String(remaining);updateModalPaymentAmount(remaining)}
      modalPaymentEvidenceFiles=[name];modalPaymentEvidenceState={};modalPaymentEvidenceErrors=[];modalPaymentEvidenceState[name]=scanFileMeta(name,file);
      const mount=document.getElementById('modalPaymentEvidenceMount');if(mount)mount.innerHTML=renderModalPaymentEvidenceUploader();
      closeExpenseScan();showToast('Bukti pembayaran berhasil dibaca dan data pembayaran terisi otomatis.','info');
    }else{
      const total=formCalc().total;
      if(formState.paymentType==='later')formState.paymentType='full';
      formState.paymentMethod='transfer';
      formState.payAmount=formState.paymentType==='full'?total:(Number(formState.payAmount)||Math.round(total*.3));
      formState.payDate=currentTimestampValue();
      const sourceAccounts=availableAccounts(formState.sourceData||'Perusahaan');
      formState.account=sourceAccounts.find(item=>/bca|mandiri|bank|bni|bri/i.test(item))||sourceAccounts[0]||'';
      setSinglePaymentEvidence(file,name);
      closeExpenseScan();renderForm();showToast('Bukti pembayaran dibaca. Metode, nominal, tanggal, rekening, dan file bukti telah terisi otomatis. Periksa kembali sebelum melanjutkan.','info');
    }
  };
  window.retryExpenseScan=function(){expenseScanState.view=expenseScanState.permission==='granted'?'camera':'denied';renderExpenseScan()};
  window.manualAfterExpenseScan=function(){closeExpenseScan();showToast('Silakan lengkapi data secara manual. Data form sebelumnya tetap dipertahankan.','info')};

  window.renderScanReceiptStatus=function(){
    if(!formState?.scanReceiptName)return'';
    const name=expenseEscape(formState.scanReceiptName);
    return `<div class="scan-result-card"><span class="scan-result-icon"><i class="ti ti-circle-check-filled"></i></span><div class="scan-result-copy"><strong>${name}</strong><small>Data nota sudah diterapkan dan dokumen tersimpan pada Lampiran Step 2.</small></div><div class="scan-result-actions"><button type="button" onclick="previewAttachment('${name.replace(/'/g,"\\'")}')">Preview</button><button type="button" onclick="resetScanReceipt()">Hapus</button></div></div>`;
  };
  window.resetScanReceipt=function(){if(!formState)return;formState.scanReceiptState='idle';formState.scanReceiptName='';renderForm()};
  window.renderScanReceiptUploader=function(){
    const hasResult=Boolean(formState?.scanReceiptName);
    return `<div class="scan-figma-uploader"><div class="expense-uploader-label"><span>Scan Nota</span></div><div class="smart-scan-card"><div class="smart-scan-main"><span class="smart-scan-icon"><i class="ti ti-receipt-2"></i></span><div class="smart-scan-copy"><strong>Pindai nota untuk mengisi transaksi otomatis</strong><small>Gunakan kamera, pilih gambar dari galeri, atau upload PDF. Maksimal 10 MB.</small></div></div><button class="btn btn-secondary" type="button" onclick="openExpenseScan('invoice')"><i class="ti ti-scan"></i>${hasResult?'Scan Ulang':'Scan Nota'}</button></div>${renderScanReceiptStatus()}</div>`;
  };

  window.setExpensePaymentMethod=function(method){formState.paymentMethod=method;renderForm()};
  window.setExpensePaymentAmount=function(value,input){const total=Math.max(0,Number(formCalc().total)||0),raw=Math.max(0,Number(String(value||'').replace(/[^0-9]/g,''))||0),amount=Math.min(raw,total);formState.payAmount=amount;formState.paymentType=total>0&&amount>=total?'full':'partial';if(input)input.value=amount||'';const remainingInput=document.querySelector('#formPage [data-payment-remaining]');if(remainingInput)remainingInput.value=Math.max(total-amount,0);const partialPanel=document.querySelector('#formPage [data-payment-partial-panel]');if(partialPanel)partialPanel.style.display=formState.paymentType==='partial'?'grid':'none';const partialBanner=document.querySelector('#formPage [data-payment-partial-banner]');if(partialBanner)partialBanner.style.display=formState.paymentType==='partial'?'flex':'none';renderFormSummary()};
  window.setExpenseThirtyPercent=function(){formState.payAmount=Math.round(formCalc().total*.3);renderForm()};
  window.handleDirectPaymentEvidence=function(files){
    const file=files?.[0];if(!file)return;
    const valid=String(file.type||'').startsWith('image/')||file.type==='application/pdf'||/\.(png|jpe?g|webp|pdf)$/i.test(file.name||'');
    if(!valid){showToast('Bukti pembayaran harus berupa JPG, PNG, WebP, atau PDF.','error');return}
    if(file.size>10*1024*1024){showToast('Ukuran bukti pembayaran maksimal 10 MB.','error');return}
    const name=safeFileName(file);setSinglePaymentEvidence(file,name);renderForm();
  };
  window.removePaymentEvidence=function(index){if(!formState)return;const name=formState.evidenceFiles?.[index];formState.evidenceFiles.splice(index,1);if(name)delete paymentEvidenceState[name];renderForm()};
  window.renderPaymentEvidenceUploader=function(){
    const files=formState.evidenceFiles||[];const name=files[0];const meta=name?paymentEvidenceState[name]:null;
    return `<div class="single-proof-uploader"><div class="expense-uploader-label"><span>Bukti Pembayaran <span class="optional">Opsional</span></span><span class="expense-upload-count">${name?'1/1':'0/1'}</span></div><button class="single-proof-upload" type="button" ${name?'disabled':''} onclick="document.getElementById('directPaymentEvidenceInput').click()"><i class="ti ti-folder-filled"></i><span>${name?'<strong>Bukti sudah diunggah</strong>':'<strong>Unggah file</strong> atau pilih dari perangkat'}</span><small>${name?'Hapus bukti untuk mengganti file':'JPG, PNG, WebP, atau PDF · maks. 10 MB'}</small></button>${name?`<div class="single-proof-file"><i class="ti ti-folder-filled"></i><div class="single-proof-file-copy"><strong>${expenseEscape(name)}</strong><small>${formatUploadSize(meta?.size||0)}</small><button type="button" onclick="previewAttachment('${expenseEscape(name).replace(/'/g,"\\'")}')">Preview</button></div><button type="button" class="single-proof-remove" onclick="removePaymentEvidence(0)" aria-label="Hapus bukti"><i class="ti ti-x"></i></button></div>`:''}</div>`;
  };

  window.renderPaymentStep=function(){
    const c=formCalc(),isLater=formState.paymentType==='later',isNow=!isLater,sourceAccounts=availableAccounts(formState.sourceData||'Perusahaan');
    formState.paymentMethod=formState.paymentMethod||'transfer';
    const paymentAmount=Math.min(c.total,Math.max(0,Number(formState.payAmount||0)));
    const remainingAmount=Math.max(c.total-paymentAmount,0);
    const isPartial=isNow&&c.total>0&&paymentAmount<c.total;
    return `<div class="card subsection wizard-step-card">${expenseSectionTitle(3,'Pembayaran','')}<div class="attachment-item source-lock-note"><strong>Sumber Data: ${formState.sourceData||'Perusahaan'}</strong><div class="hint">Pembayaran dan jurnal mengikuti Sumber Data transaksi dan tidak dapat diubah pada tahap ini.</div></div><div class="subsection-title payment-section-heading">Pilih Proses Pembayaran</div><div class="payment-options payment-options--two"><label class="payment-option ${isNow?'active':''}"><input type="radio" name="paymentProcess" value="now" ${isNow?'checked':''} onchange="setPaymentType(this.value)"><strong>Bayar Sekarang</strong><div class="hint">Masukkan nominal yang dibayarkan saat transaksi diterbitkan.</div></label><label class="payment-option ${isLater?'active':''}"><input type="radio" name="paymentProcess" value="later" ${isLater?'checked':''} onchange="setPaymentType(this.value)"><strong>Bayar Nanti</strong><div class="hint">Transaksi diterbitkan tanpa pembayaran awal.</div></label></div>${isLater?`<div class="payment-fields"><div class="payment-later-stack"><div class="journal-info-banner" role="status"><i class="ti ti-info-circle" aria-hidden="true"></i><div><strong>Informasi Jurnal</strong><span>Jurnal penerbitan tetap terbentuk. Jurnal pembayaran belum dibuat.</span></div></div><div class="field payment-due-field"><label>Tanggal Jatuh Tempo *</label><input type="date" class="input" value="${formState.due}" onchange="setForm('due',this.value);renderFormSummary()"></div></div></div>`:`<div class="payment-fields"><div class="smart-scan-card"><div class="smart-scan-main"><span class="smart-scan-icon"><i class="ti ti-receipt"></i></span><div class="smart-scan-copy"><strong>Scan Bukti Pembayaran</strong><small>Kamera, galeri, dan PDF dapat digunakan untuk mengisi data pembayaran otomatis.</small></div></div><button class="btn btn-secondary" type="button" onclick="openExpenseScan('payment')"><i class="ti ti-scan"></i>Scan Bukti</button></div><div class="payment-detail-grid"><div class="field payment-amount-field"><label>Nominal Pembayaran *</label><div class="expense-money-input"><span>Rp</span><input inputmode="numeric" value="${paymentAmount}" data-payment-amount data-max="${c.total}" oninput="setExpensePaymentAmount(this.value,this)"></div></div><div class="field payment-remaining-field"><label>Sisa Tagihan</label><div class="expense-money-input"><span>Rp</span><input data-payment-remaining value="${remainingAmount}" disabled aria-disabled="true"></div></div><div class="field payment-account-field"><label>Rekening Kas & Bank *</label><select onchange="setForm('account',this.value)">${sourceAccounts.map(a=>`<option ${formState.account===a?'selected':''}>${a}</option>`).join('')}</select></div><div class="field payment-date-time-combined"><label>Tanggal Pembayaran *</label><div class="payment-date-time-inline"><input type="date" class="input" value="${expenseDatePart(formState.payDate)}" onchange="setExpensePaymentDate(this.value)"><input type="time" class="input" aria-label="Waktu Pembayaran" value="${expenseTimePart(formState.payDate)}" onchange="setExpensePaymentTime(this.value)"></div></div><div class="payment-partial-due-block" data-payment-partial-panel style="display:${isPartial?'grid':'none'}"><div class="partial-payment-banner" data-payment-partial-banner role="status" style="display:${isPartial?'flex':'none'}"><i class="ti ti-info-circle" aria-hidden="true"></i><div><strong>Transaksi dihitung sebagai Bayar Sebagian</strong><span>Nominal pembayaran lebih kecil dari total tagihan. Sisa tagihan akan mengikuti tanggal jatuh tempo yang dipilih.</span></div></div><div class="field payment-due-field"><label>Tanggal Jatuh Tempo *</label><input type="date" class="input" value="${formState.due}" onchange="setForm('due',this.value);renderFormSummary()"></div></div><div class="payment-evidence-field payment-proof-section">${renderPaymentEvidenceUploader()}</div></div></div>`}${expenseWizardFooter({nextLabel:'Lanjut ke Preview'})}</div>`;
  };

  window.setPaymentType=function(type){if(type==='later'){formState.paymentType='later';formState.payAmount=0}else{formState.paymentType='partial';formState.payAmount=0}renderForm()};

  window.openPayment=function(id){
    if(typeof previousOpenPayment==='function')previousOpenPayment(id);
    const modal=document.querySelector('#paymentModal .modal');
    if(modal&&!modal.querySelector('.modal-smart-scan-card')){
      const head=modal.querySelector('.modal-head');head?.insertAdjacentHTML('afterend',`<div class="smart-scan-card modal-smart-scan-card"><div class="smart-scan-main"><span class="smart-scan-icon"><i class="ti ti-receipt"></i></span><div class="smart-scan-copy"><strong>Scan Bukti Pembayaran</strong><small>Gunakan kamera, galeri, atau PDF untuk mengisi pembayaran otomatis.</small></div></div><button class="btn btn-secondary" type="button" onclick="openExpenseScan('payment-modal')"><i class="ti ti-scan"></i>Scan Bukti</button></div>`);
    }
  };

  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&expenseScanState.open)closeExpenseScan()});
})();
