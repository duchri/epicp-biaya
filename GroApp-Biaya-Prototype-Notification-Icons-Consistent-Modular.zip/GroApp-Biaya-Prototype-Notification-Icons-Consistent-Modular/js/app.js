
const today=new Date('2026-07-27T10:00:00');
const sourceOptions=['Perusahaan','Laundry Malang','Laundry Surabaya'];
const accounts=['BCA Operasional','Mandiri Bisnis','Kas Utama','Kas Laundry Malang','BCA Laundry Surabaya'];
let vendorRecords=[
{name:'PLN',phone:'123',address:'Jakarta',email:'',sources:['Perusahaan','Laundry Malang']},
{name:'Telkom Indonesia',phone:'147',address:'Jakarta',email:'corporate@telkom.co.id',sources:['Perusahaan','Laundry Malang','Laundry Surabaya']},
{name:'Bluebird',phone:'021-79171234',address:'Jakarta Selatan',email:'customer.service@bluebirdgroup.com',sources:['Perusahaan','Laundry Malang','Laundry Surabaya']},
{name:'PT Gedung Sejahtera',phone:'021-5550123',address:'Jakarta Pusat',email:'finance@gedungsejahtera.co.id',sources:['Perusahaan']},
{name:'Vendor ATK',phone:'081234567890',address:'Surabaya',email:'vendoratk@example.com',sources:['Perusahaan','Laundry Surabaya']},
{name:'PT Sumber Makmur',phone:'0341-555123',address:'Malang',email:'admin@sumbermakmur.co.id',sources:['Perusahaan','Laundry Malang']},
{name:'CV Karya Bersama',phone:'0341-555987',address:'Malang',email:'',sources:['Perusahaan','Laundry Malang']}
];

function expenseVendorSlug(value){return String(value||'vendor').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'')||'vendor'}
function normalizeExpenseVendor(vendor,index=0){
  vendor.id=vendor.id||`vendor-${expenseVendorSlug(vendor.name)}-${index+1}`;
  vendor.phone=vendor.phone||'';
  vendor.email=vendor.email||'';
  vendor.additionalContacts=Array.isArray(vendor.additionalContacts)?vendor.additionalContacts:[];
  vendor.additionalContacts=vendor.additionalContacts.map((item,itemIndex)=>({id:item.id||`${vendor.id}-contact-${itemIndex+1}`,type:item.type==='email'?'email':'phone',value:item.value||''}));
  vendor.addresses=Array.isArray(vendor.addresses)?vendor.addresses.filter(value=>value!==undefined&&value!==null):[];
  if(!vendor.addresses.length&&vendor.address)vendor.addresses=[vendor.address];
  vendor.accounts=Array.isArray(vendor.accounts)?vendor.accounts:[];
  if(!vendor.accounts.length&&(vendor.bank||vendor.account||vendor.holder))vendor.accounts=[{id:`${vendor.id}-account-1`,bank:vendor.bank||'',number:vendor.account||'',raw:vendor.account||'',holder:vendor.holder||vendor.name}];
  vendor.accounts=vendor.accounts.map((account,accountIndex)=>({id:account.id||`${vendor.id}-account-${accountIndex+1}`,bank:account.bank||'',number:String(account.number||account.raw||'').replace(/\s/g,''),raw:account.raw||account.number||'',holder:account.holder||vendor.name}));
  vendor.address=vendor.addresses[0]||'';
  return vendor;
}
vendorRecords=vendorRecords.map(normalizeExpenseVendor);
function seedExpenseVendorDetails(){
  const presets={
    'PLN':{additionalContacts:[{type:'email',value:'layananpelanggan@pln.co.id'}],addresses:['Jl. Trunojoyo Blok M-I No. 135, Jakarta Selatan'],accounts:[]},
    'Telkom Indonesia':{additionalContacts:[{type:'phone',value:'0811 9000 147'},{type:'email',value:'enterprise@telkom.co.id'}],addresses:['Jl. Japati No. 1, Bandung','Jl. Gatot Subroto Kav. 52, Jakarta Selatan'],accounts:[{bank:'Bank Mandiri',number:'1230000147',holder:'PT Telkom Indonesia Tbk'}]},
    'Bluebird':{additionalContacts:[{type:'email',value:'corporate@bluebirdgroup.com'}],addresses:['Jl. Mampang Prapatan Raya No. 60, Jakarta Selatan'],accounts:[{bank:'BCA',number:'0123456789',holder:'PT Blue Bird Tbk'}]},
    'PT Gedung Sejahtera':{additionalContacts:[{type:'phone',value:'0812 8899 2233'}],addresses:['Jl. Jenderal Sudirman Kav. 45, Jakarta Pusat','Kompleks Pergudangan Cakung Blok B-12, Jakarta Timur'],accounts:[{bank:'BRI',number:'098701338855',holder:'PT Gedung Sejahtera'},{bank:'BCA',number:'0108892211',holder:'PT Gedung Sejahtera'}]},
    'Vendor ATK':{additionalContacts:[{type:'phone',value:'0813 7711 2200'},{type:'email',value:'order@vendoratk.example.com'}],addresses:['Jl. Industri Rungkut No. 8, Surabaya'],accounts:[{bank:'BRI',number:'098701338855',holder:'Vendor ATK'}]},
    'PT Sumber Makmur':{additionalContacts:[],addresses:['Jl. Soekarno Hatta No. 88, Malang'],accounts:[{bank:'BCA',number:'5220198877',holder:'PT Sumber Makmur'}]},
    'CV Karya Bersama':{additionalContacts:[{type:'email',value:'finance@karyabersama.co.id'}],addresses:['Jl. Letjen Sutoyo No. 17, Malang'],accounts:[{bank:'BNI',number:'4412019988',holder:'CV Karya Bersama'}]}
  };
  vendorRecords.forEach((vendor,index)=>{
    const preset=presets[vendor.name];
    if(!preset)return;
    if(!vendor.additionalContacts.length)vendor.additionalContacts=preset.additionalContacts.map((item,itemIndex)=>({id:`${vendor.id}-contact-${itemIndex+1}`,...item}));
    if(!vendor.addresses.length||vendor.addresses.length===1&&vendor.addresses[0]===vendor.address)vendor.addresses=[...preset.addresses];
    if(!vendor.accounts.length)vendor.accounts=preset.accounts.map((item,itemIndex)=>({id:`${vendor.id}-account-${itemIndex+1}`,raw:item.number,...item}));
    normalizeExpenseVendor(vendor,index);
  });
}
seedExpenseVendorDetails();
const vendors=vendorRecords.map(v=>v.name);
const sourceAvailability={
 'Perusahaan':{vendors:['PLN','Telkom Indonesia','PT Gedung Sejahtera','PT Sumber Makmur','CV Karya Bersama'],accounts:['BCA Operasional','Mandiri Bisnis','Kas Utama'],items:['Listrik Kantor','Internet Kantor','Sewa Kantor','Perawatan Mesin']},
 'Laundry Malang':{vendors:['PLN','Bluebird','Vendor ATK'],accounts:['Kas Laundry Malang','BCA Operasional'],items:['Listrik Kantor','Transportasi','Alat Tulis Kantor']},
 'Laundry Surabaya':{vendors:['Telkom Indonesia','Bluebird','Vendor ATK'],accounts:['BCA Laundry Surabaya','Mandiri Bisnis'],items:['Internet Kantor','Transportasi','Alat Tulis Kantor']}
};
function sourceConfig(source){return sourceAvailability[source]||sourceAvailability['Perusahaan']}
function availableVendors(source){const configured=sourceConfig(source).vendors;return [...new Set([...configured,...vendorRecords.filter(v=>v.sources.includes(source)).map(v=>v.name)])].sort((a,b)=>a.localeCompare(b))}
function getVendorDetail(name){return vendorRecords.find(v=>v.name.toLowerCase()===String(name||'').trim().toLowerCase())||null}
function availableAccounts(source){return sourceConfig(source).accounts}
function availableMasterItems(source){const allowed=sourceConfig(source).items;return masterItems.filter(m=>m.active&&allowed.includes(m.name))}
let coaList=['Biaya Listrik','Biaya Internet','Biaya Transportasi','Biaya Sewa'];
const coaCodeByName={
  'Biaya Listrik':'1.01.015',
  'Biaya Internet':'1.01.016',
  'Biaya Transportasi':'1.01.017',
  'Biaya Sewa':'1.01.018',
  'Biaya Administrasi':'1.01.019',
  'Biaya Pemeliharaan':'1.01.020'
};
function formatCoaTag(coa){const name=String(coa||'').trim();if(!name)return 'CoA belum tersedia';const code=coaCodeByName[name];return code?`${code} - ${name}`:name}

let masterItems=[
 {id:'mi1',name:'Listrik Kantor',desc:'Tagihan listrik bulanan',coa:'Biaya Listrik',ppn:false,pph:false,active:true},
 {id:'mi2',name:'Internet Kantor',desc:'Tagihan internet bulanan',coa:'Biaya Internet',ppn:true,pph:false,active:true},
 {id:'mi3',name:'Transportasi',desc:'Transportasi operasional',coa:'Biaya Transportasi',ppn:false,pph:false,active:true},
 {id:'mi4',name:'Sewa Kantor',desc:'Sewa tempat usaha',coa:'Biaya Sewa',ppn:false,pph:true,active:true}
];
let expenses=[
{id:1,sourceData:'Perusahaan',code:'EXP-2026-0006',date:'2026-07-17T09:15',contact:'PLN',title:'Listrik kantor Juli',due:'2026-07-31',status:'Draft',payStatus:'Belum Dibayar',items:[{item:'Listrik Kantor',desc:'Tagihan listrik kantor bulan Juli',amount:3200000,tax:'none',coa:'Biaya Listrik'}],paid:0,payments:[],attachments:['tagihan-pln-juli.pdf'],createdBy:'Siti Mulyani'},
{id:2,sourceData:'Perusahaan',code:'EXP-2026-0005',date:'2026-07-16T13:40',contact:'Telkom Indonesia',title:'Internet kantor Juli',due:'2026-07-28',status:'Terbit',payStatus:'Belum Dibayar',items:[{item:'Internet Kantor',desc:'Paket bisnis 200 Mbps',amount:1500000,tax:'ppn11',coa:'Biaya Internet'}],paid:0,payments:[],attachments:['tagihan-internet-juli.pdf'],createdBy:'Siti Mulyani'},
{id:3,sourceData:'Perusahaan',code:'EXP-2026-0004',date:'2026-07-15T10:30',contact:'PT Gedung Sejahtera',title:'Sewa kantor Juli',due:'2026-07-25',status:'Terbit',payStatus:'Dibayar Sebagian',items:[{item:'Sewa Kantor',desc:'Sewa ruang kantor bulan Juli',amount:10000000,tax:'pph10',coa:'Biaya Sewa'}],paid:4000000,payments:[{date:'2026-07-15T11:00',account:'BCA Operasional',amount:4000000,note:'Pembayaran tahap pertama',evidence:'bukti-transfer-sewa-tahap-1.pdf'}],attachments:['invoice-sewa-juli.pdf'],createdBy:'Raka Pratama'},
{id:4,sourceData:'Laundry Malang',code:'EXP-2026-0003',date:'2026-07-14T08:45',contact:'Bluebird',title:'Transportasi operasional',due:'',status:'Terbit',payStatus:'Lunas',items:[{item:'Transportasi',desc:'Transportasi kunjungan operasional',amount:650000,tax:'none',coa:'Biaya Transportasi'}],paid:650000,payments:[{date:'2026-07-14T08:50',account:'Kas Utama',amount:650000,note:'Bayar lunas',evidence:'bukti-bayar-bluebird.jpg'}],attachments:['struk-bluebird.jpg'],createdBy:'Nadia Putri'},
{id:5,sourceData:'Laundry Surabaya',code:'EXP-2026-0002',date:'2026-07-12T14:20',contact:'Vendor ATK',title:'Pengadaan alat tulis kantor',due:'2026-07-26',status:'Draft',payStatus:'Belum Dibayar',items:[{item:'Alat Tulis Kantor',desc:'Kertas, tinta printer, dan pulpen',amount:2250000,tax:'ppn11',coa:'Biaya Administrasi'}],paid:0,payments:[],attachments:['nota-atk-juli.jpg'],createdBy:'Nadia Putri'},
{id:6,sourceData:'Laundry Malang',code:'EXP-2026-0001',date:'2026-07-10T09:00',contact:'CV Karya Bersama',title:'Pemeliharaan mesin produksi',due:'2026-07-24',status:'Void',payStatus:'Belum Dibayar',items:[{item:'Perawatan Mesin',desc:'Servis rutin mesin produksi',amount:4800000,tax:'pph10',coa:'Biaya Pemeliharaan'}],paid:0,payments:[],attachments:['invoice-servis-mesin.pdf'],createdBy:'Siti Mulyani',voidReason:'Transaksi dibuat dengan nominal yang tidak sesuai',voidedBy:'Siti Mulyani',voidedAt:'2026-07-10T10:20'},
{id:7,sourceData:'Laundry Surabaya',code:'EXP-2026-0018',date:'2026-07-27T10:15',contact:'Telkom Indonesia',title:'Internet outlet Surabaya Agustus',due:'2026-08-05',status:'Terbit',payStatus:'Belum Dibayar',items:[{item:'Internet Kantor',desc:'Paket internet bisnis outlet Surabaya',amount:1850000,tax:'ppn11',coa:'Biaya Internet'}],paid:0,payments:[],attachments:['invoice-internet-surabaya-agustus.pdf'],createdBy:'Nadia Putri'},
{id:8,sourceData:'Perusahaan',code:'EXP-2026-0016',date:'2026-07-25T14:20',contact:'PT Gedung Sejahtera',title:'Sewa gudang operasional',due:'2026-08-02',status:'Terbit',payStatus:'Dibayar Sebagian',items:[{item:'Sewa Kantor',desc:'Sewa gudang operasional bulan Agustus',amount:12000000,tax:'pph10',coa:'Biaya Sewa'}],paid:5000000,payments:[{date:'2026-07-25T15:10',account:'Mandiri Bisnis',amount:5000000,note:'Pembayaran uang muka sewa gudang',evidence:'bukti-dp-sewa-gudang.pdf'}],attachments:['invoice-sewa-gudang-agustus.pdf'],createdBy:'Raka Pratama'},
{id:9,sourceData:'Laundry Malang',code:'EXP-2026-0015',date:'2026-07-24T08:35',contact:'PLN',title:'Listrik outlet Malang Juli',due:'2026-08-01',status:'Terbit',payStatus:'Belum Dibayar',items:[{item:'Listrik Kantor',desc:'Tagihan listrik outlet Malang bulan Juli',amount:2900000,tax:'none',coa:'Biaya Listrik'}],paid:0,payments:[],attachments:['tagihan-pln-outlet-malang.pdf'],createdBy:'Siti Mulyani'},
{id:10,sourceData:'Laundry Surabaya',code:'EXP-2026-0013',date:'2026-07-22T16:40',contact:'Vendor ATK',title:'Perlengkapan administrasi outlet',due:'',status:'Terbit',payStatus:'Lunas',items:[{item:'Alat Tulis Kantor',desc:'Kertas nota, label, tinta printer, dan pulpen',amount:1650000,tax:'ppn11',coa:'Biaya Administrasi'}],paid:1831500,payments:[{date:'2026-07-22T16:45',account:'BCA Laundry Surabaya',amount:1831500,note:'Pembayaran lunas perlengkapan administrasi',evidence:'bukti-bayar-atk-surabaya.pdf'}],attachments:['nota-atk-surabaya.pdf'],createdBy:'Nadia Putri'},
{id:11,sourceData:'Perusahaan',code:'EXP-2026-0010',date:'2026-07-21T09:35',contact:'CV Karya Bersama',title:'Perawatan AC kantor pusat',due:'2026-07-30',status:'Terbit',payStatus:'Dibayar Sebagian',items:[{item:'Perawatan Mesin',desc:'Servis dan penggantian komponen AC kantor pusat',amount:3750000,tax:'pph10',coa:'Biaya Pemeliharaan'}],paid:1500000,payments:[{date:'2026-07-21T10:15',account:'BCA Operasional',amount:1500000,note:'Pembayaran tahap pertama servis AC',evidence:'bukti-servis-ac-tahap-1.pdf'}],attachments:['invoice-servis-ac.pdf'],createdBy:'Raka Pratama'},
{id:12,sourceData:'Laundry Malang',code:'EXP-2026-0017',date:'2026-07-26T11:05',contact:'Vendor ATK',title:'Kebutuhan administrasi outlet Malang',due:'2026-08-06',status:'Draft',payStatus:'Belum Dibayar',items:[{item:'Alat Tulis Kantor',desc:'Kertas nota, label pakaian, dan tinta printer',amount:2450000,tax:'ppn11',coa:'Biaya Administrasi'}],paid:0,payments:[],attachments:['penawaran-atk-malang.pdf'],createdBy:'Nadia Putri'},
{id:13,sourceData:'Perusahaan',code:'EXP-2026-0014',date:'2026-07-23T13:15',contact:'PT Sumber Makmur',title:'Kebutuhan rapat dan administrasi',due:'2026-08-03',status:'Draft',payStatus:'Belum Dibayar',items:[{item:'Alat Tulis Kantor',desc:'Kebutuhan rapat bulanan dan perlengkapan administrasi',amount:1250000,tax:'none',coa:'Biaya Administrasi'}],paid:0,payments:[],attachments:['penawaran-kebutuhan-rapat.pdf'],createdBy:'Siti Mulyani'},
{id:14,sourceData:'Laundry Surabaya',code:'EXP-2026-0011',date:'2026-07-20T15:30',contact:'Bluebird',title:'Transportasi kunjungan outlet',due:'',status:'Draft',payStatus:'Belum Dibayar',items:[{item:'Transportasi',desc:'Transportasi kunjungan operasional antar outlet',amount:980000,tax:'none',coa:'Biaya Transportasi'}],paid:0,payments:[],attachments:['estimasi-transportasi-outlet.pdf'],createdBy:'Nadia Putri'},
{id:15,sourceData:'Perusahaan',code:'EXP-2026-0008',date:'2026-07-18T15:20',contact:'PLN',title:'Estimasi listrik gudang Juli',due:'2026-07-31',status:'Draft',payStatus:'Belum Dibayar',items:[{item:'Listrik Kantor',desc:'Estimasi tagihan listrik gudang bulan Juli',amount:4100000,tax:'none',coa:'Biaya Listrik'}],paid:0,payments:[],attachments:[],createdBy:'Raka Pratama'},
{id:16,sourceData:'Laundry Surabaya',code:'EXP-2026-0012',date:'2026-07-21T16:10',contact:'Vendor ATK',title:'Pembelian tinta printer ganda',due:'2026-07-29',status:'Void',payStatus:'Belum Dibayar',items:[{item:'Alat Tulis Kantor',desc:'Tinta printer dan kertas nota outlet Surabaya',amount:1750000,tax:'ppn11',coa:'Biaya Administrasi'}],paid:0,payments:[],attachments:['invoice-atk-duplikat.pdf'],createdBy:'Nadia Putri',voidReason:'Transaksi tercatat dua kali dari invoice yang sama',voidedBy:'Nadia Putri',voidedAt:'2026-07-21T16:45'},
{id:17,sourceData:'Perusahaan',code:'EXP-2026-0009',date:'2026-07-19T12:45',contact:'Telkom Indonesia',title:'Upgrade internet kantor pusat',due:'2026-07-29',status:'Void',payStatus:'Belum Dibayar',items:[{item:'Internet Kantor',desc:'Upgrade paket internet kantor pusat',amount:2200000,tax:'ppn11',coa:'Biaya Internet'}],paid:0,payments:[],attachments:['invoice-upgrade-internet.pdf'],createdBy:'Siti Mulyani',voidReason:'Nominal belum memperoleh persetujuan dan perlu dicatat ulang',voidedBy:'Raka Pratama',voidedAt:'2026-07-19T13:10'},
{id:18,sourceData:'Laundry Malang',code:'EXP-2026-0007',date:'2026-07-18T09:10',contact:'Bluebird',title:'Transportasi operasional outlet',due:'',status:'Void',payStatus:'Belum Dibayar',items:[{item:'Transportasi',desc:'Transportasi operasional outlet Malang',amount:720000,tax:'none',coa:'Biaya Transportasi'}],paid:0,payments:[],attachments:['struk-bluebird-duplikat.jpg'],createdBy:'Nadia Putri',voidReason:'Struk yang sama sudah digunakan pada transaksi lain',voidedBy:'Nadia Putri',voidedAt:'2026-07-18T09:35'}
];
let activeTab='Terbit',quickDue='all',selected=new Set(),filters={source:'all',pay:[],contact:[],item:[],expense:[],due:'all',account:[]},editingId=null,currentDetailId=null,currentPaymentId=null,currentVoidId=null,pendingVoidRepeatId=null,currentDeleteId=null,pendingSource=null,searchTimer=null;
let formState=null;
let expenseUploadState={};
let expenseUploadErrors=[];
let paymentEvidenceState={};
let paymentEvidenceErrors=[];
let modalPaymentEvidenceFiles=[];
let modalPaymentEvidenceState={};
let modalPaymentEvidenceErrors=[];
let vendorFieldEditKey='',vendorFieldEditTarget=null;
function rupiah(n){return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n||0)}
function fmtDate(v){if(!v)return '-';return new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:v.includes('T')?'short':undefined}).format(new Date(v))}
function taxTypeOf(i){return i.tax||(i.ppn?'ppn11':i.pph?'pph10':'none')}
function ppnItemOf(i){return taxTypeOf(i)==='ppn11'?Number(i.amount||0)*.11:0}
function pphItemOf(i){return taxTypeOf(i)==='pph10'?Number(i.amount||0)*.10:0}
function totalOf(e){const base=e.items.reduce((s,i)=>s+Number(i.amount||0),0);const ppn=e.items.reduce((s,i)=>s+ppnItemOf(i),0);return Math.round(base+ppn)}
function ppnOf(e){return Math.round(e.items.reduce((s,i)=>s+ppnItemOf(i),0))}
function pphOf(e){return Math.round(e.items.reduce((s,i)=>s+pphItemOf(i),0))}
function remainingOf(e){return Math.max(totalOf(e)-pphOf(e)-e.paid,0)}
function updatePayStatus(e){const r=remainingOf(e);e.payStatus=e.paid<=0?'Belum Dibayar':r<=0?'Lunas':'Dibayar Sebagian'}
function showToast(msg,type='success'){const t=document.getElementById('toast');t.textContent=msg;t.className='toast show'+(type==='error'?' error':'');setTimeout(()=>t.className='toast',2500)}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('show')}
const notificationReadState={upcoming:false,overdue:false};
function positionNotificationPopover(){const pop=document.getElementById('notificationPopover'),button=document.getElementById('notificationButton');if(!pop||!button||!pop.classList.contains('show'))return;const rect=button.getBoundingClientRect(),width=pop.offsetWidth||360,height=pop.offsetHeight||420,gutter=12;let left=Math.min(rect.right-width,window.innerWidth-width-gutter);left=Math.max(gutter,left);let top=rect.bottom+10;if(top+height>window.innerHeight-gutter)top=Math.max(gutter,rect.top-height-10);pop.style.left=`${Math.round(left)}px`;pop.style.top=`${Math.round(top)}px`}
function toggleNotificationPopover(event){event?.stopPropagation?.();const pop=document.getElementById('notificationPopover'),button=document.getElementById('notificationButton');if(!pop||!button)return;const open=!pop.classList.contains('show');pop.classList.toggle('show',open);pop.setAttribute('aria-hidden',open?'false':'true');button.setAttribute('aria-expanded',open?'true':'false');if(open)requestAnimationFrame(positionNotificationPopover)}
function closeNotificationPopover(){const pop=document.getElementById('notificationPopover'),button=document.getElementById('notificationButton');if(!pop||!button)return;pop.classList.remove('show');pop.setAttribute('aria-hidden','true');button.setAttribute('aria-expanded','false')}
function syncNotificationCounter(){const unread=Object.values(notificationReadState).filter(v=>!v).length;const badge=document.getElementById('notificationUnreadBadge'),button=document.getElementById('notificationButton');if(badge)badge.textContent=unread?`${unread} Belum Dibaca`:'Semua Dibaca';if(button){button.dataset.count=String(unread);button.setAttribute('aria-label',unread?`Notifikasi, ${unread} belum dibaca`:'Notifikasi, semua sudah dibaca')}}
function markNotificationRead(type){if(!(type in notificationReadState))return;notificationReadState[type]=true;const article=document.getElementById(type==='upcoming'?'notificationUpcoming':'notificationOverdue');article?.classList.remove('unread');article?.querySelector('.notification-dot')?.remove();syncNotificationCounter()}
function markAllNotificationsRead(){Object.keys(notificationReadState).forEach(markNotificationRead)}
function openNotificationDetail(event,type,expenseId){event?.stopPropagation?.();markNotificationRead(type);closeNotificationPopover();openDetail(expenseId)}
document.addEventListener('click',event=>{if(!event.target.closest('#notificationPopover')&&!event.target.closest('#notificationButton'))closeNotificationPopover()});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeNotificationPopover()});
window.addEventListener('resize',()=>{if(document.getElementById('notificationPopover')?.classList.contains('show'))positionNotificationPopover()});
function showPage(name){document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));document.getElementById(name+'Page').classList.add('active');const titles={list:['Daftar Biaya','Transaksi / Biaya'],form:['Tambah Biaya','Transaksi / Biaya / Tambah'],detail:['Detail Biaya','Transaksi / Biaya / Detail'],master:['Master Item Biaya','Master Data / Master Item Biaya'],import:['Impor Biaya','Transaksi / Biaya / Impor'],print:['Bukti Pengeluaran','Transaksi / Biaya / Bukti Pengeluaran']};document.getElementById('pageTitle').textContent=titles[name][0];document.getElementById('breadcrumb').textContent=titles[name][1];document.getElementById('navBiaya')?.classList.toggle('active',name!=='master');document.getElementById('navMasterItem')?.classList.toggle('active',name==='master');window.scrollTo(0,0)}
const modalFocusReturn=new Map();
function normalizeModalPanel(backdrop){
  const panel=backdrop?.querySelector(':scope > .modal');
  if(!panel||panel.dataset.modalNormalized==='true')return;
  const isCustom=panel.classList.contains('period-modal')||panel.classList.contains('filter-card')||panel.classList.contains('ds-export-modal')||panel.classList.contains('export-modal');
  panel.dataset.modalNormalized='true';
  if(isCustom)return;
  const head=Array.from(panel.children).find(node=>node.classList?.contains('modal-head'));
  const actions=Array.from(panel.children).find(node=>node.classList?.contains('modal-actions'));
  if(!head||!actions)return;
  const body=document.createElement('div');
  body.className='modal-scroll-body';
  let node=head.nextSibling;
  while(node&&node!==actions){
    const next=node.nextSibling;
    body.appendChild(node);
    node=next;
  }
  panel.insertBefore(body,actions);
  panel.classList.add('modal-standardized');
}
function syncModalPageLock(){document.body.classList.toggle('modal-open',Boolean(document.querySelector('.modal-backdrop.show')))}
function closeTransientActionMenus(){
  document.querySelectorAll('.menu.show').forEach(menu=>{menu.classList.remove('show');if(typeof resetRowMenuPosition==='function')resetRowMenuPosition(menu)});
  document.querySelectorAll('.pd-more-menu.show,.expense-contact-menu.show,.multi-menu.show').forEach(menu=>menu.classList.remove('show'));
  document.querySelectorAll('.row-kebab[aria-expanded="true"],.pd-more-btn[aria-expanded="true"]').forEach(button=>button.setAttribute('aria-expanded','false'));
}
function openModal(id){
  closeTransientActionMenus();
  const modal=document.getElementById(id);
  if(!modal){showToast('Modal tidak ditemukan.','error');return}
  if(id==='filterModal')syncFilterModal();
  normalizeModalPanel(modal);
  modalFocusReturn.set(id,document.activeElement);
  modal.classList.add('show');
  modal.setAttribute('aria-hidden','false');
  syncModalPageLock();
  requestAnimationFrame(()=>modal.querySelector('.close,button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')?.focus());
}
function closeModal(id){
  const modal=document.getElementById(id);
  if(!modal)return;
  modal.classList.remove('show');
  modal.setAttribute('aria-hidden','true');
  syncModalPageLock();
  const returnTarget=modalFocusReturn.get(id);
  modalFocusReturn.delete(id);
  if(returnTarget&&document.contains(returnTarget))requestAnimationFrame(()=>returnTarget.focus?.());
}
function overlayClose(e,id){if(e.target.id===id)closeModal(id)}
document.addEventListener('keydown',event=>{
  if(event.key!=='Escape')return;
  const openModals=Array.from(document.querySelectorAll('.modal-backdrop.show'));
  const topModal=openModals.at(-1);
  if(topModal?.id==='voidRepeatSuccessModal')return;
  if(topModal){event.preventDefault();closeModal(topModal.id)}
});
function isoDate(d){return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)}
function formatRangeDate(value){return new Intl.DateTimeFormat('id-ID',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(value+'T00:00:00'))}
function syncDateRangeLabel(){dateRangeLabel.textContent=`${formatRangeDate(periodStart.value)} - ${formatRangeDate(periodEnd.value)}`}
function toggleDateRange(event){event.stopPropagation();const open=dateRangePopover.classList.toggle('show');dateRangeTrigger.setAttribute('aria-expanded',open?'true':'false');if(open){rangeDraftStart.value=periodStart.value;rangeDraftEnd.value=periodEnd.value;rangeError.textContent=''}}
function closeDateRange(){dateRangePopover.classList.remove('show');dateRangeTrigger.setAttribute('aria-expanded','false');rangeError.textContent=''}
function setRangeDraft(){document.querySelectorAll('#dateRangePopover .chip').forEach(x=>x.classList.remove('active'));rangeError.textContent=''}
function setQuickPeriodDraft(type,btn){document.querySelectorAll('#dateRangePopover .chip').forEach(x=>x.classList.remove('active'));btn.classList.add('active');let start=new Date(today),end=new Date(today);if(type==='week')start.setDate(today.getDate()-((today.getDay()+6)%7));if(type==='month')start=new Date(today.getFullYear(),today.getMonth(),1);if(type==='3month')start=new Date(today.getFullYear(),today.getMonth()-2,1);rangeDraftStart.value=isoDate(start);rangeDraftEnd.value=isoDate(end);rangeError.textContent=''}
function applyDateRange(){const a=rangeDraftStart.value,b=rangeDraftEnd.value;if(!a||!b){rangeError.textContent='Tanggal mulai dan tanggal akhir wajib diisi.';return}if(a>b){rangeError.textContent='Tanggal mulai tidak boleh melewati tanggal akhir.';return}periodStart.value=a;periodEnd.value=b;syncDateRangeLabel();closeDateRange();renderList()}
function setQuickPeriod(type,btn){setQuickPeriodDraft(type,btn);applyDateRange()}
function manualPeriod(){applyDateRange()}
document.addEventListener('click',event=>{if(!dateRangePopover?.contains(event.target)&&!event.target.closest?.('[onclick*="openPeriodPicker"]'))closeDateRange()});
function uniqueValues(values){return [...new Set(values.filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b)))}
function multiLabel(values,allLabel){if(!values||!values.length)return allLabel;if(values.length===1)return values[0];return `${values.length} dipilih`}
function renderMultiOptions(containerId,values,selected,onChangeName){const el=document.getElementById(containerId);if(!el)return;el.innerHTML=values.map(v=>`<label class="multi-option"><input type="checkbox" value="${String(v).replace(/"/g,'&quot;')}" ${selected.includes(v)?'checked':''} onchange="${onChangeName}()"><span>${v}</span></label>`).join('')||'<div class="hint" style="padding:10px">Tidak ada pilihan.</div>'}
function checkedValues(containerId){return [...document.querySelectorAll(`#${containerId} input[type="checkbox"]:checked`)].map(x=>x.value)}
function updateMultiSummary(summaryId,values,allLabel){const el=document.getElementById(summaryId);if(el)el.textContent=multiLabel(values,allLabel)}
function populateFilterOptions(){
  const vendors=uniqueValues(expenses.map(e=>e.contact));
  const items=uniqueValues(expenses.flatMap(e=>e.items.map(i=>i.item)));
  const expensesCoa=uniqueValues(expenses.flatMap(e=>e.items.map(i=>i.coa)));
  const accounts=uniqueValues(expenses.flatMap(e=>e.payments.map(p=>p.account)));
  const payStatuses=['Belum Dibayar','Dibayar Sebagian','Lunas'];
  renderMultiOptions('quickPayOptions',payStatuses,filters.pay,'quickPayChanged');
  renderMultiOptions('fPayOptions',payStatuses,filters.pay,'modalMultiChanged');
  renderMultiOptions('fVendorOptions',vendors,filters.contact,'modalMultiChanged');
  renderMultiOptions('fItemOptions',items,filters.item,'modalMultiChanged');
  renderMultiOptions('fExpenseOptions',expensesCoa,filters.expense,'modalMultiChanged');
  renderMultiOptions('fAccountOptions',accounts,filters.account,'modalMultiChanged');
  syncMultiSummaries();
}
function syncMultiSummaries(){
  updateMultiSummary('quickPaySummary',filters.pay,'Terbit');
  updateMultiSummary('fPaySummary',filters.pay,'Terbit');
  updateMultiSummary('fVendorSummary',filters.contact,'Semua Vendor');
  updateMultiSummary('fItemSummary',filters.item,'Semua Item');
  updateMultiSummary('fExpenseSummary',filters.expense,'Semua Akun Beban');
  updateMultiSummary('fAccountSummary',filters.account,'Semua Rekening');
}
function quickPayChanged(){filters.pay=checkedValues('quickPayOptions');renderMultiOptions('fPayOptions',['Belum Dibayar','Dibayar Sebagian','Lunas'],filters.pay,'modalMultiChanged');syncMultiSummaries();renderList()}
function modalMultiChanged(){
  updateMultiSummary('fPaySummary',checkedValues('fPayOptions'),'Terbit');
  updateMultiSummary('fVendorSummary',checkedValues('fVendorOptions'),'Semua Vendor');
  updateMultiSummary('fItemSummary',checkedValues('fItemOptions'),'Semua Item');
  updateMultiSummary('fExpenseSummary',checkedValues('fExpenseOptions'),'Semua Akun Beban');
  updateMultiSummary('fAccountSummary',checkedValues('fAccountOptions'),'Semua Rekening');
}
function syncFilterModal(){
  const get=id=>document.getElementById(id);
  const source=get('fSource'),due=get('fQuickDue'),start=get('fPeriodStart'),end=get('fPeriodEnd');
  if(!source||!due||!start||!end)return;
  source.value=filters.source||'all';due.value=quickDue||'all';start.value=get('periodStart').value;end.value=get('periodEnd').value;
  populateFilterOptions();
}
function syncQuickFilterUI(){const source=document.getElementById('sourceFilter'),due=document.getElementById('quickDueStatus');if(source)source.value=filters.source||'all';if(due)due.value=quickDue||'all';syncDateRangeLabel();populateFilterOptions()}
function applyFilter(){
  const get=id=>document.getElementById(id),start=get('fPeriodStart').value,end=get('fPeriodEnd').value;
  if(!start||!end){showToast('Tanggal mulai dan tanggal akhir wajib diisi.','error');return}
  if(start>end){showToast('Tanggal mulai tidak boleh melewati tanggal akhir.','error');return}
  filters={source:get('fSource').value,pay:checkedValues('fPayOptions'),contact:checkedValues('fVendorOptions'),item:checkedValues('fItemOptions'),expense:checkedValues('fExpenseOptions'),due:'all',account:checkedValues('fAccountOptions')};
  quickDue=get('fQuickDue').value;get('periodStart').value=start;get('periodEnd').value=end;get('rangeDraftStart').value=start;get('rangeDraftEnd').value=end;
  syncQuickFilterUI();closeModal('filterModal');renderList();
}
function resetFilter(){filters={source:'all',pay:[],contact:[],item:[],expense:[],due:'all',account:[]};quickDue='all';const get=id=>document.getElementById(id);get('periodStart').value='2026-07-01';get('periodEnd').value='2026-07-31';get('rangeDraftStart').value='2026-07-01';get('rangeDraftEnd').value='2026-07-31';syncQuickFilterUI();syncFilterModal();renderList()}
function setQuickDue(value){quickDue=value;renderList()}
function setSourceFilter(value){filters.source=value;renderList()}
function resetQuickFilters(){filters={source:'all',pay:[],contact:[],item:[],expense:[],due:'all',account:[]};quickDue='all';activeTab='Terbit';periodStart.value='2026-07-01';periodEnd.value='2026-07-31';rangeDraftStart.value=periodStart.value;rangeDraftEnd.value=periodEnd.value;syncQuickFilterUI();document.querySelectorAll('.quick-periods .chip').forEach((el,i)=>el.classList.toggle('active',i===2));selected.clear();renderList()}
function quickDueMatches(e){if(quickDue==='all')return true;if(!e.due||e.payStatus==='Lunas'||e.status!=='Terbit')return false;const diff=Math.ceil((new Date(e.due)-today)/86400000);if(quickDue==='overdue')return diff<0;if(quickDue==='today')return diff===0;if(quickDue==='tomorrow')return diff===1;return diff===Number(quickDue)}
function matchesMulti(selected,value){return !selected||!selected.length||selected.includes(value)}
function filteredBase(){const start=document.getElementById('periodStart').value,end=document.getElementById('periodEnd').value;return expenses.filter(e=>{const d=e.date.slice(0,10),diff=e.due?Math.ceil((new Date(e.due)-today)/86400000):999,source=e.sourceData||'Perusahaan';return d>=start&&d<=end&&quickDueMatches(e)&&(filters.source==='all'||source===filters.source)&&matchesMulti(filters.pay,e.payStatus)&&matchesMulti(filters.contact,e.contact)&&(!filters.item.length||e.items.some(i=>filters.item.includes(i.item)))&&(!filters.expense.length||e.items.some(i=>filters.expense.includes(i.coa)))&&(!filters.account.length||e.payments.some(p=>filters.account.includes(p.account)))&&(filters.due==='all'||(filters.due==='overdue'&&e.due&&diff<0&&e.payStatus!=='Lunas')||(filters.due==='soon'&&e.due&&diff>=0&&diff<=7&&e.payStatus!=='Lunas'))})}
function filteredRows(){let rows=filteredBase();rows=rows.filter(e=>e.status===activeTab);const q=searchInput.value.trim().toLowerCase();if(q)rows=rows.filter(e=>`${e.code} ${e.sourceData||'Perusahaan'} ${e.title} ${e.contact} ${e.items.map(i=>i.item).join(' ')}`.toLowerCase().includes(q));return rows.sort((a,b)=>b.date.localeCompare(a.date))}
function renderTabs(base){const names=['Terbit','Draft','Void'];tabs.innerHTML=names.map(n=>{const count=base.filter(e=>e.status===n).length;const countMarkup=`<span class="count">${count}</span>`;return `<button class="tab ${activeTab===n?'active':''}" onclick="setTab('${n}')"><span>${n}</span>${countMarkup}</button>`}).join('')}
function setTab(n){activeTab=n;selected.clear();renderList()}
function dateOnly(v){if(!v)return '-';return new Intl.DateTimeFormat('id-ID',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(v))}
function timeOnly(v,fallback=''){if(!v)return fallback||'';const raw=String(v);if(raw.includes('T')){const part=(raw.split('T')[1]||'').slice(0,5);if(part)return part}return String(fallback||'')}
function dateTimeStack(v,fallbackTime=''){if(!v)return '-';const time=timeOnly(v,fallbackTime);return `<div class="date-time-stack"><span class="date-time-stack__date">${dateOnly(v)}</span>${time?`<span class="date-time-stack__time">${time}</span>`:''}</div>`}
function dueDayDiff(e){return e.due?Math.ceil((new Date(e.due)-today)/86400000):null}
function dueToneClass(e){if(!e.due||e.payStatus==='Lunas'||e.status!=='Terbit')return '';const diff=dueDayDiff(e);if(diff<0)return 'overdue-soft';if(diff<=7)return 'overdue-soon';return ''}
function dueToneLabel(e){if(!e.due)return 'Tidak memiliki tanggal jatuh tempo';if(e.payStatus==='Lunas')return 'Tagihan sudah lunas';if(e.status!=='Terbit')return 'Status jatuh tempo berlaku setelah transaksi diterbitkan';const diff=dueDayDiff(e);if(diff<0)return `Terlambat ${Math.abs(diff)} hari`;if(diff===0)return 'Jatuh tempo hari ini';return `Jatuh tempo ${diff} hari lagi`}
function renderList(){const base=filteredBase(),data=filteredRows();renderTabs(base);const terbit=base.filter(e=>e.status==='Terbit'),drafts=base.filter(e=>e.status==='Draft'),total=terbit.reduce((s,e)=>s+(totalOf(e)-pphOf(e)),0),gross=terbit.reduce((s,e)=>s+e.items.reduce((a,i)=>a+Number(i.amount||0),0),0),ppn=terbit.reduce((s,e)=>s+ppnOf(e),0),pph=terbit.reduce((s,e)=>s+pphOf(e),0),paid=terbit.reduce((s,e)=>s+Math.min(Number(e.paid||0),totalOf(e)-pphOf(e)),0),rem=terbit.reduce((s,e)=>s+remainingOf(e),0),over=terbit.filter(e=>e.due&&new Date(e.due+'T23:59:59')<today&&e.payStatus!=='Lunas'),draftValue=drafts.reduce((s,e)=>s+(totalOf(e)-pphOf(e)),0);sumTotal.textContent=rupiah(total);document.getElementById('sumTotalSub').textContent=`Pokok ${rupiah(gross)} • PPN ${rupiah(ppn)} • PPh ${rupiah(pph)}`;paidRatio.textContent=`${total?Math.round(paid/total*100):0}%`;debtRatio.textContent=`${total?Math.round(rem/total*100):0}%`;paidRatioNominal.textContent=rupiah(paid);debtRatioNominal.textContent=rupiah(rem);sumOverdue.textContent=rupiah(over.reduce((s,e)=>s+remainingOf(e),0));sumOverdueCount.textContent=`${over.length} transaksi`;document.getElementById('sumDraftCount').textContent=String(drafts.length);document.getElementById('sumDraftValue').textContent=rupiah(draftValue);rows.innerHTML=data.length?data.map(e=>`<tr><td><input type="checkbox" ${selected.has(e.id)?'checked':''} onchange="toggleSelect(${e.id},this.checked)"></td><td>${dateTimeStack(e.date)}</td><td><span class="code-link">${e.code}</span></td><td>${e.sourceData||'Perusahaan'}</td><td><span class="vendor-link">${e.contact||'-'}</span></td><td class="due-cell ${dueToneClass(e)}" title="${dueToneLabel(e)}">${e.due?fmtDate(e.due):'-'}</td><td class="total-strong">${rupiah(totalOf(e)-pphOf(e))}</td><td>${rupiah(remainingOf(e))}</td><td><span class="badge ${e.payStatus==='Lunas'?'lunas':e.payStatus==='Dibayar Sebagian'?'partial':'unpaid'}">${e.payStatus}</span></td><td class="actions"><button class="kebab row-kebab" aria-expanded="false" onclick="toggleMenu(event,${e.id})" aria-label="Buka aksi"><i class="ti ti-dots" aria-hidden="true"></i></button><div class="menu" id="menu${e.id}">${actionMenu(e)}</div></td></tr>`).join(''):`<tr><td colspan="10"><div class="empty">Tidak ada data sesuai pencarian atau filter.</div></td></tr>`;bulkBar.classList.toggle('show',selected.size>0);bulkText.textContent=`${selected.size} transaksi dipilih`;selectAll.checked=data.length>0&&data.every(e=>selected.has(e.id));const active=[filters.source!=='all',quickDue!=='all',filters.pay.length>0,filters.contact.length>0,filters.item.length>0,filters.expense.length>0,filters.account.length>0,filters.due!=='all'].filter(Boolean).length;filterBtn.innerHTML=active?`<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter (${active})`:'<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter';filterBtn.className='btn '+(active?'btn-soft':'btn-secondary')}
function actionMenu(e){if(e.status==='Draft')return `<button onclick="openDetail(${e.id})">Detail</button><button onclick="openForm(${e.id})">Edit Draft</button><button onclick="askDelete(${e.id})">Hapus Draft</button>`;if(e.status==='Terbit')return `<button onclick="openDetail(${e.id})">Detail</button>${e.payStatus!=='Lunas'?`<button onclick="openPayment(${e.id})">Catat Pembayaran</button>`:`<button onclick="openRepeatForm(${e.id})">Catat Lagi</button>`}<button onclick="openPrint(${e.id})">Cetak</button><button onclick="askVoid(${e.id})">Void</button>`;return `<button onclick="openDetail(${e.id})">Detail</button><button onclick="openRepeatForm(${e.id})">Catat Lagi</button><button onclick="openPrint(${e.id})">Cetak</button>`}
function resetRowMenuPosition(menu){
  menu.style.position='';
  menu.style.left='';
  menu.style.right='';
  menu.style.top='';
  menu.style.bottom='';
  menu.style.zIndex='';
}
function toggleMenu(eventOrId,maybeId){
  const event=eventOrId&&typeof eventOrId==='object'?eventOrId:null;
  const id=event?maybeId:eventOrId;
  event?.stopPropagation?.();
  const target=document.getElementById('menu'+id);
  const trigger=event?.currentTarget||document.querySelector(`[onclick*="toggleMenu(event,${id})"]`);
  if(!target||!trigger)return;
  const shouldOpen=!target.classList.contains('show');
  document.querySelectorAll('.menu').forEach(menu=>{
    if(menu!==target)menu.classList.remove('show');
    resetRowMenuPosition(menu);
  });
  document.querySelectorAll('.row-kebab').forEach(button=>button.setAttribute('aria-expanded','false'));
  target.classList.toggle('show',shouldOpen);
  if(!shouldOpen)return;
  trigger.setAttribute('aria-expanded','true');
  target.style.position='fixed';
  target.style.right='auto';
  target.style.bottom='auto';
  target.style.zIndex='900';
  requestAnimationFrame(()=>{
    const buttonRect=trigger.getBoundingClientRect();
    const menuRect=target.getBoundingClientRect();
    const gutter=12;
    let left=buttonRect.right-menuRect.width;
    left=Math.max(gutter,Math.min(left,window.innerWidth-menuRect.width-gutter));
    let top=buttonRect.bottom+8;
    if(top+menuRect.height>window.innerHeight-gutter)top=buttonRect.top-menuRect.height-8;
    target.style.left=`${Math.round(left)}px`;
    target.style.top=`${Math.max(gutter,Math.round(top))}px`;
  });
}
function toggleSelect(id,on){on?selected.add(id):selected.delete(id);renderList()}
function toggleSelectAll(on){filteredRows().forEach(e=>on?selected.add(e.id):selected.delete(e.id));renderList()}
let exportContext='filtered';
let exportState={status:null,output:null,format:null};
function checkedRadio(name,fallback=null){return document.querySelector(`input[name="${name}"]:checked`)?.value||fallback}
function exportSearchContext(ignoreTab=false){
  let data=exportContext==='selected'?expenses.filter(expense=>selected.has(expense.id)):filteredBase();
  const query=(document.getElementById('searchInput')?.value||'').trim().toLowerCase();
  if(query) data=data.filter(expense=>`${expense.code} ${expense.sourceData||'Perusahaan'} ${expense.title} ${expense.contact} ${expense.items.map(item=>item.item).join(' ')}`.toLowerCase().includes(query));
  if(!ignoreTab&&exportContext!=='selected') data=data.filter(expense=>expense.status===activeTab);
  return data;
}
function exportCandidates(){
  const base=exportState.status&&exportContext!=='selected'?exportSearchContext(true):exportSearchContext(false);
  return exportState.status?base.filter(expense=>expense.status===exportState.status):base;
}
function clearExportRadios(){document.querySelectorAll('#exportModal input[type="radio"]').forEach(input=>input.checked=false)}
function openExport(scope){
  exportContext=scope==='selected'?'selected':'filtered';
  exportState={status:null,output:null,format:null};
  clearExportRadios();
  openModal('exportModal');
  refreshExportUI();
}
function setExportStatus(status){exportState.status=status;refreshExportUI()}
function setExportType(output){exportState.output=output;exportState.format=output==='documents'?'pdf':null;document.querySelectorAll('input[name="exportFormat"]').forEach(input=>input.checked=false);refreshExportUI()}
function setExportFormat(format){exportState.format=format;refreshExportUI()}
function syncExportOptions(){
  exportState.output=checkedRadio('exportOutput',null);
  exportState.format=exportState.output==='documents'?'pdf':checkedRadio('exportFormat',null);
  refreshExportUI();
}
function refreshExportUI(){
  const selectedMode=exportContext==='selected';
  ['Void','Draft','Terbit'].forEach(status=>{
    const count=document.getElementById(`scopeCount${status}`);
    if(count) count.textContent=`${exportSearchContext(true).filter(expense=>expense.status===status).length} data`;
  });
  const statusGroup=document.getElementById('exportStatusGroup');
  const info=document.getElementById('exportInfoBanner');
  const selectedSummary=document.getElementById('exportSelectedSummary');
  if(statusGroup) statusGroup.hidden=selectedMode;
  if(info){info.hidden=selectedMode;info.style.display=selectedMode?'none':'flex'}
  if(selectedSummary){selectedSummary.hidden=!selectedMode;selectedSummary.textContent=selectedMode?`${selected.size} transaksi dipilih untuk diekspor.`:''}
  const formatGroup=document.getElementById('exportFormatGroup');
  if(formatGroup) formatGroup.hidden=exportState.output!=='list';
  const data=exportCandidates();
  const validChoice=!!exportState.output&&(exportState.output==='documents'||!!exportState.format);
  const validation=document.getElementById('exportValidation');
  const noData=validChoice&&!data.length;
  if(validation){validation.textContent=noData?'Tidak ada data yang dapat diekspor untuk pilihan ini.':'';validation.classList.toggle('show',noData)}
  const button=document.getElementById('runExportBtn');
  if(button) button.disabled=!validChoice||!data.length;
  const title=document.getElementById('exportModalTitle');
  const subtitle=document.getElementById('exportModalSubtitle');
  if(title) title.textContent=selectedMode?'Ekspor Data Terpilih':'Pengaturan Ekspor';
  if(subtitle) subtitle.textContent=selectedMode?'Hanya transaksi yang dipilih akan masuk ke proses ekspor.':'Pilih tipe ekspor dan format file yang dibutuhkan.';
}
function updateExportSummary(){refreshExportUI()}
function runExport(){
  const data=exportCandidates();
  const validChoice=!!exportState.output&&(exportState.output==='documents'||!!exportState.format);
  if(!validChoice||!data.length){refreshExportUI();return}
  const effectiveFormat=exportState.output==='documents'?'pdf':exportState.format;
  const outputText=exportState.output==='documents'?'Detail Biaya':'Daftar Biaya';
  const formatText=effectiveFormat==='xlsx'?'Excel (.xlsx)':'PDF';
  const statusText=exportState.status||'filter dan tab aktif';
  showToast(`Ekspor ${outputText} untuk ${data.length} transaksi (${statusText}) dalam format ${formatText} sedang diproses.`);
  closeModal('exportModal');
}
function importIcon(name){const paths={folder:'<path d="M3 7a2 2 0 0 1 2 -2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z" fill="currentColor" stroke="none"/>',check:'<path d="M5 12l5 5l10 -10"/>',x:'<path d="M18 6l-12 12M6 6l12 12"/>',alert:'<circle cx="12" cy="12" r="9"/><path d="M12 8v4M12 16h.01"/>',info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'};return `<svg class="import-pattern-svg" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`}
let importStep=1,importFileName='',importFileSize=0,importStatus='idle',importError='',importImportedCount=0,importCreated=false,importTimer=null,importValidationTotal=6,importValidationNeedsFix=2,importCorrectionMode=false;
function openImportPage(){resetImportFlow();renderImportPage();showPage('import')}
function resetImportFlow(){if(importTimer)clearTimeout(importTimer);importStep=1;importFileName='';importFileSize=0;importStatus='idle';importError='';importImportedCount=0;importCreated=false;importValidationTotal=6;importValidationNeedsFix=2;importCorrectionMode=false}
function renderImportStepHeader(step,title){return `<div class="import-pattern-step"><span class="import-pattern-step-number">${step}</span><div><div class="import-pattern-step-caption">Langkah ${step} dari 3</div><strong>${title}</strong></div></div><div class="import-pattern-divider"></div>`}
function renderImportInstruction(number,title,description,extra=''){return `<div class="import-pattern-instruction"><span class="import-pattern-instruction-number">${number}</span><div class="import-pattern-instruction-copy"><strong>${title}</strong><p>${description}</p>${extra}</div></div>`}
function renderImportFileCard(){if(!importFileName)return '';return `<div class="import-pattern-file-card"><span class="import-pattern-file-status">${importIcon('check')}</span><div class="import-pattern-file-copy"><strong>${escapeUploadText(importFileName)}</strong><span>${formatUploadSize(importFileSize)}</span></div><button type="button" class="import-pattern-file-remove" onclick="removeImportFile()" aria-label="Hapus file">${importIcon('x')}</button></div>`}
function renderImportUploader(){const hasFile=Boolean(importFileName);if(hasFile)return renderImportFileCard();return `<input id="importFileInput" class="import-pattern-file-input" type="file" accept=".xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onchange="setImportFile(this.files[0]);this.value=''"><div class="import-pattern-uploader ${importError?'has-error':''}" role="button" tabindex="0" onclick="document.getElementById('importFileInput').click()" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();document.getElementById('importFileInput').click()}" ondragenter="setImportDrag(event,true)" ondragover="setImportDrag(event,true)" ondragleave="setImportDrag(event,false)" ondrop="handleImportDrop(event)"><span class="import-pattern-folder">${importIcon('folder')}</span><div><strong>Unggah file</strong><span> atau seret kesini</span></div><small>Format file yang didukung: .xls, .xlsx</small></div>${importError?`<div class="import-pattern-error">${importIcon('alert')}${escapeUploadText(importError)}</div>`:''}`}
function renderImportUpload(){return `<div class="import-pattern-card">${renderImportStepHeader(1,'Upload File')}<div class="import-pattern-instructions">${renderImportInstruction(1,'Unduh template Biaya','Gunakan template Excel resmi GroApp agar data Biaya dapat diproses dengan benar.',`<button class="btn btn-secondary import-template-button" type="button" onclick="downloadImportTemplate()">Unduh Template</button>`)}${renderImportInstruction(2,'Isi data Biaya di template','Lengkapi data Biaya sesuai panduan pengisian pada template. Jangan mengubah struktur kolom agar file dapat dibaca oleh sistem.')}${renderImportInstruction(3,'Upload file template yang sudah diisi','Upload file Excel yang sudah diisi. Sistem akan membaca dan mengecek data sebelum Biaya disimpan.',renderImportUploader())}</div></div><div class="import-pattern-footer"><button class="btn btn-secondary" type="button" onclick="showPage('list')">Batal</button><button class="btn btn-primary" type="button" ${importFileName?'':'disabled'} onclick="goImportValidation()">Cek Data</button></div>`}
function renderImportValidation(){const total=importValidationTotal,needsFix=importValidationNeedsFix,valid=Math.max(0,total-needsFix),hasIssues=needsFix>0;const issuePanel=hasIssues?`<div class="import-validation-action"><div><strong>${needsFix} data belum valid</strong><span>Perbaiki data tersebut sebelum melanjutkan impor.</span></div><button class="btn btn-primary" type="button" onclick="prepareImportCorrection()">Perbaiki Data Impor</button></div>`:'';return `<div class="import-pattern-card">${renderImportStepHeader(2,'Hasil Validasi')}<div class="import-validation-summary"><div><span>Semua Data</span><strong>${total}</strong></div><div><span>Data Valid</span><strong>${valid}</strong></div><div class="${hasIssues?'is-invalid':''}"><span>Perlu Diperbaiki</span><strong>${needsFix}</strong></div></div>${issuePanel}</div><div class="import-pattern-footer"><button class="btn btn-secondary" type="button" onclick="showPage('list')">Batal</button><button class="btn btn-primary" type="button" ${hasIssues?'disabled':''} onclick="startImportProcess()">Impor Sekarang</button></div>`}
function renderImportResult(){return `<div class="import-pattern-card import-result-card-figma">${renderImportStepHeader(3,'Selesai')}<div class="import-pattern-result"><span class="import-pattern-success-icon">${importIcon('check')}</span><h2>Impor Biaya Berhasil</h2><p>${importImportedCount||6} data Biaya berhasil ditambahkan ke sistem.</p></div></div><div class="import-pattern-footer"><button class="btn btn-secondary" type="button" onclick="resetImportFlow();renderImportPage()">Impor Data Lain</button><button class="btn btn-primary" type="button" onclick="renderList();showPage('list')">Ke Daftar Biaya</button></div>`}
function renderImportLoadingOverlay(label){return `<div class="import-pattern-loading-overlay" role="status" aria-live="polite"><div class="import-pattern-spinner-card"><span class="import-pattern-spinner"></span><span class="sr-only">${label}</span></div></div>`}
function renderImportPage(){const root=document.getElementById('importContent');if(!root)return;root.innerHTML=importStep===1?renderImportUpload():importStep===2?renderImportValidation():renderImportResult();if(importStatus==='checking')root.insertAdjacentHTML('beforeend',renderImportLoadingOverlay('Memeriksa data'));if(importStatus==='importing')root.insertAdjacentHTML('beforeend',renderImportLoadingOverlay('Mengimpor data'))}
function downloadImportTemplate(){const header=['Tanggal','Vendor','Keterangan','Item','Linked CoA','Nominal','Pajak','Status Pembayaran','Jatuh Tempo','Rekening'].join('\t');const sample=['17/07/2026','Telkom Indonesia','Internet kantor Juli','Internet Kantor','Biaya Internet','1500000','PPN 11%','Bayar Nanti','31/07/2026',''].join('\t');const blob=new Blob([header+'\n'+sample],{type:'application/vnd.ms-excel;charset=utf-8'});const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='Template_Impor_Biaya.xls';document.body.appendChild(link);link.click();link.remove();URL.revokeObjectURL(url);showToast('Template Impor Biaya berhasil diunduh.','info')}
function setImportDrag(event,active){event.preventDefault();event.currentTarget?.classList.toggle('is-dragging',active)}
function setImportFile(file){if(!file)return;importError='';const name=String(file.name||''),valid=/\.xls(x)?$/i.test(name)||['application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'].includes(file.type);if(!valid){importFileName='';importFileSize=0;importError='Format file harus .xls atau .xlsx.';renderImportPage();return}if(file.size<=0){importFileName='';importFileSize=0;importError='File belum berisi data. Isi minimal 1 baris data lalu unggah ulang.';renderImportPage();return}if(file.size>10*1024*1024){importFileName='';importFileSize=0;importError='Ukuran file maksimal 10 MB.';renderImportPage();return}importFileName=name;importFileSize=file.size;renderImportPage()}
function handleImportDrop(event){event.preventDefault();setImportDrag(event,false);const file=event.dataTransfer?.files?.[0];if(file)setImportFile(file)}
function removeImportFile(){importFileName='';importFileSize=0;importError='';renderImportPage()}
function goImportValidation(){if(!importFileName){importError='Pilih file Excel terlebih dahulu.';renderImportPage();return}importStatus='checking';renderImportPage();importTimer=setTimeout(()=>{importStatus='idle';importValidationNeedsFix=importCorrectionMode?0:2;importStep=2;renderImportPage()},850)}
function prepareImportCorrection(){openModal('importCorrectionModal')}
function downloadImportValidationNotes(){const rows=[['Baris','Kolom','Masalah','Rekomendasi'],['3','Vendor','Vendor tidak ditemukan','Gunakan nama vendor yang tersedia atau tambahkan vendor terlebih dahulu'],['5','Nominal','Nominal tidak valid','Isi nominal menggunakan angka lebih dari 0']];const content=rows.map(row=>row.map(value=>`"${String(value).replace(/"/g,'""')}"`).join(',')).join('\n');const blob=new Blob([content],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob),anchor=document.createElement('a');anchor.href=url;anchor.download='Catatan-Validasi-Impor-Biaya.csv';document.body.appendChild(anchor);anchor.click();anchor.remove();URL.revokeObjectURL(url);showToast('Catatan validasi berhasil diunduh.','info')}
function handleImportCorrectionFile(file){if(!file)return;const name=String(file.name||''),valid=/\.xls(x)?$/i.test(name)||['application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'].includes(file.type);if(!valid){showToast('Format file harus .xls atau .xlsx.','error');return}if(file.size<=0){showToast('File belum berisi data.','error');return}if(file.size>10*1024*1024){showToast('Ukuran file maksimal 10 MB.','error');return}importCorrectionMode=true;importFileName=name;importFileSize=file.size;importError='';importStep=2;importStatus='checking';closeModal('importCorrectionModal');if(importTimer)clearTimeout(importTimer);renderImportPage();importTimer=setTimeout(()=>{importStatus='idle';importValidationNeedsFix=0;renderImportPage();showToast('Pengecekan ulang selesai. Semua data sudah valid.','info')},850)}
function importedExpenseFixtures(){const rows=[['Telkom Indonesia','Internet kantor hasil impor','Internet Kantor','Biaya Internet',1500000,'ppn11'],['PLN','Listrik kantor hasil impor','Listrik Kantor','Biaya Listrik',2750000,'none'],['Bluebird','Transportasi operasional','Transportasi','Biaya Transportasi',650000,'none'],['PT Gedung Sejahtera','Sewa kantor','Sewa Kantor','Biaya Sewa',5000000,'pph10'],['Vendor ATK','ATK kantor','ATK Kantor','Biaya Administrasi',500000,'none'],['CV Teknik Mandiri','Pemeliharaan mesin','Pemeliharaan','Biaya Pemeliharaan',1850000,'none']];const base=expenses.length+1;return rows.map((row,index)=>({id:Date.now()+index,sourceData:'Perusahaan',code:`EXP-2026-${String(base+index).padStart(4,'0')}`,date:`2026-07-${String(17+index).padStart(2,'0')}T10:00`,contact:row[0],title:row[1],due:'2026-07-31',dueTime:'23:59',status:'Terbit',payStatus:'Belum Dibayar',items:[{item:row[2],desc:'Hasil impor Excel',amount:row[4],tax:row[5],coa:row[3]}],paid:0,payments:[],attachments:[importFileName],createdBy:'Siti Mulyani'}))}
function startImportProcess(){if(importValidationNeedsFix>0){showToast('Masih ada data yang perlu diperbaiki.','error');return}if(importCreated){importStep=3;renderImportPage();return}importStatus='importing';renderImportPage();importTimer=setTimeout(()=>{const imported=importedExpenseFixtures();expenses.unshift(...imported);importImportedCount=imported.length;importCreated=true;importStatus='success';importStep=3;renderList();renderImportPage();showToast('Impor selesai. Semua data valid berhasil ditambahkan.','info')},950)}
function completeImport(){startImportProcess()}
function nextCode(){return `EXP-2026-${String(expenses.length+1).padStart(4,'0')}`}
function localDateTimeValue(date=new Date()){const pad=n=>String(n).padStart(2,'0');return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`}
function displayCreatedAt(value){return new Intl.DateTimeFormat('id-ID',{day:'2-digit',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date(value))}
const loggedInUserName='Siti Mulyani';
function blankForm(){
  const now=localDateTimeValue();
  return {step:1,maxStepReached:1,previewUnlocked:false,sourceData:'Perusahaan',sourceDropdownOpen:false,code:nextCode(),date:now,contact:'',title:'',createdAt:now,createdBy:loggedInUserName,due:'',dueTime:'23:59',items:[],attachments:[],paymentType:'partial',account:accounts[0],payAmount:0,payDate:now,evidence:'',evidenceFiles:[],editing:false,vendorQuery:'',vendorSearchOpen:false,vendorPhoneIndex:null,vendorEmailIndex:null,vendorAddressIndex:null,receiverAccountId:'',vendorManagerOpen:false,vendorManagerDraft:null,itemQuery:'',itemSearchOpen:false,scanReceiptState:'idle',scanReceiptName:''}
}
function syncExpenseVendorSelection(){
  const vendor=getVendorDetail(formState?.contact);
  if(!formState)return;
  if(!vendor){formState.vendorPhoneIndex=null;formState.vendorEmailIndex=null;formState.vendorAddressIndex=null;formState.receiverAccountId='';return}
  normalizeExpenseVendor(vendor,vendorRecords.indexOf(vendor));
  const phones=expenseVendorPhoneOptions(vendor),emails=expenseVendorEmailOptions(vendor),addresses=expenseVendorAddressOptions(vendor),accountsList=expenseVendorAccountOptions(vendor);
  if(formState.vendorPhoneIndex===null||formState.vendorPhoneIndex>=phones.length)formState.vendorPhoneIndex=phones.length?0:null;
  if(formState.vendorEmailIndex===null||formState.vendorEmailIndex>=emails.length)formState.vendorEmailIndex=emails.length?0:null;
  if(formState.vendorAddressIndex===null||formState.vendorAddressIndex>=addresses.length)formState.vendorAddressIndex=addresses.length?0:null;
  if(!accountsList.some(account=>account.id===formState.receiverAccountId))formState.receiverAccountId=accountsList[0]?.id||'';
}
function openForm(id=null){editingId=id;expenseUploadState={};expenseUploadErrors=[];paymentEvidenceState={};paymentEvidenceErrors=[];formState=blankForm();if(id){const e=expenses.find(x=>x.id===id);formState={...formState,editing:true,sourceData:e.sourceData||'Perusahaan',code:e.code,date:e.date,contact:e.contact,title:e.title,createdAt:e.createdAt||e.date,createdBy:e.createdBy||loggedInUserName,due:e.due,dueTime:e.dueTime||'23:59',items:e.items.map((i,k)=>({...i,id:k+1})),attachments:[...e.attachments],paymentType:e.payStatus==='Lunas'?'full':e.paid>0?'partial':'later',account:e.payments[0]?.account||accounts[0],payAmount:e.paid,payDate:e.payments[0]?.date||'2026-07-17T10:00',evidenceFiles:Array.isArray(e.payments[0]?.evidence)?[...e.payments[0].evidence]:e.payments[0]?.evidence?[e.payments[0].evidence]:[],vendorQuery:''}}syncExpenseVendorSelection();renderForm();showPage('form')}
function openRepeatForm(id){const e=expenses.find(x=>x.id===id);if(!e)return;editingId=null;expenseUploadState={};expenseUploadErrors=[];paymentEvidenceState={};paymentEvidenceErrors=[];formState={...blankForm(),sourceData:e.sourceData||'Perusahaan',date:e.date,contact:e.contact,title:e.title,due:e.due||'',dueTime:e.dueTime||'23:59',items:e.items.map((i,k)=>({...i,id:k+1})),attachments:[...(e.attachments||[])],paymentType:e.payStatus==='Lunas'?'full':e.paid>0?'partial':'later',account:e.payments?.[0]?.account||accounts[0],payAmount:e.paid>0&&e.payStatus!=='Lunas'?e.paid:0,payDate:'2026-07-17T10:00',vendorQuery:''};syncExpenseVendorSelection();renderForm();showPage('form');showToast('Data transaksi sebelumnya sudah disalin. Silakan periksa sebelum disimpan.','info')}
function renderForm(){
  const wizardHead=document.getElementById('expenseWizardHead');
  const layout=document.getElementById('formLayout');
  if(wizardHead)wizardHead.hidden=false;
  if(layout)layout.classList.remove('vendor-manager-layout');
  pageTitle.textContent=formState.editing?'Edit Draft Biaya':'Tambah Biaya';
  breadcrumb.textContent='Transaksi / Biaya / Tambah';
  const labels=[step1Label,step2Label,step3Label,step4Label];
  const maxStep=Math.max(Number(formState.maxStepReached)||1,Number(formState.step)||1,formState.previewUnlocked?4:1);
  labels.forEach((el,index)=>{
    const step=index+1;
    const active=formState.step===step;
    const reached=step<=maxStep;
    el.className='expense-step '+(active?'active':reached?'done':'');
    el.disabled=!reached;
    el.setAttribute('aria-current',active?'step':'false');
    const number=el.querySelector('.expense-step-number');
    if(number)number.innerHTML=active?String(step):reached?'<i class="ti ti-check" aria-hidden="true"></i>':String(step);
  });
  expenseWizardTitle.textContent=formState.editing?'Edit Draft Biaya':'Tambah Biaya';
  const renderers=[renderTransactionStep,renderItemsStep,renderPaymentStep,renderPreviewStep];
  formMain.innerHTML=renderers[formState.step-1]();
  renderFormSummary();
  populateMasterSelects();
}
function jumpExpenseStep(step){
  const maxStep=Math.max(Number(formState.maxStepReached)||1,Number(formState.step)||1,formState.previewUnlocked?4:1);
  if(step>maxStep)return;
  formState.step=step;
  renderForm();
  window.scrollTo({top:0,behavior:'smooth'});
}
function expenseSectionTitle(number,title,description){return `<div class="expense-section-title"><span class="expense-section-number">${number}</span><div class="expense-section-copy"><h2>${title}</h2></div></div>`}
function expenseWizardFooter({back=true,nextLabel='Lanjutkan',final=false}={}){
  return `<div class="expense-wizard-footer"><div>${back?`<button class="btn btn-secondary" type="button" onclick="previousExpenseStep()"><i class="ti ti-arrow-left" aria-hidden="true"></i>Kembali</button>`:''}</div><div class="expense-wizard-footer-actions"><button class="btn btn-secondary" type="button" onclick="saveExpense('Draft')">Simpan Draft</button>${final?`<button class="btn btn-primary" type="button" onclick="saveExpense('Terbit')">Terbitkan Biaya</button>`:`<button class="btn btn-primary" type="button" onclick="nextExpenseStep()">${nextLabel}<i class="ti ti-arrow-right" aria-hidden="true"></i></button>`}</div></div>`
}
function validateExpenseStep(step){
  if(step===1){
    if(!sourceOptions.includes(formState.sourceData)){showToast('Sumber Data wajib dipilih.','error');return false}
    if(!formState.date){showToast('Tanggal dan Waktu Transaksi wajib diisi.','error');return false}
    const contact=String(formState.contact||'').trim();
    if(contact&&!availableVendors(formState.sourceData||'Perusahaan').some(v=>v.toLowerCase()===contact.toLowerCase())){showToast('Pilih Vendor yang tersedia pada daftar.','error');return false}
  }
  if(step===2){
    if(!formState.items.length){showToast('Tambahkan minimal satu Item Biaya.','error');return false}
    if(formState.items.some(i=>!i.item||Number(i.amount)<=0)){showToast('Lengkapi item dan nominal pada seluruh Item Biaya.','error');return false}
  }
  if(step===3)return validatePaymentStep();
  return true;
}
function nextExpenseStep(){
  if(!validateExpenseStep(formState.step))return;
  formState.step=Math.min(formState.step+1,4);
  formState.maxStepReached=Math.max(Number(formState.maxStepReached)||1,formState.step);
  if(formState.step===4)formState.previewUnlocked=true;
  renderForm();
  window.scrollTo({top:0,behavior:'smooth'});
}
function previousExpenseStep(){
  formState.maxStepReached=Math.max(Number(formState.maxStepReached)||1,Number(formState.step)||1);
  formState.step=Math.max(formState.step-1,1);
  renderForm();
  window.scrollTo({top:0,behavior:'smooth'});
}
function renderInfoStep(){return renderTransactionStep()}
function requestSourceChange(value){
  const next=String(value||'').trim();
  if(!sourceOptions.includes(next)){showToast('Pilih Sumber Data yang tersedia.','error');return}
  formState.sourceData=next;
  formState.sourceDropdownOpen=false;
  if(formState.contact&&!availableVendors(next).some(name=>name.toLowerCase()===formState.contact.toLowerCase())){
    formState.contact='';formState.vendorQuery='';formState.vendorSearchOpen=false;
  }
  if(!availableAccounts(next).includes(formState.account))formState.account=availableAccounts(next)[0]||'';
  syncExpenseVendorSelection();
  renderForm();
}
function expenseSourceOption(value,label,description,icon){
  const active=formState.sourceData===value;
  return `<button type="button" class="expense-source-option ${active?'selected':''}" role="option" aria-selected="${active}" onclick="event.stopPropagation();requestSourceChange('${expenseEscape(value)}')"><span class="expense-source-option-icon"><i class="ti ${icon}" aria-hidden="true"></i></span><span class="expense-source-option-copy"><strong>${expenseEscape(label)}</strong><small>${expenseEscape(description)}</small></span>${active?'<i class="ti ti-check expense-source-check" aria-hidden="true"></i>':''}</button>`;
}
function renderExpenseSourceOptions(){
  const units=sourceOptions.filter(value=>value!=='Perusahaan');
  return `<div class="expense-source-group"><div class="expense-source-group-label">Perusahaan</div>${expenseSourceOption('Perusahaan','Perusahaan','Sumber data perusahaan utama','ti-building')}</div><div class="expense-source-group"><div class="expense-source-group-label">Unit Usaha</div>${units.map(value=>expenseSourceOption(value,value,'Unit usaha di bawah Perusahaan','ti-building-store')).join('')}</div>`;
}
function toggleExpenseSourceDropdown(event){
  event?.stopPropagation();
  formState.sourceDropdownOpen=!formState.sourceDropdownOpen;
  const menu=document.getElementById('expenseSourceMenu');
  const trigger=document.getElementById('expenseSourceTrigger');
  if(menu)menu.classList.toggle('show',formState.sourceDropdownOpen);
  if(trigger)trigger.setAttribute('aria-expanded',String(formState.sourceDropdownOpen));
}
function closeExpenseSourceDropdown(){
  if(!formState)return;
  formState.sourceDropdownOpen=false;
  document.getElementById('expenseSourceMenu')?.classList.remove('show');
  document.getElementById('expenseSourceTrigger')?.setAttribute('aria-expanded','false');
}

function expenseDatePart(value){return String(value||'').slice(0,10)}
function expenseTimePart(value){const text=String(value||'');return text.includes('T')?text.slice(11,16):'00:00'}
function setExpenseTransactionDate(value){const date=value||expenseDatePart(localDateTimeValue());formState.date=`${date}T${expenseTimePart(formState.date)||'00:00'}`}
function setExpenseTransactionTime(value){const time=value||'00:00';formState.date=`${expenseDatePart(formState.date)||expenseDatePart(localDateTimeValue())}T${time}`}
function expenseVendorReadOnlyCard(){
  const vendor=getVendorDetail(formState.contact);
  if(!vendor)return `<div class="vendor-readonly-empty"><i class="ti ti-building-store" aria-hidden="true"></i><div><strong>Belum ada vendor dipilih</strong><span>Cari dan pilih vendor dari database Kontak. Informasi vendor hanya dapat dilihat.</span></div></div>`;
  const address=vendor.addresses?.[0]||vendor.address||'-';
  return `<div class="vendor-readonly-card"><div class="vendor-readonly-head"><div><span>DATA VENDOR</span><strong>${expenseEscape(vendor.name)}</strong></div><i class="ti ti-lock" aria-label="Data vendor read-only"></i></div><div class="vendor-readonly-grid"><div><span>No. HP/WA</span><strong>${expenseEscape(vendor.phone||'-')}</strong></div><div><span>Email</span><strong>${expenseEscape(vendor.email||'-')}</strong></div><div class="vendor-readonly-address"><span>Alamat</span><strong>${expenseEscape(address)}</strong></div></div></div>`;
}
function renderScanReceiptStatus(){
  const name=expenseEscape(formState.scanReceiptName||'Gambar nota');
  if(formState.scanReceiptState==='processing')return `<div class="expense-upload-list scan-upload-list"><div class="expense-upload-card"><div class="expense-upload-head"><span class="expense-upload-status-icon"><i class="ti ti-folder-filled" aria-hidden="true"></i></span><div class="expense-upload-meta"><div class="expense-upload-name">${name}</div><div class="expense-upload-size">Sedang memindai nota</div></div><button type="button" class="expense-upload-remove" aria-label="Batalkan scan" onclick="resetScanReceipt()"><i class="ti ti-x" aria-hidden="true"></i></button></div><div class="expense-upload-progress-row"><div class="expense-upload-track"><div class="expense-upload-bar" style="width:70%"></div></div><span class="expense-upload-percent">70%</span></div></div></div>`;
  if(formState.scanReceiptState==='done')return `<div class="expense-upload-list scan-upload-list"><div class="expense-upload-card"><div class="expense-upload-head"><span class="expense-upload-status-icon success"><i class="ti ti-check" aria-hidden="true"></i></span><div class="expense-upload-meta"><div class="expense-upload-name">${name}</div><div class="expense-upload-size">Data nota berhasil diterapkan</div><button type="button" class="expense-upload-action" onclick="previewAttachment('${name.replace(/'/g,"\\'")}')">Preview</button></div><button type="button" class="expense-upload-remove" aria-label="Hapus hasil scan" onclick="resetScanReceipt()"><i class="ti ti-x" aria-hidden="true"></i></button></div></div></div>`;
  return '';
}
function resetScanReceipt(){if(!formState)return;formState.scanReceiptState='idle';formState.scanReceiptName='';renderForm()}
function renderScanReceiptUploader(){
  const disabled=formState.scanReceiptState==='processing';
  const count=formState.scanReceiptName?'1/1':'0/1';
  return `<div class="expense-uploader scan-figma-uploader"><div class="expense-uploader-label"><span>Scan Nota</span><span class="expense-upload-count">${count}</span></div><div class="expense-upload-description">Pindai gambar nota untuk mengisi data transaksi dan item secara otomatis.</div><input id="scanReceiptInput" class="expense-upload-input" type="file" accept="image/*" capture="environment" onchange="scanExpenseReceipt(this.files[0]);this.value=''"/><div class="expense-upload-dropzone ${disabled?'is-disabled':''}" role="button" tabindex="0" onclick="${disabled?'':'document.getElementById(\'scanReceiptInput\').click()'}" onkeydown="if(!${disabled}&&(event.key==='Enter'||event.key===' ')){event.preventDefault();document.getElementById('scanReceiptInput').click()}" ondragenter="setGenericUploaderDrag(event,true)" ondragover="setGenericUploaderDrag(event,true)" ondragleave="setGenericUploaderDrag(event,false)" ondrop="handleScanReceiptDrop(event)"><span class="expense-upload-icon" aria-hidden="true"><i class="ti ti-folder-filled"></i></span><div class="expense-upload-copy"><strong>${disabled?'Sedang memindai':'Unggah gambar nota'}</strong>${disabled?'':' atau seret kesini'}</div><div class="expense-upload-hint">Maks. ukuran file 10 MB</div></div>${renderScanReceiptStatus()}</div>`;
}
function handleScanReceiptDrop(event){event.preventDefault();setGenericUploaderDrag(event,false);const file=event.dataTransfer?.files?.[0];if(file)scanExpenseReceipt(file)}
function scanExpenseReceipt(file){
  if(!file)return;
  const validImage=String(file.type||'').startsWith('image/')||/\.(png|jpe?g|webp)$/i.test(file.name||'');
  if(!validImage){showToast('Scan Nota hanya menerima file gambar.','error');return}
  if(file.size>10*1024*1024){showToast('Ukuran gambar nota maksimal 10 MB.','error');return}
  formState.scanReceiptState='processing';
  formState.scanReceiptName=file.name;
  if(!formState.attachments.includes(file.name))addAttachments([file]);
  renderForm();
  setTimeout(()=>{
    if(!formState)return;
    const vendor=expenseAvailableVendorRecords()[0];
    const master=availableMasterItems(formState.sourceData||'Perusahaan').find(item=>item.active);
    if(vendor){formState.contact=vendor.name;formState.vendorQuery='';syncExpenseVendorSelection()}
    if(!formState.title.trim())formState.title=`Biaya hasil scan ${String(file.name||'nota').replace(/\.[^.]+$/,'')}`;
    if(!formState.items.length&&master)formState.items.push({id:Date.now(),item:master.name,desc:master.desc||'Hasil pemindaian nota',amount:185000,tax:master.ppn?'ppn11':master.pph?'pph10':'none',coa:master.coa||''});
    formState.scanReceiptState='done';
    renderForm();
    showToast('Scan Nota selesai. Data transaksi terisi dan gambar masuk ke Lampiran Step 2.','info');
  },900);
}
function renderTransactionStep(){
  const source=formState.sourceData||'Perusahaan';
  return `<div class="card subsection wizard-step-card">${expenseSectionTitle(1,'Informasi Transaksi','Lengkapi sumber data, tanggal dan waktu, pilih vendor, lalu tambahkan keterangan bila diperlukan atau gunakan Scan Nota.')}<div class="scan-receipt-section scan-receipt-top">${renderScanReceiptUploader()}</div><div class="transaction-grid transaction-grid-v21"><div class="field expense-source-field"><label>Sumber Data *</label><div class="expense-source-select"><button id="expenseSourceTrigger" type="button" class="expense-source-trigger" role="combobox" aria-haspopup="listbox" aria-expanded="${Boolean(formState.sourceDropdownOpen)}" onclick="toggleExpenseSourceDropdown(event)"><span class="expense-source-trigger-value"><i class="ti ${source==='Perusahaan'?'ti-building':'ti-building-store'}" aria-hidden="true"></i><span>${expenseEscape(source)}</span></span><i class="ti ti-chevron-down expense-source-chevron" aria-hidden="true"></i></button><div id="expenseSourceMenu" class="expense-source-menu ${formState.sourceDropdownOpen?'show':''}" role="listbox">${renderExpenseSourceOptions()}</div></div><div class="field-help">Pilih Perusahaan atau Unit Usaha yang menjadi pemilik transaksi.</div></div><div class="transaction-date-time"><div class="field transaction-date-field"><label>Tanggal Transaksi *</label><input type="date" class="input" value="${expenseDatePart(formState.date)}" onchange="setExpenseTransactionDate(this.value)"></div><div class="field transaction-time-field"><label>Waktu *</label><input type="time" class="input" value="${expenseTimePart(formState.date)}" onchange="setExpenseTransactionTime(this.value)"></div><div class="field-help">Tanggal transaksi menjadi periode jurnal saat transaksi diterbitkan.</div></div><div class="transaction-section-divider" role="separator" aria-label="Pembatas Informasi Vendor"></div><div class="transaction-vendor-section"><div class="subsection-title">Vendor</div><div class="expense-vendor-select"><button id="expenseVendorTrigger" type="button" class="expense-vendor-trigger" role="combobox" aria-haspopup="listbox" aria-expanded="${Boolean(formState.vendorSearchOpen)}" onclick="toggleExpenseVendorDropdown(event)"><span class="expense-vendor-trigger-value ${formState.contact?'':'placeholder'}"><i class="ti ti-building-store" aria-hidden="true"></i><span>${formState.contact?expenseEscape(formState.contact):'Pilih vendor'}</span></span><i class="ti ti-chevron-down expense-vendor-chevron" aria-hidden="true"></i></button><div class="vendor-search-popover expense-vendor-menu ${formState.vendorSearchOpen?'show':''}" id="expenseVendorSearchPopover" role="listbox"><div class="expense-vendor-menu-search"><i class="ti ti-search" aria-hidden="true"></i><input id="expenseVendorSearchInput" value="${expenseEscape(formState.vendorQuery||'')}" placeholder="Cari vendor..." oninput="searchExpenseVendor(this.value)" onclick="event.stopPropagation()" autocomplete="off"></div><div class="expense-vendor-options" id="expenseVendorOptions">${expenseVendorRows()}</div><div class="expense-vendor-menu-footer"><button class="btn btn-secondary" type="button" onclick="event.stopPropagation();openVendorModal()"><i class="ti ti-plus" aria-hidden="true"></i>Tambah Vendor</button></div></div></div>${expenseVendorReadOnlyCard()}<div class="field-help">Klik field Vendor, lalu gunakan pencarian di dalam dropdown untuk memilih vendor.</div></div><div class="field transaction-description-field"><label>Keterangan <span class="optional">Opsional</span></label><textarea class="transaction-description" rows="5" placeholder="Contoh: Listrik kantor Juli" oninput="setForm('title',this.value)">${expenseEscape(formState.title||'')}</textarea><div class="field-help">Keterangan dapat dikosongkan dan diisi bila diperlukan untuk memudahkan identifikasi transaksi.</div></div></div>${expenseWizardFooter({back:false,nextLabel:'Lanjut ke Item'})}</div>`;
}
function expenseVendorPhoneOptions(vendor){if(!vendor)return[];const options=[];if(vendor.phone)options.push({id:'primary-phone',label:vendor.phone,primary:true,kind:'primary'});vendor.additionalContacts.filter(item=>item.type==='phone'&&item.value).forEach(item=>options.push({id:item.id,label:item.value,primary:false,kind:'additional'}));return options}
function expenseVendorEmailOptions(vendor){if(!vendor)return[];const options=[];if(vendor.email)options.push({id:'primary-email',label:vendor.email,primary:true,kind:'primary'});vendor.additionalContacts.filter(item=>item.type==='email'&&item.value).forEach(item=>options.push({id:item.id,label:item.value,primary:false,kind:'additional'}));return options}
function expenseVendorAddressOptions(vendor){return (vendor?.addresses||[]).map((label,index)=>({id:`address-${index}`,label,primary:index===0,index}))}
function expenseVendorAccountOptions(vendor){return (vendor?.accounts||[]).map((item,index)=>({id:item.id,label:`${item.holder||vendor.name} · ${item.bank||'-'} · ${item.number||item.raw||'-'}`,primary:index===0,index,...item}))}
function expenseAvailableVendorRecords(){const source=formState.sourceData||'Perusahaan',allowed=availableVendors(source).map(name=>name.toLowerCase());return vendorRecords.filter(vendor=>allowed.includes(vendor.name.toLowerCase()))}
function expenseVendorRows(){
  const query=String(formState.vendorQuery||'').trim().toLowerCase();
  const matched=expenseAvailableVendorRecords().filter(vendor=>!query||`${vendor.name} ${vendor.phone} ${vendor.email} ${vendor.additionalContacts.map(item=>item.value).join(' ')}`.toLowerCase().includes(query));
  const rows=matched.slice(0,5);
  if(!rows.length)return `<div class="vendor-search-empty"><strong>Vendor tidak ditemukan</strong><span>Coba kata kunci lain atau tambahkan Vendor baru.</span></div>`;
  return rows.map(vendor=>{const active=vendor.name===formState.contact;return `<button class="vendor-row ${active?'selected':''}" type="button" role="option" aria-selected="${active}" onclick="event.stopPropagation();selectExpenseVendorFromSearch('${expenseEscape(vendor.name)}')"><span class="vendor-row-copy"><strong>${expenseEscape(vendor.name)}</strong><span class="vendor-row-meta"><span>HP/WA: ${expenseEscape(vendor.phone||'-')}</span><span>Email: ${expenseEscape(vendor.email||'-')}</span></span></span>${active?'<i class="ti ti-check vendor-row-check" aria-hidden="true"></i>':''}</button>`}).join('');
}
function syncExpenseVendorDropdown(){
  const popover=document.getElementById('expenseVendorSearchPopover');
  const trigger=document.getElementById('expenseVendorTrigger');
  const options=document.getElementById('expenseVendorOptions');
  if(options)options.innerHTML=expenseVendorRows();
  if(popover)popover.classList.toggle('show',Boolean(formState.vendorSearchOpen));
  if(trigger)trigger.setAttribute('aria-expanded',String(Boolean(formState.vendorSearchOpen)));
}
function searchExpenseVendor(query){formState.vendorQuery=query;formState.vendorSearchOpen=true;syncExpenseVendorDropdown()}
function openExpenseVendorSearch(){formState.vendorSearchOpen=true;syncExpenseVendorDropdown();setTimeout(()=>document.getElementById('expenseVendorSearchInput')?.focus(),0)}
function closeExpenseVendorDropdown(){if(!formState)return;formState.vendorSearchOpen=false;formState.vendorQuery='';syncExpenseVendorDropdown()}
function toggleExpenseVendorDropdown(event){event?.stopPropagation();const next=!formState.vendorSearchOpen;formState.vendorSearchOpen=next;formState.vendorQuery='';syncExpenseVendorDropdown();if(next)setTimeout(()=>document.getElementById('expenseVendorSearchInput')?.focus(),0)}
function selectExpenseVendorFromSearch(name){const vendor=getVendorDetail(name);if(!vendor)return;formState.contact=vendor.name;formState.vendorQuery='';formState.vendorSearchOpen=false;formState.vendorPhoneIndex=null;formState.vendorEmailIndex=null;formState.vendorAddressIndex=null;formState.receiverAccountId='';syncExpenseVendorSelection();renderForm()}
function selectExpenseVendor(name){const value=String(name||'').trim();if(!value){formState.contact='';formState.vendorQuery='';syncExpenseVendorSelection();renderForm();return}const vendor=getVendorDetail(value);if(vendor)selectExpenseVendorFromSearch(vendor.name);else{formState.vendorQuery=value;searchExpenseVendor(value)}}
function closeExpenseContactDropdowns(){document.querySelectorAll('.expense-contact-menu.show').forEach(menu=>menu.classList.remove('show'));document.querySelectorAll('.expense-contact-trigger[aria-expanded="true"]').forEach(trigger=>trigger.setAttribute('aria-expanded','false'))}
function toggleExpenseContactDropdown(key,event){event?.stopPropagation();const menu=document.getElementById(`expenseContactMenu-${key}`),trigger=document.getElementById(`expenseContactTrigger-${key}`);if(!menu||!trigger)return;const open=!menu.classList.contains('show');closeExpenseContactDropdowns();if(open){menu.classList.add('show');trigger.setAttribute('aria-expanded','true')}}
function selectExpenseVendorContact(key,value){const vendor=getVendorDetail(formState.contact);if(!vendor)return;if(key==='phone')formState.vendorPhoneIndex=Number(value);if(key==='email')formState.vendorEmailIndex=Number(value);if(key==='address')formState.vendorAddressIndex=Number(value);if(key==='account')formState.receiverAccountId=value;closeExpenseContactDropdowns();renderForm()}
function expenseContactDropdown({key,title,options,value,valueMode='index',placeholder}){
  const selected=String(value??'');
  const selectedItem=options.find((item,index)=>String(valueMode==='id'?item.id:index)===selected)||null;
  const optionHtml=options.map((item,index)=>{const optionValue=valueMode==='id'?item.id:String(index),active=String(optionValue)===selected;return `<button type="button" class="expense-contact-option ${active?'selected':''}" onclick="event.stopPropagation();selectExpenseVendorContact('${key}','${expenseEscape(optionValue)}')"><span class="option-copy">${expenseEscape(item.label)}</span><span class="option-label">${item.primary?'Utama':'Pendukung'}</span>${active?'<i class="ti ti-check check" aria-hidden="true"></i>':''}</button>`}).join('');
  return `<div class="expense-contact-group"><div class="expense-contact-head"><strong>${title}</strong></div><div class="expense-contact-control"><div class="expense-contact-select"><button type="button" class="expense-contact-trigger" id="expenseContactTrigger-${key}" aria-haspopup="listbox" aria-expanded="false" onclick="toggleExpenseContactDropdown('${key}',event)"><span class="value ${selectedItem?'':'placeholder'}">${selectedItem?`${expenseEscape(selectedItem.label)} · ${selectedItem.primary?'Utama':'Pendukung'}`:placeholder}</span><i class="ti ti-chevron-down chevron" aria-hidden="true"></i></button><div class="expense-contact-menu" id="expenseContactMenu-${key}" role="listbox"><div class="expense-contact-options">${optionHtml||'<div class="expense-contact-empty">Belum ada data tersedia.</div>'}</div></div></div><button type="button" class="expense-contact-edit" onclick="openExpenseVendorFieldEdit('${key}')">Edit <i class="ti ti-pencil" aria-hidden="true"></i></button></div></div>`;
}
function renderVendorStep(){
  const vendor=getVendorDetail(formState.contact);if(vendor)syncExpenseVendorSelection();
  const phones=expenseVendorPhoneOptions(vendor),emails=expenseVendorEmailOptions(vendor),addresses=expenseVendorAddressOptions(vendor),vendorAccounts=expenseVendorAccountOptions(vendor);
  return `<div class="card subsection wizard-step-card">${expenseSectionTitle(2,'Vendor','Cari vendor dari database Kontak, lalu pilih data yang digunakan pada transaksi.')}<div class="expense-vendor-search-toolbar"><div class="expense-vendor-search"><div class="expense-search-box"><i class="ti ti-search" aria-hidden="true"></i><input value="${expenseEscape(formState.vendorQuery||'')}" placeholder="Cari nama vendor..." onfocus="openExpenseVendorSearch()" oninput="searchExpenseVendor(this.value)" autocomplete="off"></div><div class="vendor-search-popover ${formState.vendorSearchOpen&&String(formState.vendorQuery||'').trim()?'show':''}" id="expenseVendorSearchPopover">${expenseVendorRows()}</div></div><button class="btn btn-secondary" type="button" onclick="openVendorModal()"><i class="ti ti-plus" aria-hidden="true"></i>Tambah Vendor</button></div><aside class="selected-vendor ${vendor?'has-data':''}">${vendor?`<div class="selected-vendor-head"><div><div class="selected-label">DATA KONTAK VENDOR</div><h4>${expenseEscape(vendor.name)}</h4></div><button class="btn btn-secondary" type="button" onclick="openExpenseVendorManager()">Kelola</button></div><div class="vendor-contact-grid">${expenseContactDropdown({key:'phone',title:'Nomor HP/WA',options:phones,value:formState.vendorPhoneIndex,placeholder:'Pilih nomor HP/WA'})}${expenseContactDropdown({key:'email',title:'Email',options:emails,value:formState.vendorEmailIndex,placeholder:'Pilih email'})}${expenseContactDropdown({key:'address',title:'Alamat',options:addresses,value:formState.vendorAddressIndex,placeholder:'Pilih alamat'})}${expenseContactDropdown({key:'account',title:'Rekening',options:vendorAccounts,value:formState.receiverAccountId,valueMode:'id',placeholder:'Pilih rekening'})}</div>`:`<div class="vendor-empty-state"><i class="ti ti-building-store" aria-hidden="true"></i><strong>Belum ada vendor dipilih</strong><span>Cari nama vendor pada kolom di atas. Hasil yang sesuai akan muncul sebagai dropdown.</span></div>`}</aside>${expenseWizardFooter({nextLabel:'Lanjut ke Item'})}</div>`
}
function expenseSelectedVendorField(key){
  const vendor=getVendorDetail(formState.contact);if(!vendor)return null;
  if(key==='phone'){const item=expenseVendorPhoneOptions(vendor)[formState.vendorPhoneIndex];return item?{key,id:item.id,kind:item.kind,value:item.label}:null}
  if(key==='email'){const item=expenseVendorEmailOptions(vendor)[formState.vendorEmailIndex];return item?{key,id:item.id,kind:item.kind,value:item.label}:null}
  if(key==='address'){const index=formState.vendorAddressIndex;return Number.isInteger(index)&&vendor.addresses[index]!==undefined?{key,index,value:vendor.addresses[index]}:null}
  if(key==='account'){const account=vendor.accounts.find(item=>item.id===formState.receiverAccountId);return account?{key,id:account.id,bank:account.bank,number:account.number||account.raw,holder:account.holder}:null}
  return null;
}
function openExpenseVendorFieldEdit(key){
  closeExpenseContactDropdowns();const vendor=getVendorDetail(formState.contact),target=expenseSelectedVendorField(key);if(!vendor){showToast('Pilih vendor terlebih dahulu.','error');return}if(!target){showToast('Belum ada data yang dapat diedit. Tambahkan melalui menu Kelola.','error');return}
  vendorFieldEditKey=key;vendorFieldEditTarget=JSON.parse(JSON.stringify(target));
  const labels={phone:'Nomor HP/WA',email:'Email',address:'Alamat',account:'Rekening Bank'};
  vendorFieldEditTitle.textContent=`Edit ${labels[key]}`;vendorFieldEditSubtitle.textContent=`Perubahan hanya diterapkan pada ${labels[key].toLowerCase()} yang sedang dipilih.`;
  if(key==='phone')vendorFieldEditFields.innerHTML=`<div class="field"><label>Nomor HP/WA</label><input id="vendorFieldEditValue" class="input" inputmode="tel" value="${expenseEscape(target.value)}"></div>`;
  if(key==='email')vendorFieldEditFields.innerHTML=`<div class="field"><label>Email</label><input id="vendorFieldEditValue" class="input" type="email" value="${expenseEscape(target.value)}"></div>`;
  if(key==='address')vendorFieldEditFields.innerHTML=`<div class="field"><label>Alamat Lengkap</label><textarea id="vendorFieldEditValue">${expenseEscape(target.value)}</textarea></div>`;
  if(key==='account')vendorFieldEditFields.innerHTML=`<div class="grid-2"><div class="field"><label>Nama Bank</label><input id="vendorFieldEditBank" class="input" list="vendorBankList" value="${expenseEscape(target.bank)}"></div><div class="field"><label>Nomor Rekening</label><input id="vendorFieldEditNumber" class="input" inputmode="numeric" value="${expenseEscape(target.number)}"></div><div class="field" style="grid-column:1/-1"><label>Nama Pemilik Rekening</label><input id="vendorFieldEditHolder" class="input" value="${expenseEscape(target.holder)}"></div></div>`;
  openModal('vendorFieldEditModal');setTimeout(()=>vendorFieldEditFields.querySelector('input,textarea')?.focus(),0);
}
function closeExpenseVendorFieldEdit(){closeModal('vendorFieldEditModal');vendorFieldEditKey='';vendorFieldEditTarget=null}
function saveExpenseVendorFieldEdit(){
  const vendor=getVendorDetail(formState.contact),target=vendorFieldEditTarget,key=vendorFieldEditKey;if(!vendor||!target)return;
  if(key==='phone'||key==='email'){
    const value=document.getElementById('vendorFieldEditValue').value.trim();if(!value){showToast(`${key==='phone'?'Nomor HP/WA':'Email'} wajib diisi.`,'error');return}if(key==='email'&&!/^\S+@\S+\.\S+$/.test(value)){showToast('Format email belum valid.','error');return}
    if(target.kind==='primary')vendor[key]=value;else{const item=vendor.additionalContacts.find(contact=>contact.id===target.id);if(item)item.value=value}
  }
  if(key==='address'){const value=document.getElementById('vendorFieldEditValue').value.trim();if(!value){showToast('Alamat wajib diisi.','error');return}vendor.addresses[target.index]=value}
  if(key==='account'){const bank=vendorFieldEditBank.value.trim(),number=vendorFieldEditNumber.value.trim(),holder=vendorFieldEditHolder.value.trim();if(!bank||!number||!holder){showToast('Nama bank, nomor rekening, dan pemilik rekening wajib diisi.','error');return}const account=vendor.accounts.find(item=>item.id===target.id);if(account)Object.assign(account,{bank,number:number.replace(/\s/g,''),raw:number,holder})}
  normalizeExpenseVendor(vendor,vendorRecords.indexOf(vendor));closeExpenseVendorFieldEdit();renderForm();showToast('Data vendor berhasil diperbarui.','info');
}
function cloneExpenseVendor(vendor){return JSON.parse(JSON.stringify(vendor))}
function openExpenseVendorManager(){const vendor=getVendorDetail(formState.contact);if(!vendor){showToast('Pilih vendor terlebih dahulu.','error');return}formState.vendorManagerDraft=cloneExpenseVendor(vendor);formState.vendorManagerOpen=true;renderForm();window.scrollTo(0,0)}
function closeExpenseVendorManager(){formState.vendorManagerOpen=false;formState.vendorManagerDraft=null;renderForm();window.scrollTo(0,0)}
function saveExpenseVendorManager(){
  const draft=formState.vendorManagerDraft,original=getVendorDetail(formState.contact);if(!draft||!original)return;
  if(draft.email&&!/^\S+@\S+\.\S+$/.test(draft.email)){showToast('Format Email Utama belum valid.','error');return}
  const invalidEmail=draft.additionalContacts.some(item=>item.type==='email'&&item.value&&!/^\S+@\S+\.\S+$/.test(item.value));if(invalidEmail){showToast('Periksa format email pada Kontak Tambahan.','error');return}
  Object.keys(original).forEach(key=>delete original[key]);Object.assign(original,normalizeExpenseVendor(cloneExpenseVendor(draft),vendorRecords.indexOf(original)));
  formState.contact=original.name;formState.vendorQuery='';syncExpenseVendorSelection();formState.vendorManagerOpen=false;formState.vendorManagerDraft=null;renderForm();showToast('Data Vendor berhasil disimpan.','info');
}
function updateExpenseVendorManagerPrimary(field,value){if(formState.vendorManagerDraft)formState.vendorManagerDraft[field]=value}
function addExpenseVendorManagerContact(){const draft=formState.vendorManagerDraft;if(!draft)return;if(draft.additionalContacts.length>=5){showToast('Maksimal 5 kontak tambahan.','error');return}draft.additionalContacts.push({id:`${draft.id}-contact-${Date.now()}`,type:'phone',value:''});renderForm();setTimeout(()=>document.querySelector('[data-new-vendor-contact] input')?.focus(),0)}
function updateExpenseVendorManagerContact(index,field,value){const item=formState.vendorManagerDraft?.additionalContacts[index];if(!item)return;item[field]=value;if(field==='type')renderForm()}
function removeExpenseVendorManagerContact(index){formState.vendorManagerDraft?.additionalContacts.splice(index,1);renderForm()}
function addExpenseVendorManagerAddress(){const draft=formState.vendorManagerDraft;if(!draft)return;if(draft.addresses.length>=5){showToast('Maksimal 5 alamat.','error');return}draft.addresses.push('');renderForm();setTimeout(()=>document.querySelector('[data-new-vendor-address] textarea')?.focus(),0)}
function updateExpenseVendorManagerAddress(index,value){if(formState.vendorManagerDraft?.addresses[index]!==undefined)formState.vendorManagerDraft.addresses[index]=value}
function removeExpenseVendorManagerAddress(index){formState.vendorManagerDraft?.addresses.splice(index,1);renderForm()}
function addExpenseVendorManagerAccount(){const draft=formState.vendorManagerDraft;if(!draft)return;if(draft.accounts.length>=3){showToast('Maksimal 3 rekening bank.','error');return}draft.accounts.push({id:`${draft.id}-account-${Date.now()}`,bank:'',number:'',raw:'',holder:draft.name});renderForm();setTimeout(()=>document.querySelector('[data-new-vendor-account] input')?.focus(),0)}
function updateExpenseVendorManagerAccount(index,field,value){const account=formState.vendorManagerDraft?.accounts[index];if(!account)return;account[field]=value;if(field==='raw')account.number=String(value).replace(/\s/g,'')}
function removeExpenseVendorManagerAccount(index){formState.vendorManagerDraft?.accounts.splice(index,1);renderForm()}
function renderExpenseVendorManagerContact(item,index,total){return `<div class="manager-entry" ${index===total-1?'data-new-vendor-contact':''}><div class="manager-entry-head"><strong>Kontak ${index+1}</strong><button type="button" class="manager-delete" onclick="removeExpenseVendorManagerContact(${index})" aria-label="Hapus kontak"><i class="ti ti-trash" aria-hidden="true"></i></button></div><div class="manager-grid two"><div class="field"><label>Jenis Kontak</label><select onchange="updateExpenseVendorManagerContact(${index},'type',this.value)"><option value="phone" ${item.type==='phone'?'selected':''}>No. HP/WA</option><option value="email" ${item.type==='email'?'selected':''}>Email</option></select></div><div class="field"><label>${item.type==='email'?'Email':'No. HP/WA'}</label><input class="input" ${item.type==='email'?'type="email"':'inputmode="tel"'} value="${expenseEscape(item.value||'')}" oninput="updateExpenseVendorManagerContact(${index},'value',this.value)"></div></div></div>`}
function renderExpenseVendorManagerAddress(value,index,total){return `<div class="manager-entry" ${index===total-1?'data-new-vendor-address':''}><div class="manager-entry-head"><strong>Alamat ${index+1}</strong><button type="button" class="manager-delete" onclick="removeExpenseVendorManagerAddress(${index})" aria-label="Hapus alamat"><i class="ti ti-trash" aria-hidden="true"></i></button></div><div class="field"><label>Alamat Lengkap</label><textarea placeholder="Masukkan alamat lengkap" oninput="updateExpenseVendorManagerAddress(${index},this.value)">${expenseEscape(value||'')}</textarea></div></div>`}
function renderExpenseVendorManagerAccount(account,index,total){return `<div class="manager-entry" ${index===total-1?'data-new-vendor-account':''}><div class="manager-entry-head"><strong>Rekening ${index+1}</strong><button type="button" class="manager-delete" onclick="removeExpenseVendorManagerAccount(${index})" aria-label="Hapus rekening"><i class="ti ti-trash" aria-hidden="true"></i></button></div><div class="manager-grid three"><div class="field"><label>Nama Bank</label><input class="input" list="vendorBankList" value="${expenseEscape(account.bank||'')}" oninput="updateExpenseVendorManagerAccount(${index},'bank',this.value)"></div><div class="field"><label>Nomor Rekening</label><input class="input" inputmode="numeric" value="${expenseEscape(account.raw||account.number||'')}" oninput="updateExpenseVendorManagerAccount(${index},'raw',this.value)"></div><div class="field"><label>Nama Pemilik Rekening</label><input class="input" value="${expenseEscape(account.holder||formState.vendorManagerDraft.name)}" oninput="updateExpenseVendorManagerAccount(${index},'holder',this.value)"></div></div></div>`}
function renderExpenseVendorManager(){
  const vendor=formState.vendorManagerDraft;if(!vendor)return '<div class="card panel"><div class="empty">Data vendor tidak tersedia.</div></div>';
  const contacts=vendor.additionalContacts.map((item,index)=>renderExpenseVendorManagerContact(item,index,vendor.additionalContacts.length)).join(''),addresses=vendor.addresses.map((value,index)=>renderExpenseVendorManagerAddress(value,index,vendor.addresses.length)).join(''),vendorAccounts=vendor.accounts.map((item,index)=>renderExpenseVendorManagerAccount(item,index,vendor.accounts.length)).join('');
  return `<div class="vendor-manager-page"><div class="manager-page-back"><button class="btn btn-secondary" type="button" onclick="closeExpenseVendorManager()"><i class="ti ti-arrow-left" aria-hidden="true"></i>Kembali ke Transaksi</button></div><section class="card panel manager-section"><div class="manager-section-title"><div><h2>Informasi Dasar</h2><p>Kelola data utama vendor yang berasal dari database Kontak.</p></div></div><div class="manager-grid two"><div class="field"><label>Nama Vendor</label><input class="input" value="${expenseEscape(vendor.name)}" disabled><div class="field-help">Nama vendor tidak dapat diubah dari transaksi.</div></div><div class="field"><label>No. HP/WA Utama</label><input class="input" inputmode="tel" value="${expenseEscape(vendor.phone||'')}" oninput="updateExpenseVendorManagerPrimary('phone',this.value)"></div><div class="field"><label>Email Utama</label><input class="input" type="email" value="${expenseEscape(vendor.email||'')}" oninput="updateExpenseVendorManagerPrimary('email',this.value)"></div></div></section><section class="card panel manager-section"><div class="manager-section-title"><div><h2>Data Opsional</h2><p>Tambahkan data yang diperlukan untuk transaksi ini dan transaksi berikutnya.</p></div></div><div class="manager-subsection"><div class="manager-subsection-head"><div><h3>Kontak Tambahan</h3><p>Nomor HP/WA dan email berbagi maksimal 5 slot tambahan.</p></div></div><div class="manager-stack">${contacts||'<div class="manager-empty">Belum ada kontak tambahan.</div>'}</div>${vendor.additionalContacts.length<5?'<button type="button" class="manager-add-bottom" onclick="addExpenseVendorManagerContact()"><i class="ti ti-plus" aria-hidden="true"></i>Tambah Kontak</button>':''}</div><div class="manager-subsection"><div class="manager-subsection-head"><div><h3>Alamat</h3><p>Pilih alamat yang sesuai saat kembali ke transaksi.</p></div></div><div class="manager-stack">${addresses||'<div class="manager-empty">Belum ada alamat tersimpan.</div>'}</div>${vendor.addresses.length<5?'<button type="button" class="manager-add-bottom" onclick="addExpenseVendorManagerAddress()"><i class="ti ti-plus" aria-hidden="true"></i>Tambah Alamat</button>':''}</div><div class="manager-subsection"><div class="manager-subsection-head"><div><h3>Rekening Bank</h3><p>Rekening yang tersimpan akan tersedia pada pilihan transaksi dan pembayaran.</p></div></div><div class="manager-stack">${vendorAccounts||'<div class="manager-empty">Belum ada rekening tersimpan.</div>'}</div>${vendor.accounts.length<3?'<button type="button" class="manager-add-bottom" onclick="addExpenseVendorManagerAccount()"><i class="ti ti-plus" aria-hidden="true"></i>Tambah Rekening</button>':''}</div></section><div class="manager-footer"><button class="btn btn-secondary" type="button" onclick="closeExpenseVendorManager()">Batal</button><button class="btn btn-primary" type="button" onclick="saveExpenseVendorManager()">Simpan</button></div></div>`;
}
function openVendorModal(){const prefill=String(formState?.vendorQuery||'').trim();closeExpenseVendorDropdown();['vendorName','vendorPhone','vendorEmail','vendorAddress','vendorBank','vendorAccountNumber','vendorAccountHolder'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=''});const nameField=document.getElementById('vendorName');if(nameField)nameField.value=prefill;openModal('vendorModal');setTimeout(()=>document.getElementById('vendorName')?.focus(),0)}
function saveQuickVendor(){
  const name=vendorName.value.trim(),phone=vendorPhone.value.trim(),email=vendorEmail.value.trim(),address=vendorAddress.value.trim(),bank=vendorBank.value.trim(),number=vendorAccountNumber.value.trim(),holder=vendorAccountHolder.value.trim(),source=formState?.sourceData||'Perusahaan';
  if(!name||!phone){showToast('Nama Vendor dan Nomor Telepon wajib diisi.','error');return}if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){showToast('Format email vendor tidak valid.','error');return}if((bank||number||holder)&&!(bank&&number&&holder)){showToast('Lengkapi seluruh informasi rekening atau kosongkan semuanya.','error');return}
  let vendor=vendorRecords.find(item=>item.name.toLowerCase()===name.toLowerCase());if(vendor){if(!vendor.sources.includes(source))vendor.sources.push(source);vendor.phone=phone;vendor.email=email;if(address&&!vendor.addresses.includes(address))vendor.addresses.unshift(address);if(bank&&number&&holder)vendor.accounts.push({id:`${vendor.id}-account-${Date.now()}`,bank,number:number.replace(/\s/g,''),raw:number,holder})}else{vendor=normalizeExpenseVendor({name,phone,email,address,sources:[source],additionalContacts:[],addresses:address?[address]:[],accounts:bank&&number&&holder?[{id:`vendor-${Date.now()}-account-1`,bank,number:number.replace(/\s/g,''),raw:number,holder}]:[]},vendorRecords.length);vendorRecords.push(vendor);vendors.push(name)}
  const config=sourceConfig(source);if(!config.vendors.includes(vendor.name))config.vendors.push(vendor.name);formState.contact=vendor.name;formState.vendorQuery='';formState.vendorSearchOpen=false;syncExpenseVendorSelection();closeModal('vendorModal');renderForm();showToast('Vendor berhasil ditambahkan dan langsung dipilih.','info');
}
function expenseItemOptionRows(){
  const source=formState.sourceData||'Perusahaan',query=String(formState.itemQuery||'').trim().toLowerCase(),selectedNames=new Set(formState.items.map(item=>String(item.item||'').toLowerCase()));
  const rows=availableMasterItems(source).filter(item=>!selectedNames.has(item.name.toLowerCase())).filter(item=>!query||[item.name,item.desc,item.coa].some(value=>String(value||'').toLowerCase().includes(query)));
  return rows.length?rows.map(item=>`<button type="button" class="expense-item-option" onclick='selectExpenseItem(${JSON.stringify(item.name)})'><span class="expense-item-option-copy"><strong>${expenseEscape(item.name)}</strong><small><span>${expenseEscape(item.desc||'Tanpa deskripsi')}</span><span class="expense-item-meta-divider" aria-hidden="true">•</span><span class="expense-item-option-coa">${expenseEscape(formatCoaTag(item.coa))}</span></small></span></button>`).join(''):'<div class="expense-item-option-empty"><strong>Data tidak ditemukan</strong><span>Coba gunakan kata kunci lain, ya.</span></div>';
}
function renderExpenseItemOptions(){const target=document.getElementById('expenseItemOptions');if(target)target.innerHTML=expenseItemOptionRows()}
function openExpenseItemMenu(){if(!formState)return;formState.itemSearchOpen=true;document.getElementById('expenseItemMenu')?.classList.add('show');document.getElementById('expenseItemSearchControl')?.setAttribute('aria-expanded','true');renderExpenseItemOptions()}
function closeExpenseItemMenu(){if(!formState)return;formState.itemSearchOpen=false;document.getElementById('expenseItemMenu')?.classList.remove('show');document.getElementById('expenseItemSearchControl')?.setAttribute('aria-expanded','false')}
function toggleExpenseItemMenu(event){event?.stopPropagation();if(formState?.itemSearchOpen)closeExpenseItemMenu();else{openExpenseItemMenu();setTimeout(()=>document.getElementById('expenseItemSearch')?.focus(),0)}}
function filterExpenseItemMenu(value){if(!formState)return;formState.itemQuery=value;formState.itemSearchOpen=true;document.getElementById('expenseItemMenu')?.classList.add('show');document.getElementById('expenseItemSearchControl')?.setAttribute('aria-expanded','true');renderExpenseItemOptions()}
function selectExpenseItem(name){if(!formState)return;formState.itemQuery='';formState.itemSearchOpen=false;addSelectedExpenseItem(name)}
function openNewExpenseItemFromSearch(){
  const suggestedName=String(formState?.itemQuery||'').trim();
  closeExpenseItemMenu();window.activeItemRow=null;openMasterItemModal();
  if(suggestedName){const nameInput=document.getElementById('mName');if(nameInput){nameInput.value=suggestedName;nameInput.focus()}}
}
function renderItemsStep(){
  return `<div class="card subsection wizard-step-card">${expenseSectionTitle(2,'Item','Tambahkan item, lengkapi nominal dan pajak, lalu periksa lampiran transaksi.')}<div class="expense-item-picker-section"><div class="field expense-item-picker-field"><label>Pilih Item</label><div class="expense-item-picker-row"><div class="expense-item-select"><div class="expense-item-search-control" id="expenseItemSearchControl" aria-expanded="${formState.itemSearchOpen?'true':'false'}"><i class="ti ti-search" aria-hidden="true"></i><input id="expenseItemSearch" value="${expenseEscape(formState.itemQuery||'')}" placeholder="Cari dan pilih Item" onfocus="openExpenseItemMenu()" oninput="filterExpenseItemMenu(this.value)" autocomplete="off"><button type="button" class="expense-item-chevron" onclick="toggleExpenseItemMenu(event)" aria-label="Buka pilihan Item"><i class="ti ti-chevron-down" aria-hidden="true"></i></button></div><div class="expense-item-menu ${formState.itemSearchOpen?'show':''}" id="expenseItemMenu"><div class="expense-item-options" id="expenseItemOptions">${expenseItemOptionRows()}</div><div class="expense-item-menu-footer"><button type="button" class="expense-item-menu-add" onclick="openNewExpenseItemFromSearch()"><i class="ti ti-plus" aria-hidden="true"></i>Tambah Item</button></div></div></div></div></div></div><div id="itemRows">${formState.items.length?formState.items.map(renderItemRow).join(''):'<div class="item-empty"><strong>Belum ada item biaya</strong><div class="hint" style="margin-top:4px">Cari dan pilih item untuk menambahkannya ke transaksi.</div></div>'}</div><div class="expense-step-subsection item-attachment-section"><div class="subsection-title">Lampiran</div><div class="field-help attachment-step-help">Gambar dari Scan Nota otomatis muncul di sini. File lain tetap dapat ditambahkan secara manual.</div>${renderExpenseAttachmentUploader()}</div>${expenseWizardFooter({nextLabel:'Lanjut ke Pembayaran'})}</div>`;
}
function renderItemRow(i){const tax=taxTypeOf(i),taxValue=tax==='ppn11'?ppnItemOf(i):tax==='pph10'?pphItemOf(i):0;return `<div class="expense-item-row"><div class="expense-item-head"><div><div class="hint">Item</div><div class="expense-item-title">${i.item}</div></div><span class="badge terbit">${expenseEscape(formatCoaTag(i.coa))}</span></div><div class="expense-item-fields"><div class="field"><label>Deskripsi</label><input class="input" value="${i.desc||''}" placeholder="Masukkan deskripsi" oninput="updateItem(${i.id},'desc',this.value)"></div><div class="field"><label>Nominal</label><input class="input" inputmode="numeric" value="${i.amount||''}" placeholder="0" oninput="updateItem(${i.id},'amount',this.value)"></div><div class="field"><label>Pajak</label><select onchange="updateItem(${i.id},'tax',this.value)"><option value="none" ${tax==='none'?'selected':''}>Tanpa Pajak</option><option value="ppn11" ${tax==='ppn11'?'selected':''}>PPN 11%</option><option value="pph10" ${tax==='pph10'?'selected':''}>PPh 10%</option></select></div><button type="button" class="btn btn-danger remove-item" aria-label="Hapus ${i.item}" onclick="removeItem(${i.id})"><i class="ti ti-x" aria-hidden="true"></i></button></div>${tax!=='none'?`<div class="attachment-item" style="margin-top:12px">${tax==='ppn11'?'PPN 11% ditambahkan':'PPh 10% dipotong'} dari nominal: ${rupiah(taxValue)}.</div>`:''}</div>`}
function addSelectedExpenseItem(name){const value=String(name||'').trim();if(!value)return;const m=availableMasterItems(formState.sourceData||'Perusahaan').find(x=>x.active&&x.name.toLowerCase()===value.toLowerCase());if(!m){showToast('Pilih Item Biaya yang tersedia pada daftar.','error');return}if(formState.items.some(i=>i.item.toLowerCase()===m.name.toLowerCase())){showToast('Item tersebut sudah ditambahkan.','error');return}formState.itemQuery='';formState.itemSearchOpen=false;formState.items.push({id:Date.now(),item:m.name,desc:m.desc||'',amount:0,tax:m.ppn?'ppn11':m.pph?'pph10':'none',coa:m.coa||''});renderForm()}
function selectMasterByName(id,name){const m=masterItems.find(x=>x.active&&x.name.toLowerCase()===String(name).trim().toLowerCase()),i=formState.items.find(x=>x.id===id);if(m&&i){Object.assign(i,{item:m.name,desc:m.desc,coa:m.coa,tax:m.ppn?'ppn11':m.pph?'pph10':'none'});renderForm()}}

function setExpensePaymentDate(value){const date=value||expenseDatePart(localDateTimeValue());formState.payDate=`${date}T${expenseTimePart(formState.payDate)||'00:00'}`}
function setExpensePaymentTime(value){const time=value||'00:00';formState.payDate=`${expenseDatePart(formState.payDate)||expenseDatePart(localDateTimeValue())}T${time}`}
function renderPaymentStep(){
  const c=formCalc(),isFull=formState.paymentType==='full',isPartial=formState.paymentType==='partial',isLater=formState.paymentType==='later',sourceAccounts=availableAccounts(formState.sourceData||'Perusahaan');
  if(isFull)formState.payAmount=c.total;
  if(isPartial&&(!Number(formState.payAmount)||Number(formState.payAmount)>=c.total))formState.payAmount=Math.max(1,Math.floor(c.total/2));
  const paymentAmount=isFull?c.total:Number(formState.payAmount||0);
  return `<div class="card subsection wizard-step-card">${expenseSectionTitle(3,'Pembayaran','Atur proses pembayaran, rekening, tanggal dan waktu pembayaran, serta bukti pembayaran.')}<div class="attachment-item source-lock-note"><strong>Sumber Data: ${formState.sourceData||'Perusahaan'}</strong><div class="hint">Pembayaran dan jurnal mengikuti Sumber Data transaksi dan tidak dapat diubah pada tahap ini.</div></div><div class="subsection-title payment-section-heading">Pilih Proses Pembayaran</div><div class="payment-options"><label class="payment-option ${isFull?'active':''}"><input type="radio" name="paymentType" value="full" ${isFull?'checked':''} onchange="setPaymentType(this.value)"><strong>Bayar Lunas</strong><div class="hint">Pembayaran dilakukan penuh saat transaksi diterbitkan.</div></label><label class="payment-option ${isPartial?'active':''}"><input type="radio" name="paymentType" value="partial" ${isPartial?'checked':''} onchange="setPaymentType(this.value)"><strong>Bayar Sebagian</strong><div class="hint">Prototype mengisi nominal pembayaran sebagian secara otomatis.</div></label><label class="payment-option ${isLater?'active':''}"><input type="radio" name="paymentType" value="later" ${isLater?'checked':''} onchange="setPaymentType(this.value)"><strong>Bayar Nanti</strong><div class="hint">Transaksi diterbitkan tanpa pembayaran awal.</div></label></div><div class="payment-fields">${isLater?`<div class="grid-2 payment-later-grid"><div class="field"><label>Tanggal Jatuh Tempo *</label><input type="date" class="input" value="${formState.due}" onchange="setForm('due',this.value);renderFormSummary()"></div><div class="field"><label>Waktu Jatuh Tempo *</label><input type="time" class="input" value="${formState.dueTime||'23:59'}" onchange="setForm('dueTime',this.value);renderFormSummary()"></div></div><div class="journal-info-banner" role="status"><i class="ti ti-info-circle" aria-hidden="true"></i><div><strong>Informasi Jurnal</strong><span>Jurnal penerbitan tetap terbentuk. Jurnal pembayaran belum dibuat.</span></div></div>`:`<div class="payment-detail-grid"><div class="field payment-account-field"><label>Rekening Kas & Bank *</label><select onchange="setForm('account',this.value)">${sourceAccounts.map(a=>`<option ${formState.account===a?'selected':''}>${a}</option>`).join('')}</select></div><div class="payment-date-time"><div class="field payment-date-field"><label>Tanggal Pembayaran *</label><input type="date" class="input" value="${expenseDatePart(formState.payDate)}" onchange="setExpensePaymentDate(this.value)"></div><div class="field payment-time-field"><label>Waktu *</label><input type="time" class="input" value="${expenseTimePart(formState.payDate)}" onchange="setExpensePaymentTime(this.value)"></div></div><div class="field payment-amount-field"><label>Nominal Pembayaran</label><input class="input readonly-input" value="${rupiah(paymentAmount)}" readonly aria-readonly="true"><div class="field-help">Nominal ditentukan otomatis dari pilihan proses pembayaran dan tidak dapat diubah.</div></div>${isPartial?`<div class="field payment-due-field"><label>Tanggal Jatuh Tempo *</label><input type="date" class="input" value="${formState.due}" onchange="setForm('due',this.value)"></div>`:''}<div class="payment-evidence-field">${renderPaymentEvidenceUploader()}</div></div>`}</div>${expenseWizardFooter({nextLabel:'Lanjut ke Preview'})}</div>`;
}
function renderPreviewStep(){const c=formCalc(),pay=formState.paymentType==='full'?c.total:formState.paymentType==='partial'?Number(formState.payAmount||0):0,remaining=Math.max(c.total-pay,0),paymentLabel=formState.paymentType==='full'?'Bayar Sekarang · Lunas':formState.paymentType==='partial'?'Bayar Sekarang · Dibayar Sebagian':'Bayar Nanti',dueLabel=formState.due?fmtDate(formState.due):'-';return `<div class="preview-section"><div class="card preview-card wizard-step-card">${expenseSectionTitle(4,'Preview Transaksi Biaya','')}<div class="preview-block"><div class="subsection-title">Informasi Transaksi</div><div class="preview-info-grid"><div><div class="preview-key">Sumber Data</div><div class="preview-value">${formState.sourceData||'-'}</div></div><div><div class="preview-key">Tanggal Transaksi</div><div class="preview-value">${fmtDate(formState.date)}</div></div><div><div class="preview-key">Vendor</div><div class="preview-value">${formState.contact||'-'}</div></div><div><div class="preview-key">Keterangan</div><div class="preview-value">${formState.title||'-'}</div></div><div><div class="preview-key">Dibuat pada</div><div class="preview-value">${displayCreatedAt(formState.createdAt)}</div></div><div><div class="preview-key">Dibuat oleh</div><div class="preview-value">${formState.createdBy}</div></div><div><div class="preview-key">Jumlah Item</div><div class="preview-value">${formState.items.length} item</div></div><div><div class="preview-key">Lampiran</div><div class="preview-value">${formState.attachments.length} file</div></div></div></div><div class="preview-block"><div class="subsection-title">Detail Item</div><div class="table-wrap"><table class="preview-item-table"><thead><tr><th>Item</th><th>Deskripsi</th><th>Nominal</th><th>Pajak</th></tr></thead><tbody>${formState.items.map(i=>`<tr><td><strong>${i.item}</strong></td><td>${i.desc||'-'}</td><td>${rupiah(i.amount)}</td><td>${taxTypeOf(i)==='ppn11'?'PPN 11%':taxTypeOf(i)==='pph10'?'PPh 10%':'Tanpa Pajak'}</td></tr>`).join('')}</tbody></table></div></div><div class="preview-block"><div class="subsection-title">Pembayaran</div><div class="preview-payment-grid"><div><div class="preview-key">Pilihan Pembayaran</div><div class="preview-value">${paymentLabel}</div></div><div><div class="preview-key">Rekening Kas & Bank</div><div class="preview-value">${formState.paymentType==='later'?'-':formState.account||'-'}</div></div><div><div class="preview-key">Tanggal Pembayaran</div><div class="preview-value">${formState.paymentType==='later'?'-':fmtDate(formState.payDate)}</div></div><div><div class="preview-key">Total Tagihan</div><div class="preview-value">${rupiah(c.total)}</div></div><div><div class="preview-key">Total Dibayar</div><div class="preview-value">${rupiah(pay)}</div></div><div><div class="preview-key">Sisa Tagihan</div><div class="preview-value">${rupiah(remaining)}</div></div><div><div class="preview-key">Tanggal Jatuh Tempo</div><div class="preview-value">${dueLabel}</div></div></div></div>${expenseWizardFooter({final:true})}</div></div>`}
function validatePaymentStep(){const c=formCalc();if(formState.paymentType==='later'&&!formState.due){showToast('Tanggal jatuh tempo wajib untuk Bayar Nanti.','error');return false}if(formState.paymentType==='partial'){const amount=Number(formState.payAmount||0);if(amount<=0||amount>=c.total){showToast('Nominal Bayar Sekarang harus lebih dari nol dan tidak melebihi total tagihan.','error');return false}if(!formState.due){showToast('Tanggal jatuh tempo wajib ketika nominal Bayar Sekarang lebih kecil dari total tagihan.','error');return false}}if(formState.paymentType!=='later'&&!formState.account){showToast('Rekening Kas & Bank wajib dipilih.','error');return false}return true}
function goPreview(){if(formState.step!==3)formState.step=3;nextExpenseStep()}
function setPaymentType(type){formState.paymentType=type;const total=formCalc().total;if(type==='full')formState.payAmount=total;if(type==='partial')formState.payAmount=Math.max(1,Math.floor(total/2));if(type==='later'){formState.payAmount=0;formState.dueTime=formState.dueTime||'23:59'}renderForm()}
function renderFormSummary(){
  const layout=document.getElementById('formLayout');
  const visible=Boolean(formState&&formState.step>=2);
  if(layout)layout.classList.toggle('summary-hidden',!visible);
  formSummary.hidden=!visible;
  if(!visible){formSummary.innerHTML='';return}
  const c=formCalc(),pay=formState.paymentType==='full'?c.total:formState.paymentType==='partial'?Number(formState.payAmount||0):0,rem=Math.max(c.total-pay,0),status=pay<=0?'Belum Dibayar':rem<=0?'Lunas':'Dibayar Sebagian';
  formSummary.innerHTML=`<h3>Ringkasan Transaksi</h3><div class="summary-line"><span>Subtotal</span><strong>${rupiah(c.subtotal)}</strong></div><div class="summary-line"><span>PPN</span><strong>${rupiah(c.ppn)}</strong></div><div class="summary-line"><span>PPh</span><strong>- ${rupiah(c.pph)}</strong></div><div class="summary-line total"><span>Total Tagihan</span><strong>${rupiah(c.total)}</strong></div><div class="summary-line"><span>Total Dibayar</span><strong>${rupiah(pay)}</strong></div><div class="summary-line"><span>Sisa Tagihan</span><strong>${rupiah(rem)}</strong></div><div class="summary-line"><span>Status Pembayaran</span><span class="badge ${status==='Lunas'?'lunas':status==='Dibayar Sebagian'?'partial':'unpaid'}">${status}</span></div><div class="hint summary-step-hint">Tahap ${formState.step} dari 4</div>`;
}
function formCalc(){const subtotal=formState.items.reduce((s,i)=>s+Number(i.amount||0),0),ppn=formState.items.reduce((s,i)=>s+ppnItemOf(i),0),pph=formState.items.reduce((s,i)=>s+pphItemOf(i),0);return{subtotal,ppn:Math.round(ppn),pph:Math.round(pph),total:Math.round(subtotal+ppn-pph)}}
function setForm(k,v){formState[k]=v}
function generateMasterCoaCode(){return `6${String(coaList.length+101).padStart(3,'0')}`}
function populateMasterSelects(){const linked=document.getElementById('mLinkedCoa'),parent=document.getElementById('mParentCoa');if(linked)linked.innerHTML=`<option value="">Pilih Linked CoA</option>`+coaList.map(c=>`<option value="${c}">${c}</option>`).join('');if(parent)parent.innerHTML=`<option value="">Pilih Parent CoA</option>`+coaList.map(c=>`<option value="${c}">${c}</option>`).join('')}
function setMasterCoaMode(mode){document.querySelectorAll('input[name="masterCoaMode"]').forEach(input=>{input.checked=input.value===mode});const existing=document.getElementById('masterCoaPanelExisting'),fresh=document.getElementById('masterCoaPanelNew'),existingBanner=document.getElementById('masterExistingBanner'),newBanner=document.getElementById('masterNewBanner');if(existing)existing.classList.toggle('active',mode==='existing');if(fresh)fresh.classList.toggle('active',mode==='new');if(existingBanner)existingBanner.style.display=mode==='existing'?'grid':'none';if(newBanner)newBanner.style.display=mode==='new'?'grid':'none';if(mode==='new'){const codeField=document.getElementById('mCoaCode');if(codeField&&!codeField.value)codeField.value=generateMasterCoaCode()}}
function removeItem(id){formState.items=formState.items.filter(i=>i.id!==id);renderForm()}
function updateItem(id,k,v){const i=formState.items.find(x=>x.id===id);i[k]=k==='amount'?Number(v.replace?.(/\D/g,'')||v)||0:v;renderFormSummary()}
function selectMaster(id,val){if(val==='new'){window.activeItemRow=id;openMasterItemModal();return}const m=masterItems.find(x=>x.id===val),i=formState.items.find(x=>x.id===id);if(m){Object.assign(i,{item:m.name,desc:m.desc,coa:m.coa,tax:m.ppn?'ppn11':m.pph?'pph10':'none'});renderForm()}}
let editingMasterId=null;
let masterFilters={status:'all',tax:'all'};
function openMasterItemPage(){renderMasterItemPage();showPage('master')}
function masterTaxValue(m){return m.ppn?'ppn11':m.pph?'pph10':'none'}
function renderMasterItemPage(){if(!document.getElementById('masterRows'))return;const q=(document.getElementById('masterSearch')?.value||'').toLowerCase();const data=masterItems.filter(m=>(!q||`${m.name} ${m.desc} ${m.coa}`.toLowerCase().includes(q))&&(masterFilters.status==='all'||(masterFilters.status==='active'?m.active:!m.active))&&(masterFilters.tax==='all'||masterTaxValue(m)===masterFilters.tax));document.getElementById('masterRows').innerHTML=data.length?data.map(m=>`<tr><td><strong>${m.name}</strong></td><td>${m.desc||'-'}</td><td>${m.coa}</td><td>${m.ppn?'PPN 11%':m.pph?'PPh 10%':'Tanpa Pajak'}</td><td><span class="master-status ${m.active?'active':'inactive'}">${m.active?'Aktif':'Nonaktif'}</span></td><td><button class="btn btn-secondary" onclick="openMasterItemModal('${m.id}')">Edit</button> <button class="btn ${m.active?'btn-danger':'btn-secondary'}" onclick="toggleMasterItem('${m.id}')">${m.active?'Nonaktifkan':'Aktifkan'}</button></td></tr>`).join(''):'<tr><td colspan="6"><div class="empty">Master Item tidak ditemukan.</div></td></tr>';const count=[masterFilters.status!=='all',masterFilters.tax!=='all'].filter(Boolean).length;const btn=document.getElementById('masterFilterBtn');if(btn){btn.innerHTML=count?`<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter (${count})`:'<i class="ti ti-adjustments-horizontal" aria-hidden="true"></i>Filter';btn.className='btn '+(count?'btn-soft':'btn-secondary')}}
function openMasterFilterModal(){document.getElementById('mfStatus').value=masterFilters.status;document.getElementById('mfTax').value=masterFilters.tax;openModal('masterFilterModal')}
function applyMasterFilters(){masterFilters.status=document.getElementById('mfStatus').value;masterFilters.tax=document.getElementById('mfTax').value;closeModal('masterFilterModal');renderMasterItemPage()}
function resetMasterFilters(){masterFilters={status:'all',tax:'all'};document.getElementById('mfStatus').value='Terbit';document.getElementById('mfTax').value='Terbit';closeModal('masterFilterModal');renderMasterItemPage()}
function openMasterItemModal(id=null){editingMasterId=id;window.activeItemRow=window.activeItemRow||null;populateMasterSelects();const m=id?masterItems.find(x=>x.id===id):null;document.getElementById('masterModalTitle').textContent=m?'Edit Master Item':'Tambah Master Item';document.getElementById('mName').value=m?.name||'';document.getElementById('mDesc').value=m?.desc||'';document.getElementById('mTax').value=m?masterTaxValue(m):'';document.getElementById('mLinkedCoa').value=m?.coa||'';document.getElementById('mCoaCode').value=generateMasterCoaCode();document.getElementById('mCoaName').value='';document.getElementById('mParentCoa').value='';setMasterCoaMode('existing');openModal('masterModal')}
function saveMasterItem(){const name=document.getElementById('mName').value.trim(),desc=document.getElementById('mDesc').value.trim(),tax=document.getElementById('mTax').value,mode=document.querySelector('input[name="masterCoaMode"]:checked')?.value||'existing';let coa='';if(mode==='existing'){coa=document.getElementById('mLinkedCoa').value}else{const coaName=document.getElementById('mCoaName').value.trim(),parent=document.getElementById('mParentCoa').value,code=document.getElementById('mCoaCode').value||generateMasterCoaCode();if(!coaName||!parent){showToast('Lengkapi data CoA baru terlebih dahulu.','error');return}coa=coaName;document.getElementById('mCoaCode').value=code;if(!coaList.includes(coaName))coaList.push(coaName)}if(!name||!desc||!coa||!tax){showToast('Semua field Master Item wajib diisi.','error');return}let m=editingMasterId?masterItems.find(x=>x.id===editingMasterId):null;if(m){Object.assign(m,{name,desc,coa,ppn:tax==='ppn11',pph:tax==='pph10'})}else{m={id:'mi'+Date.now(),name,desc,coa,ppn:tax==='ppn11',pph:tax==='pph10',active:true};masterItems.push(m)}closeModal('masterModal');if(formState&&document.getElementById('formPage')?.classList.contains('active')){if(window.activeItemRow){const i=formState.items.find(x=>x.id===window.activeItemRow);if(i)Object.assign(i,{item:m.name,desc:m.desc,coa:m.coa,tax:masterTaxValue(m)});window.activeItemRow=null;renderForm()}else renderForm()}renderMasterItemPage();showToast(editingMasterId?'Master Item berhasil diperbarui.':'Master Item berhasil ditambahkan dan otomatis berstatus Aktif.')}
function toggleMasterItem(id){const m=masterItems.find(x=>x.id===id);m.active=!m.active;renderMasterItemPage();showToast(`Master Item berhasil ${m.active?'diaktifkan':'dinonaktifkan'}.`)}
function saveCoa(){const n=(document.getElementById('mCoaName')?.value||'').trim();if(!n){showToast('Nama akun wajib diisi.','error');return}if(!coaList.includes(n))coaList.push(n);populateMasterSelects();const linked=document.getElementById('mLinkedCoa');if(linked)linked.value=n;setMasterCoaMode('existing');showToast('CoA baru berhasil dibuat.')}
function formatUploadSize(bytes){if(!Number.isFinite(bytes)||bytes<=0)return 'File tersimpan';if(bytes<1024)return `${bytes} B`;if(bytes<1024*1024)return `${Math.round(bytes/1024)} KB`;return `${(bytes/1024/1024).toFixed(1)} MB`}
function escapeUploadText(value){return String(value??'').replace(/[&<>'"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]))}
function renderFigmaUploadCards(files,state,errors,kind){
  const removeFns={attachment:'removeAttachment',evidence:'removePaymentEvidence',modalEvidence:'removeModalPaymentEvidence'};
  const retryFns={attachment:'retryAttachment',evidence:'retryPaymentEvidence',modalEvidence:'retryModalPaymentEvidence'};
  const inputIds={attachment:'expenseAttachmentInput',evidence:'paymentEvidenceInput',modalEvidence:'modalPaymentEvidenceInput'};
  const saved=(files||[]).map((name,index)=>{const meta=state[name]||{status:'done',progress:100,size:0};const error=meta.status==='error';const done=meta.status==='done';const escaped=escapeUploadText(name);return `<div class="expense-upload-card${error?' is-error':''}"><div class="expense-upload-head"><span class="expense-upload-status-icon ${error?'error':done?'success':''}"><i class="ti ${error?'ti-alert-circle-filled':done?'ti-circle-check-filled':'ti-folder-filled'}" aria-hidden="true"></i></span><div class="expense-upload-meta"><div class="expense-upload-name">${escaped}</div><div class="expense-upload-size">${formatUploadSize(meta.size)}</div>${error?`<div class="expense-upload-error">${escapeUploadText(meta.message||'Lampiran gagal diunggah. Coba lagi ya!')}</div>`:''}${done?`<button type="button" class="expense-upload-action" onclick="previewAttachment('${escaped.replace(/'/g,"\\'")}')">Preview</button>`:''}${error?`<button type="button" class="expense-upload-action error" onclick="${retryFns[kind]}('${escaped.replace(/'/g,"\\'")}')">Coba Lagi</button>`:''}</div><button type="button" class="expense-upload-remove" aria-label="Hapus ${escaped}" onclick="${removeFns[kind]}(${index})"><i class="ti ti-x" aria-hidden="true"></i></button></div>${!error&&!done?`<div class="expense-upload-progress-row"><div class="expense-upload-track"><div class="expense-upload-bar" style="width:${meta.progress||0}%"></div></div><span class="expense-upload-percent">${meta.progress||0}%</span></div>`:''}</div>`}).join('');
  const invalid=(errors||[]).map((item,index)=>`<div class="expense-upload-card is-error invalid"><div class="expense-upload-head"><span class="expense-upload-status-icon error"><i class="ti ti-alert-circle-filled" aria-hidden="true"></i></span><div class="expense-upload-meta"><div class="expense-upload-name">${escapeUploadText(item.name)}</div><div class="expense-upload-error">${escapeUploadText(item.message)}</div><button type="button" class="expense-upload-action error" onclick="removeUploaderError('${kind}',${index});document.getElementById('${inputIds[kind]}')?.click()">Ganti file</button></div><button type="button" class="expense-upload-remove" aria-label="Hapus file tidak valid" onclick="removeUploaderError('${kind}',${index})"><i class="ti ti-x" aria-hidden="true"></i></button></div></div>`).join('');
  return saved+invalid;
}
function uploaderChannel(kind){
  if(kind==='attachment')return{files:formState.attachments,state:expenseUploadState,errors:expenseUploadErrors,max:5};
  if(kind==='evidence')return{files:formState.evidenceFiles||(formState.evidenceFiles=[]),state:paymentEvidenceState,errors:paymentEvidenceErrors,max:5};
  return{files:modalPaymentEvidenceFiles,state:modalPaymentEvidenceState,errors:modalPaymentEvidenceErrors,max:5};
}
function renderFigmaUploader(kind,{label,optional=true,hint='Maks. 10 MB per file',accept='image/*,.pdf'}={}){
  const channel=uploaderChannel(kind),inputIds={attachment:'expenseAttachmentInput',evidence:'paymentEvidenceInput',modalEvidence:'modalPaymentEvidenceInput'},addFns={attachment:'addAttachments',evidence:'addPaymentEvidence',modalEvidence:'addModalPaymentEvidence'},dropFns={attachment:'handleAttachmentDrop',evidence:'handlePaymentEvidenceDrop',modalEvidence:'handleModalPaymentEvidenceDrop'};
  const inputId=inputIds[kind],full=channel.files.length>=channel.max,count=`${channel.files.length}/${channel.max}`;
  return `<div class="expense-uploader" data-uploader-kind="${kind}"><div class="expense-uploader-label"><span>${escapeUploadText(label)}${optional?' <span class="optional">Opsional</span>':''}</span><span class="expense-upload-count">${count}</span></div><input id="${inputId}" class="expense-upload-input" type="file" multiple accept="${accept}" onchange="${addFns[kind]}(this.files);this.value=''"/><div class="expense-upload-dropzone ${full?'is-disabled':''}" role="button" tabindex="${full?'-1':'0'}" aria-disabled="${full}" onclick="${full?'':`document.getElementById('${inputId}').click()`}" onkeydown="if(!${full}&&(event.key==='Enter'||event.key===' ')){event.preventDefault();document.getElementById('${inputId}').click()}" ondragenter="setGenericUploaderDrag(event,true)" ondragover="setGenericUploaderDrag(event,true)" ondragleave="setGenericUploaderDrag(event,false)" ondrop="${dropFns[kind]}(event)"><span class="expense-upload-icon" aria-hidden="true"><i class="ti ti-folder-filled"></i></span><div class="expense-upload-copy"><strong>${full?'Tidak bisa unggah':'Unggah file'}</strong>${full?'':' atau seret kesini'}</div><div class="expense-upload-hint">${full?`Maksimal ${channel.max} file dapat diunggah`:hint}</div></div><div class="expense-upload-list">${renderFigmaUploadCards(channel.files,channel.state,channel.errors,kind)}</div></div>`;
}
function renderExpenseUploaderFiles(){return renderFigmaUploadCards(formState?.attachments||[],expenseUploadState,expenseUploadErrors,'attachment')}
function renderExpenseAttachmentUploader(){return renderFigmaUploader('attachment',{label:'File pendukung',optional:true})}
function renderPaymentEvidenceUploader(){return renderFigmaUploader('evidence',{label:'Bukti Pembayaran',optional:true})}
function renderModalPaymentEvidenceUploader(){return renderFigmaUploader('modalEvidence',{label:'Bukti Pembayaran',optional:true})}
function refreshUploader(kind){
  if(kind==='attachment'){const root=document.querySelector('[data-uploader-kind="attachment"]');if(root)root.outerHTML=renderExpenseAttachmentUploader();return}
  if(kind==='evidence'){const root=document.querySelector('[data-uploader-kind="evidence"]');if(root)root.outerHTML=renderPaymentEvidenceUploader();return}
  const root=document.querySelector('[data-uploader-kind="modalEvidence"]');if(root)root.outerHTML=renderModalPaymentEvidenceUploader();
}
function refreshExpenseUploader(){refreshUploader('attachment')}
function setGenericUploaderDrag(event,active){event.preventDefault();const zone=event.currentTarget||event.target.closest('.expense-upload-dropzone');if(zone&&!zone.classList.contains('is-disabled'))zone.classList.toggle('is-dragging',active)}
function setAttachmentDrag(event,active){setGenericUploaderDrag(event,active)}
function validateUploaderFile(file){const validType=String(file.type||'').startsWith('image/')||file.type==='application/pdf'||/\.(pdf|png|jpe?g|webp)$/i.test(file.name||'');if(!validType)return'Format file tidak didukung. Gunakan PDF atau gambar.';if(file.size>10*1024*1024)return'Ukuran file melebihi 10 MB. Coba kompres atau ganti file.';return''}
function addFilesToUploader(kind,fileList){const channel=uploaderChannel(kind);for(const file of Array.from(fileList||[])){if(channel.files.length>=channel.max){channel.errors.push({name:file.name,message:`Maksimal ${channel.max} file dapat diunggah.`});continue}const message=validateUploaderFile(file);if(message){channel.errors.push({name:file.name,message});continue}if(channel.files.includes(file.name)){channel.errors.push({name:file.name,message:'File dengan nama yang sama sudah ditambahkan.'});continue}channel.files.push(file.name);channel.state[file.name]={status:'uploading',progress:10,size:file.size};simulateUploaderProgress(kind,file.name)}refreshUploader(kind)}
function simulateUploaderProgress(kind,name){const channel=uploaderChannel(kind);let progress=channel.state[name]?.progress||10;const timer=setInterval(()=>{const current=uploaderChannel(kind);if(!current.state[name]){clearInterval(timer);return}progress=Math.min(100,progress+Math.ceil(Math.random()*22));current.state[name].progress=progress;if(progress>=100){current.state[name].status='done';clearInterval(timer)}refreshUploader(kind)},220)}
function handleAttachmentDrop(event){event.preventDefault();setGenericUploaderDrag(event,false);addAttachments(event.dataTransfer?.files||[])}
function addAttachments(files){addFilesToUploader('attachment',files)}
function addPaymentEvidence(files){addFilesToUploader('evidence',files)}
function addModalPaymentEvidence(files){addFilesToUploader('modalEvidence',files)}
function handlePaymentEvidenceDrop(event){event.preventDefault();setGenericUploaderDrag(event,false);addPaymentEvidence(event.dataTransfer?.files||[])}
function handleModalPaymentEvidenceDrop(event){event.preventDefault();setGenericUploaderDrag(event,false);addModalPaymentEvidence(event.dataTransfer?.files||[])}
function retryUploader(kind,name){const channel=uploaderChannel(kind);if(!channel.state[name])return;channel.state[name].status='uploading';channel.state[name].progress=10;simulateUploaderProgress(kind,name);refreshUploader(kind)}
function retryAttachment(name){retryUploader('attachment',name)}
function retryPaymentEvidence(name){retryUploader('evidence',name)}
function retryModalPaymentEvidence(name){retryUploader('modalEvidence',name)}
function previewAttachment(name){showToast(`Preview ${name} dibuka (simulasi).`,'info')}
function removeUploaderError(kind,index){uploaderChannel(kind).errors.splice(index,1);refreshUploader(kind)}
function removeUploadError(index){removeUploaderError('attachment',index)}
function removeAttachment(index){const channel=uploaderChannel('attachment'),name=channel.files[index];channel.files.splice(index,1);delete channel.state[name];refreshUploader('attachment')}
function removePaymentEvidence(index){const channel=uploaderChannel('evidence'),name=channel.files[index];channel.files.splice(index,1);delete channel.state[name];refreshUploader('evidence')}
function removeModalPaymentEvidence(index){const channel=uploaderChannel('modalEvidence'),name=channel.files[index];channel.files.splice(index,1);delete channel.state[name];refreshUploader('modalEvidence')}
function goPayment(){if(formState.step!==2)formState.step=2;nextExpenseStep()}
function saveExpense(status){const c=formCalc();if(!sourceOptions.includes(formState.sourceData)){showToast('Sumber Data wajib dipilih.','error');return}const cfg=sourceConfig(formState.sourceData);if(formState.contact&&!cfg.vendors.includes(formState.contact)){showToast('Vendor tidak tersedia pada Sumber Data yang dipilih.','error');return}if(formState.paymentType!=='later'&&!cfg.accounts.includes(formState.account)){showToast('Rekening Kas & Bank tidak tersedia pada Sumber Data yang dipilih.','error');return}if(status==='Draft'&&(!formState.items.length||formState.items.every(i=>!i.item||Number(i.amount)<=0))){showToast('Isi minimal 1 item biaya untuk menyimpan Draft.','error');return}if(status==='Terbit'&&formState.paymentType!=='full'&&!formState.contact.trim()){showToast('Vendor wajib untuk Bayar Sekarang sebagian atau Bayar Nanti.','error');return}if(status==='Terbit'&&formState.paymentType==='later'&&!formState.due){showToast('Tanggal jatuh tempo wajib untuk Bayar Nanti.','error');return}let pay=formState.paymentType==='full'?c.total:formState.paymentType==='partial'?Number(formState.payAmount||0):0;if(formState.paymentType==='partial'&&(pay<=0||pay>=c.total)){showToast('Nominal Bayar Sekarang harus lebih dari nol dan tidak melebihi total tagihan.','error');return}if(pay>c.total){showToast('Nominal pembayaran tidak boleh melebihi total tagihan.','error');return}let obj={id:editingId||Date.now(),sourceData:formState.sourceData,code:formState.code,date:formState.date,contact:formState.contact,title:formState.title,createdAt:formState.createdAt,createdBy:formState.createdBy,due:formState.due,dueTime:formState.dueTime||'23:59',status,payStatus:'Belum Dibayar',items:formState.items.map(({id,...x})=>x),paid:status==='Draft'?0:pay,payments:status==='Draft'||pay<=0?[]:[{date:formState.payDate,account:formState.account,amount:pay,note:'Pembayaran awal',evidence:[...(formState.evidenceFiles||[])]}],attachments:formState.attachments};updatePayStatus(obj);if(editingId){expenses[expenses.findIndex(e=>e.id===editingId)]=obj}else expenses.unshift(obj);showToast(status==='Draft'?'Draft berhasil disimpan.':'Biaya berhasil diterbitkan dan jurnal terbentuk.');if(status==='Draft'){activeTab='Draft';selected.clear();renderList();showPage('list');return}renderList();openDetail(obj.id)}
function openDetail(id){currentDetailId=id;const e=expenses.find(x=>x.id===id);detailPage.innerHTML=renderDetail(e);showPage('detail')}
function renderDetail(e){const journals=journalGroups(e);return `<div class="card panel"><div class="section-head"><div><button class="btn btn-secondary" onclick="showPage('list')"><i class="ti ti-arrow-left" aria-hidden="true"></i>Kembali</button><h2 style="margin:14px 0 4px">${e.code}</h2><div class="hint">${fmtDate(e.date)}</div></div><div>${e.status==='Draft'?`<button class="btn btn-secondary" onclick="openForm(${e.id})">Edit Draft</button> <button class="btn btn-danger" onclick="askDelete(${e.id})">Hapus Draft</button> <button class="btn btn-primary" onclick="publishDraft(${e.id})">Terbitkan</button>`:e.status==='Terbit'?`${e.payStatus==='Lunas'?`<button class="btn btn-secondary" onclick="openRepeatForm(${e.id})">Catat Lagi</button> `:''}<button class="btn btn-secondary" onclick="openPrint(${e.id})">Cetak</button> <button class="btn btn-danger" onclick="askVoid(${e.id})">Void</button>`:`<button class="btn btn-secondary" onclick="openRepeatForm(${e.id})">Catat Lagi</button> <button class="btn btn-secondary" onclick="openPrint(${e.id})">Cetak</button>`}</div></div><div class="section-head"><h3>Informasi Utama</h3><span class="badge ${e.status.toLowerCase()}">${e.status}</span></div><div class="detail-grid">${[['Nomor Transaksi',e.code],['Sumber Data',e.sourceData||'Perusahaan'],['Tanggal Transaksi',fmtDate(e.date)],['Vendor',e.contact||'-'],['Keterangan',e.title],['Tanggal Jatuh Tempo',e.due?fmtDate(e.due):'-'],['Total Transaksi',rupiah(totalOf(e)-pphOf(e))],['Dibuat Oleh',e.createdBy]].map(x=>`<div><div class="info-label">${x[0]}</div><div class="info-value">${x[1]}</div></div>`).join('')}</div>${e.status==='Void'?`<div class="attachment-item" style="margin-top:18px"><span class="stamp">VOID</span><div style="margin-top:12px">Alasan: ${e.voidReason||'-'}</div><div class="hint" style="margin-top:6px">Dilakukan oleh ${e.voidedBy||'-'} · ${e.voidedAt?fmtDate(e.voidedAt):'-'}</div></div>`:''}</div><div class="card panel"><h3>Item Biaya</h3><div class="table-wrap"><table style="min-width:760px"><thead><tr><th>Item</th><th>Deskripsi</th><th>Nominal</th><th>Pajak</th><th>Nilai Pajak</th></tr></thead><tbody>${e.items.map(i=>`<tr><td>${i.item}</td><td>${i.desc}</td><td>${rupiah(i.amount)}</td><td>${taxTypeOf(i)==='ppn11'?'PPN 11%':taxTypeOf(i)==='pph10'?'PPh 10%':'Tanpa Pajak'}</td><td>${taxTypeOf(i)==='none'?'-':rupiah(taxTypeOf(i)==='ppn11'?ppnItemOf(i):pphItemOf(i))}</td></tr>`).join('')}</tbody></table></div></div><div class="card panel"><div class="section-head"><h3>Ringkasan Pembayaran</h3>${e.status==='Terbit'&&e.payStatus!=='Lunas'?`<button class="btn btn-primary" onclick="openPayment(${e.id})">Catat Pembayaran</button>`:''}</div><div class="payment-summary">${[['Total Tagihan',rupiah(totalOf(e)-pphOf(e))],['Total Sudah Dibayar',rupiah(e.paid)],['Sisa Tagihan',rupiah(remainingOf(e))],['Status Pembayaran',e.payStatus],['Tanggal Jatuh Tempo',e.due?fmtDate(e.due):'-']].map(x=>`<div class="summary-card"><div class="summary-label">${x[0]}</div><div style="margin-top:8px;font-weight:700">${x[1]}</div></div>`).join('')}</div><div class="history-list">${e.payments.length?e.payments.map((p,i)=>`<div class="history-item"><strong>Pembayaran ${i+1}</strong><div>${fmtDate(p.date)} · ${p.account} · ${rupiah(p.amount)} · ${p.note||'-'}</div>${p.evidence?`<div class="hint" style="margin-top:6px">Bukti pembayaran: ${p.evidence}</div>`:''}</div>`).join(''):'<div class="empty">Belum ada pembayaran.</div>'}</div></div><div class="card panel"><h3>Lampiran</h3><div class="grid-2"><div><div class="subsection-title" style="font-size:14px;margin-bottom:10px">Lampiran Transaksi</div><div class="attachment-list">${e.attachments&&e.attachments.length?e.attachments.map(a=>`<div class="attachment-item"><strong>${a}</strong><div class="hint">Diunggah pada Informasi Transaksi</div></div>`).join(''):'<div class="empty">Tidak ada lampiran transaksi.</div>'}</div></div><div><div class="subsection-title" style="font-size:14px;margin-bottom:10px">Bukti Pembayaran</div><div class="attachment-list">${e.payments&&e.payments.some(p=>p.evidence)?e.payments.filter(p=>p.evidence).map((p,i)=>`<div class="attachment-item"><strong>${p.evidence}</strong><div class="hint">Pembayaran ${i+1} · ${fmtDate(p.date)} · ${rupiah(p.amount)}</div></div>`).join(''):'<div class="empty">Tidak ada bukti pembayaran.</div>'}</div></div></div></div><div class="card panel"><h3>Section Jurnal</h3><div class="journal-list">${journals.map((j,i)=>`<div class="journal-card"><button class="accordion-head" onclick="toggleAccordion(${i})"><span>${j.type} · ${j.id}</span><i class="ti ti-chevron-down" aria-hidden="true"></i></button><div class="accordion-body" id="acc${i}"><div class="hint">${j.date} · Sumber Data ${j.sourceData||e.sourceData||'Perusahaan'} · Referensi ${e.code}</div><div class="table-wrap" style="margin-top:10px"><table style="min-width:600px"><thead><tr><th>Akun</th><th>Debit</th><th>Kredit</th></tr></thead><tbody>${j.lines.map(l=>`<tr><td>${l.account}</td><td>${rupiah(l.debit)}</td><td>${rupiah(l.credit)}</td></tr>`).join('')}</tbody></table></div></div></div>`).join('')}</div></div>`}
function journalGroups(e){
  if(e.status==='Draft') return [];
  const base=e.items.reduce((sum,item)=>sum+Number(item.amount||0),0);
  const ppn=ppnOf(e);
  const pph=pphOf(e);
  const payable=totalOf(e)-pph;
  const debitLines=[
    {account:e.items[0]?.coa||'Beban',debit:base,credit:0},
    ...(ppn>0?[{account:'PPN Masukan',debit:ppn,credit:0}]:[])
  ];
  const withholdingLines=pph>0?[{account:'PPh Terutang',debit:0,credit:pph}]:[];

  // Transaksi lunas dicatat langsung ke kas/bank pada jurnal penerbitan.
  // Tidak membentuk Hutang Biaya dan tidak menghasilkan jurnal pembayaran terpisah.
  if(e.payStatus==='Lunas'){
    const paymentAccount=e.payments?.[0]?.account||'Kas / Bank';
    return [{
      sourceData:e.sourceData||'Perusahaan',
      id:'JRN-'+e.id+'-01',
      date:fmtDate(e.date),
      type:'Jurnal Penerbitan',
      lines:[...debitLines,...withholdingLines,{account:paymentAccount,debit:0,credit:payable}]
    }];
  }

  const arr=[{
    sourceData:e.sourceData||'Perusahaan',
    id:'JRN-'+e.id+'-01',
    date:fmtDate(e.date),
    type:'Jurnal Penerbitan',
    lines:[...debitLines,...withholdingLines,{account:'Hutang Biaya',debit:0,credit:payable}]
  }];

  e.payments.forEach((payment,index)=>arr.push({
    sourceData:e.sourceData||'Perusahaan',
    id:`JRN-${e.id}-P${index+1}`,
    date:fmtDate(payment.date),
    type:index?'Jurnal Pembayaran Berikutnya':'Jurnal Pembayaran',
    lines:[
      {account:'Hutang Biaya',debit:payment.amount,credit:0},
      {account:payment.account,debit:0,credit:payment.amount}
    ]
  }));

  if(e.status==='Void'){
    arr.push({
      sourceData:e.sourceData||'Perusahaan',
      id:`JRN-${e.id}-V`,
      date:fmtDate('2026-07-17T10:00'),
      type:'Jurnal Void / Pembalik',
      lines:[
        {account:'Hutang Biaya',debit:payable,credit:0},
        ...(pph>0?[{account:'PPh Terutang',debit:pph,credit:0}]:[]),
        ...(ppn>0?[{account:'PPN Masukan',debit:0,credit:ppn}]:[]),
        {account:e.items[0]?.coa||'Beban',debit:0,credit:base}
      ]
    });
  }
  return arr;
}
function toggleAccordion(i){document.getElementById('acc'+i).classList.toggle('show')}
function syncModalPayDate(){const date=document.getElementById('payDateDay')?.value||expenseDatePart(localDateTimeValue()),time=document.getElementById('payDateTime')?.value||'00:00';return `${date}T${time}`}
function openPayment(id){currentPaymentId=id;const e=expenses.find(x=>x.id===id),maxAmount=remainingOf(e);modalPaymentEvidenceFiles=[];modalPaymentEvidenceState={};modalPaymentEvidenceErrors=[];document.getElementById('payDateDay').value='2026-07-17';document.getElementById('payDateTime').value='10:00';payAccount.innerHTML=availableAccounts(e.sourceData||'Perusahaan').map(a=>`<option>${a}</option>`).join('');payAmount.dataset.max=String(maxAmount);payAmount.dataset.raw='0';payAmount.value='';payAmount.removeAttribute('readonly');payAmount.removeAttribute('aria-readonly');const remainingField=document.getElementById('payRemaining');if(remainingField)remainingField.value=rupiah(maxAmount);payNote.value='';document.getElementById('modalPaymentEvidenceMount').innerHTML=renderModalPaymentEvidenceUploader();openModal('paymentModal')}
function savePayment(){const e=expenses.find(x=>x.id===currentPaymentId),remaining=remainingOf(e),amt=Number(payAmount.dataset.raw||String(payAmount.value||'').replace(/[^0-9]/g,''))||0;if(remaining<=0){showToast('Transaksi sudah lunas.','error');return}if(amt<=0){showToast('Nominal pembayaran harus lebih dari nol.','error');return}if(amt>remaining){showToast('Nominal pembayaran tidak boleh melebihi sisa tagihan.','error');return}e.payments.push({date:syncModalPayDate(),account:payAccount.value,amount:amt,note:payNote.value,evidence:[...modalPaymentEvidenceFiles]});e.paid+=amt;updatePayStatus(e);closeModal('paymentModal');showToast('Pembayaran berhasil dicatat dan jurnal baru terbentuk.');renderList();openDetail(e.id)}
function updateModalPaymentAmount(value){const input=document.getElementById('payAmount'),max=Math.max(0,Number(input?.dataset.max||0)),raw=Math.max(0,Number(String(value||'').replace(/[^0-9]/g,''))||0),amount=Math.min(raw,max);if(input){input.dataset.raw=String(amount);input.value=amount?rupiah(amount):''}const remainingField=document.getElementById('payRemaining');if(remainingField)remainingField.value=rupiah(Math.max(max-amount,0));return amount}
document.addEventListener('input',function(event){if(event.target&&event.target.id==='payAmount')updateModalPaymentAmount(event.target.value)})
function askVoid(id){currentVoidId=id;const reason=document.getElementById('voidReason');if(reason)reason.value='';const defaultChoice=document.querySelector('input[name="voidAction"][value="void"]');if(defaultChoice)defaultChoice.checked=true;openModal('voidModal')}
function confirmVoid(){const reason=document.getElementById('voidReason');if(!reason||!reason.value.trim()){showToast('Alasan Void wajib diisi.','error');return}const selectedAction=document.querySelector('input[name="voidAction"]:checked');if(!selectedAction){showToast('Pilih proses Void terlebih dahulu.','error');return}const e=expenses.find(x=>x.id===currentVoidId);if(!e){showToast('Transaksi tidak ditemukan.','error');return}const createAgain=selectedAction.value==='repeat';e.status='Void';e.voidReason=reason.value.trim();e.voidedBy=loggedInUserName;e.voidedAt=new Date().toISOString();closeModal('voidModal');renderList();if(createAgain){pendingVoidRepeatId=e.id;openModal('voidRepeatSuccessModal')}else{showToast('Transaksi berhasil di-void dan jurnal terkait telah disesuaikan.');openDetail(e.id)}}
function continueVoidRepeat(){const id=pendingVoidRepeatId;pendingVoidRepeatId=null;closeModal('voidRepeatSuccessModal');if(!id){showToast('Salinan transaksi tidak ditemukan.','error');return}openRepeatForm(id)}
function askDelete(id){currentDeleteId=id;openModal('deleteModal')}
function confirmDelete(){expenses=expenses.filter(e=>e.id!==currentDeleteId);closeModal('deleteModal');showToast('Draft berhasil dihapus.');renderList();showPage('list')}
function publishDraft(id){const e=expenses.find(x=>x.id===id);e.status='Terbit';updatePayStatus(e);showToast('Draft berhasil diterbitkan dan jurnal penerbitan terbentuk.');renderList();openDetail(id)}
function openPrint(id){const e=expenses.find(x=>x.id===id);printPage.innerHTML=`<div class="print-hide" style="margin-bottom:16px"><button class="btn btn-secondary" onclick="openDetail(${id})"><i class="ti ti-arrow-left" aria-hidden="true"></i>Kembali ke Detail</button> <button class="btn btn-primary" onclick="window.print()">Download / Cetak PDF</button></div><div class="card panel print-doc"><div class="print-header"><div><h1>Bukti Pengeluaran</h1><strong>GroApp Accounting</strong></div><div class="stamp">${e.status.toUpperCase()}</div></div><div class="detail-grid">${[['Nomor Transaksi',e.code],['Sumber Data',e.sourceData||'Perusahaan'],['Judul Transaksi',e.title],['Tanggal Transaksi',fmtDate(e.date)],['Vendor',e.contact||'-'],['Dibuat Oleh',e.createdBy],['Tanggal Jatuh Tempo',e.due?fmtDate(e.due):'-']].map(x=>`<div><div class="info-label">${x[0]}</div><div class="info-value">${x[1]}</div></div>`).join('')}</div><h3 style="margin-top:24px">Rincian Item</h3><div class="table-wrap"><table style="min-width:700px"><thead><tr><th>Item</th><th>Deskripsi</th><th>Nominal</th><th>Pajak</th><th>Nilai Pajak</th></tr></thead><tbody>${e.items.map(i=>`<tr><td>${i.item}</td><td>${i.desc}</td><td>${rupiah(i.amount)}</td><td>${taxTypeOf(i)==='ppn11'?'PPN 11%':taxTypeOf(i)==='pph10'?'PPh 10%':'Tanpa Pajak'}</td><td>${taxTypeOf(i)==='none'?'-':rupiah(taxTypeOf(i)==='ppn11'?ppnItemOf(i):pphItemOf(i))}</td></tr>`).join('')}</tbody></table></div><div class="summary-grid"><div class="summary-card"><div class="summary-label">Total Tagihan</div><div class="summary-value">${rupiah(totalOf(e)-pphOf(e))}</div></div><div class="summary-card"><div class="summary-label">Total Dibayar</div><div class="summary-value">${rupiah(e.paid)}</div></div><div class="summary-card"><div class="summary-label">Sisa Tagihan</div><div class="summary-value">${rupiah(remainingOf(e))}</div></div></div><h3>Informasi Pembayaran</h3>${e.payments.length?e.payments.map((p,i)=>`<div class="history-item">Pembayaran ${i+1}: ${fmtDate(p.date)} · ${p.account} · ${rupiah(p.amount)}</div>`).join(''):'<div class="empty">Belum ada pembayaran.</div>'}<h3>Attachment</h3>${e.attachments.length?e.attachments.map(a=>`<div class="attachment-item">${a}</div>`).join(''):'<div class="empty">Tidak ada attachment.</div>'}</div>`;showPage('print')}
document.getElementById('searchInput').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(renderList,300)});
document.addEventListener('click',e=>{
  if(!e.target.closest?.('.actions')){
    document.querySelectorAll('.menu').forEach(menu=>{
      menu.classList.remove('show');
      resetRowMenuPosition(menu);
    });
    document.querySelectorAll('.row-kebab').forEach(button=>button.setAttribute('aria-expanded','false'));
  }
  if(!e.target.closest?.('.expense-source-select'))closeExpenseSourceDropdown();
  if(!e.target.closest?.('.expense-vendor-select')&&!e.target.closest?.('.expense-vendor-search'))closeExpenseVendorDropdown()
  if(!e.target.closest?.('.expense-contact-select'))closeExpenseContactDropdowns();
  if(!e.target.closest?.('.expense-item-select'))closeExpenseItemMenu();
});
function initializePrototype(){
  try{
    populateFilterOptions();
    syncDateRangeLabel();
    selected.clear();
    renderList();
    showPage('list');
  }catch(error){
    console.error('Prototype initialization failed:',error);
    const fallback=document.getElementById('rows');
    if(fallback) fallback.innerHTML='<tr><td colspan="10"><div class="empty">Prototype gagal dimuat. Silakan muat ulang halaman.</div></td></tr>';
  }
}
if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',initializePrototype,{once:true});
}else{
  initializePrototype();
}
window.addEventListener('load',()=>{renderList();},{once:true});

